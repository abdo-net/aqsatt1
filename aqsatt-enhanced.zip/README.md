# AQSATT

Installment / credit-commerce platform. Decoupled stack: FastAPI backend +
Next.js 14 frontend (BFF cookie auth) behind nginx.

## Structure
```
aqsatt/
├── backend/            FastAPI + PostgreSQL (RLS), Alembic, append-only ledger
│   ├── app/            routers, models, services, core (config/security/deps)
│   ├── alembic/        migrations (incl. c3d4e5f6a7b8 refresh_tokens)
│   ├── jobs/           overdue installment job
│   └── requirements.txt, gunicorn_conf.py, .env.example
├── frontend/           Next.js 14 (App Router, Tailwind 3, shadcn, TanStack)
│   ├── src/app/        pages + /api BFF (proxy, auth login/refresh/logout)
│   ├── src/features/   customers, products, sales, payments, ledger, settings
│   ├── src/middleware.ts (refresh-aware auth guard)
│   └── .env.example
├── nginx/aqsatt.conf   reverse proxy (/ → 3000, /api & /static → 8000, TLS)
├── installer/
│   ├── install.sh      one-command production installer
│   └── systemd/        backend, frontend, overdue units
└── INTEGRATION_REPORT.md
```

## Production install (clean Ubuntu 22.04/24.04)
```bash
sudo bash installer/install.sh
```
Prompts for domain, email, and DNS-readiness. It installs PostgreSQL/Python/
Node/nginx, creates the `ccs_admin` (migrations) and `ccs_app` (RLS) roles with
generated passwords, generates ONE shared `JWT_SECRET` for both services,
migrates + seeds, builds the frontend, installs systemd services, configures
nginx, and obtains a Let's Encrypt certificate. Prints the generated admin
password at the end.

## Local development
Backend:
```bash
cd backend
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # set DATABASE_URL/ADMIN_DATABASE_URL + a >=32-char JWT_SECRET
alembic upgrade head
python -m app.db.seed
uvicorn app.main:app --port 8000
```
Frontend (separate shell):
```bash
cd frontend
cp .env.example .env            # JWT_SECRET MUST equal the backend's
npm install
npm run dev                     # http://localhost:3000
```

## Critical invariants
- `JWT_SECRET` must be **identical** in `backend/.env` and `frontend/.env` and **≥32 chars**. Mismatch = silent total lockout.
- All money is **integer Iraqi dinars** (no fractions, Latin digits).
- Multi-tenant isolation is enforced by PostgreSQL RLS; the app connects as the non-superuser `ccs_app` role.
- The ledger and `refresh_tokens` are append-only / revoke-only — never hard-deleted.

See `INTEGRATION_REPORT.md` for what was changed, what was validated, and the
one open decision (ledger/payments list shape).
