#!/usr/bin/env bash
# ============================================================================
# AQSATT — Credit Commerce / Installment System — Production Installer
# ============================================================================
# Target: Ubuntu 22.04 / 24.04 server. Run as root (sudo). Idempotent — safe
# to re-run: stops the old services, replaces the deployed copy + nginx site
# from scratch, rebuilds, and restarts. No manual cleanup required between runs.
#
# Topology (the ONE correct layout — not configurable):
#   PostgreSQL (loopback) -> FastAPI gunicorn 127.0.0.1:8000
#                         -> Next.js          127.0.0.1:3000
#                         -> nginx (sole public face, TLS)
#
# Run from the directory that contains backend/ and frontend/ (the aqsatt tree).
#   sudo ./installer/install.sh        # from repo root: sudo bash installer/install.sh
# ============================================================================
set -euo pipefail

# ---- fixed configuration ---------------------------------------------------
APP_USER="aqsatt"
APP_ROOT="/opt/aqsatt"
BACKEND_DIR="$APP_ROOT/backend"
FRONTEND_DIR="$APP_ROOT/frontend"
DB_NAME="ccs"
DB_ADMIN_ROLE="ccs_admin"      # superuser-ish: owns schema, runs migrations
DB_APP_ROLE="ccs_app"          # restricted: RLS-enforced application role
API_PORT="8000"; WEB_PORT="3000"; PG_PORT="5432"
MIN_NODE_MAJOR=20

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
say(){ echo -e "${BLUE}[*]${NC} $1"; }
ok(){  echo -e "${GREEN}[OK]${NC} $1"; }
warn(){ echo -e "${YELLOW}[!]${NC} $1"; }
die(){ echo -e "${RED}[FATAL]${NC} $1" >&2; exit 1; }
# set -e kills the script on ANY non-zero exit, including from things deep
# inside a pipe (pipefail) — and does so SILENTLY unless something traps it.
# This turns the next surprise into a line number instead of a blank prompt.
trap 'echo -e "${RED}[FATAL]${NC} install.sh aborted at line $LINENO — last command: $BASH_COMMAND" >&2' ERR

# ---- 0. preconditions ------------------------------------------------------
[ "$EUID" -eq 0 ] || die "Run as root (sudo)."
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"   # repo root (parent of installer/)
[ -d "$SRC_DIR/backend" ] && [ -d "$SRC_DIR/frontend" ] || \
  die "Could not find backend/ and frontend/ next to installer/. Run from the aqsatt tree."

read -rp "Domain pointing at this server (e.g. aqsatt.example.com): " DOMAIN
[ -n "$DOMAIN" ] || die "Domain required — auth cookies need real TLS to be Secure."
read -rp "Email for Let's Encrypt notices: " LE_EMAIL
[ -n "$LE_EMAIL" ] || die "Email required for certbot."
read -rp "Is DNS for $DOMAIN already pointed at this server? [y/N]: " DNS_READY

# ---- 1. teardown old install (safe to run on a fresh box — all guarded) ----
say "Stopping any previous AQSATT services..."
systemctl stop aqsatt-frontend.service 2>/dev/null || true
systemctl stop aqsatt-backend.service 2>/dev/null || true
systemctl stop aqsatt-overdue.timer 2>/dev/null || true
systemctl disable aqsatt-frontend.service 2>/dev/null || true
systemctl disable aqsatt-backend.service 2>/dev/null || true
# Belt-and-suspenders: kill anything still bound to our ports that systemd
# didn't track (a manually-run `npm start`/`node`/gunicorn from past testing,
# or a process that outlived a crashed unit). Without this, a stale process
# serving an OLD build can keep answering on 3000/8000 after redeploy —
# the exact "stale build vs new build" mismatch that causes Server Action /
# chunk-hash errors and EADDRINUSE on the next start.
for PORT in 3000 8000; do
  # `|| true` on the WHOLE pipeline is required: grep exits 1 when nothing is
  # listening on the port yet (the normal case on a fresh box), and pipefail
  # propagates that 1 to this assignment — which set -e then treats as a
  # failed command and kills the entire script, silently, with no message.
  PIDS="$(ss -ltnp 2>/dev/null | awk -v p=":$PORT" '$4 ~ p {print $NF}' | grep -oP 'pid=\K[0-9]+' | sort -u || true)"
  if [ -n "${PIDS:-}" ]; then
    warn "Killing leftover process(es) on port $PORT: $PIDS"
    kill -9 $PIDS 2>/dev/null || true
  fi
done
ok "Old services stopped and ports 3000/8000 confirmed free."

# ---- 2. system packages ----------------------------------------------------
say "Installing system packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip postgresql postgresql-contrib \
  nginx curl ca-certificates gnupg git >/dev/null
# Node.js (NodeSource) if missing or too old
if ! command -v node >/dev/null || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt "$MIN_NODE_MAJOR" ]; then
  say "Installing Node.js ${MIN_NODE_MAJOR}.x..."
  curl -fsSL "https://deb.nodesource.com/setup_${MIN_NODE_MAJOR}.x" | bash - >/dev/null
  apt-get install -y -qq nodejs >/dev/null
fi
command -v node >/dev/null || die "Node install failed."
ok "System packages ready (node $(node -v), python $(python3 -V | awk '{print $2}'))."

# ---- 3. firewall ------------------------------------------------------------
# Only touch ufw if it's already the active firewall — never enable it on a
# box that doesn't use it (that could lock out the current SSH session).
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  say "ufw is active — opening 80/443 (leaving everything else as-is)..."
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ok "Firewall ports 80/443 open."
else
  warn "ufw not active — skipping (certbot's HTTP-01 challenge needs your cloud/VPS firewall to allow inbound 80/443 too)."
fi

# ---- 4. app user + copy source --------------------------------------------
id "$APP_USER" >/dev/null 2>&1 || useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_ROOT"
say "Copying source to $APP_ROOT..."
rsync -a --delete --exclude node_modules --exclude .next --exclude venv --exclude __pycache__ \
  "$SRC_DIR/backend/" "$BACKEND_DIR/"
rsync -a --delete --exclude node_modules --exclude .next \
  "$SRC_DIR/frontend/" "$FRONTEND_DIR/"
ok "Source copied."

# ---- 5. secrets (D1 fix: ONE shared JWT secret for backend AND frontend) ---
# DB/JWT secrets stay random — they're never user-facing and there's no reason
# to make them guessable. The admin LOGIN password is intentionally fixed
# (explicit operator request: deterministic credentials for initial setup).
# This is a known-default-credential tradeoff: change it after first login —
# seed.py resets it to this value on every install.sh run, so re-running the
# installer will NOT preserve a password you changed in the UI.
DB_ADMIN_PASS="$(openssl rand -hex 24)"
DB_APP_PASS="$(openssl rand -hex 24)"
SHARED_JWT_SECRET="$(openssl rand -hex 32)"   # 64 chars, satisfies frontend min(32)
ADMIN_PW="admin123"

# ---- 6. PostgreSQL: dual roles + DB ---------------------------------------
say "Configuring PostgreSQL roles and database..."
sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='${DB_ADMIN_ROLE}') THEN
    CREATE ROLE ${DB_ADMIN_ROLE} LOGIN PASSWORD '${DB_ADMIN_PASS}' CREATEDB CREATEROLE;
  ELSE ALTER ROLE ${DB_ADMIN_ROLE} PASSWORD '${DB_ADMIN_PASS}'; END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='${DB_APP_ROLE}') THEN
    CREATE ROLE ${DB_APP_ROLE} LOGIN PASSWORD '${DB_APP_PASS}';
  ELSE ALTER ROLE ${DB_APP_ROLE} PASSWORD '${DB_APP_PASS}'; END IF;
END \$\$;
SQL
# CREATE DATABASE cannot run inside a DO block — issued separately, idempotently.
if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1; then
  sudo -u postgres createdb -O "${DB_ADMIN_ROLE}" "${DB_NAME}"
fi
sudo -u postgres psql -v ON_ERROR_STOP=1 -d "${DB_NAME}" <<SQL
ALTER DATABASE ${DB_NAME} OWNER TO ${DB_ADMIN_ROLE};
GRANT CONNECT ON DATABASE ${DB_NAME} TO ${DB_APP_ROLE};
SQL
ok "PostgreSQL roles + database ready."

# ---- 7. backend: venv, .env, migrate, seed --------------------------------
say "Setting up backend venv + dependencies..."
rm -rf "$BACKEND_DIR/venv"   # never layer a fresh install onto a stale/partial venv
python3 -m venv "$BACKEND_DIR/venv"
"$BACKEND_DIR/venv/bin/pip" install -q --upgrade pip
"$BACKEND_DIR/venv/bin/pip" install -q -r "$BACKEND_DIR/requirements.txt"

# scram-sha-256 needs a password in the URL (no peer auth over TCP).
cat > "$BACKEND_DIR/.env" <<ENV
DATABASE_URL=postgresql+psycopg2://${DB_APP_ROLE}:${DB_APP_PASS}@localhost:${PG_PORT}/${DB_NAME}
ADMIN_DATABASE_URL=postgresql+psycopg2://${DB_ADMIN_ROLE}:${DB_ADMIN_PASS}@localhost:${PG_PORT}/${DB_NAME}
JWT_SECRET=${SHARED_JWT_SECRET}
JWT_ACCESS_EXP_MINUTES=120
JWT_REFRESH_EXP_DAYS=30
DEFAULT_TENANT_NAME="Default Store"
DEFAULT_TENANT_SLUG=default
DEFAULT_ADMIN_USERNAME=admin
DEFAULT_ADMIN_PASSWORD=${ADMIN_PW}
CORS_ORIGINS=https://${DOMAIN}
ENV

say "Running migrations (alembic upgrade head)..."
( cd "$BACKEND_DIR" && set -a && . ./.env && set +a && ./venv/bin/alembic upgrade head )
say "Seeding baseline data (tenant, admin, roles, accounts)..."
( cd "$BACKEND_DIR" && set -a && . ./.env && set +a && ./venv/bin/python -m app.db.seed )
# Safety-net grant pass for any tables added by future migrations.
sudo -u postgres psql -d "${DB_NAME}" -c \
  "GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO ${DB_APP_ROLE}; \
   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ${DB_APP_ROLE};" >/dev/null
ok "Backend database ready. seed.py resets the admin password every run — the
    one printed at the end of THIS run is always the one that actually works."

# ---- 8. frontend: .env, install, build ------------------------------------
say "Building frontend (npm install + next build)..."
cat > "$FRONTEND_DIR/.env" <<ENV
NODE_ENV=production
NEXT_PUBLIC_SITE_URL=https://${DOMAIN}
API_INTERNAL_URL=http://127.0.0.1:${API_PORT}
JWT_SECRET=${SHARED_JWT_SECRET}
ENV
rm -rf "$FRONTEND_DIR/.next" "$FRONTEND_DIR/node_modules"   # never layer onto stale build artifacts or a half-installed node_modules
( cd "$FRONTEND_DIR" && if [ -f package-lock.json ]; then npm ci; else npm install; fi && npm run build )
[ -d "$FRONTEND_DIR/.next/static" ] || die "next build did not produce .next/static — check the build log above."
[ -f "$FRONTEND_DIR/.next/standalone/server.js" ] || die "next build did not produce .next/standalone/server.js — next.config.js must have output:'standalone'."

# next's standalone output does NOT include static assets or public/ — it must
# be assembled manually (this is the step that's missing if you ever see pages
# load with no CSS/JS: the standalone server runs, but /_next/static 404s
# because this copy never happened).
mkdir -p "$FRONTEND_DIR/.next/standalone/.next"
cp -r "$FRONTEND_DIR/.next/static" "$FRONTEND_DIR/.next/standalone/.next/static"
mkdir -p "$FRONTEND_DIR/.next/standalone/public"
cp -r "$FRONTEND_DIR/public/." "$FRONTEND_DIR/.next/standalone/public/" 2>/dev/null || true
ok "Frontend built (standalone runtime assembled)."

chown -R "$APP_USER:$APP_USER" "$APP_ROOT"

# ---- 9. systemd services ---------------------------------------------------
say "Installing systemd services..."
cp "$SRC_DIR/installer/systemd/"*.service "$SRC_DIR/installer/systemd/"*.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now aqsatt-backend.service
systemctl enable --now aqsatt-frontend.service
systemctl enable --now aqsatt-overdue.timer
sleep 3
systemctl is-active --quiet aqsatt-backend.service || die "backend service failed: journalctl -u aqsatt-backend -n 50 --no-pager"
systemctl is-active --quiet aqsatt-frontend.service || die "frontend service failed: journalctl -u aqsatt-frontend -n 50 --no-pager"

# Verify both services actually answer on loopback before touching nginx.
# Plain root-path checks first (cheapest signal: did anything bind the port at all).
curl -fsS -o /dev/null "http://127.0.0.1:${WEB_PORT}" || die "curl http://127.0.0.1:${WEB_PORT} got no response — frontend did not bind to the port. journalctl -u aqsatt-frontend -n 50 --no-pager"
curl -fsS -o /dev/null "http://127.0.0.1:${API_PORT}" || die "curl http://127.0.0.1:${API_PORT} got no response — backend did not bind to the port. journalctl -u aqsatt-backend -n 50 --no-pager"
# Stronger checks: real routes that must return 200, not just "something answered".
curl -fsS "http://127.0.0.1:${API_PORT}/health" >/dev/null || die "backend /health not responding on 127.0.0.1:${API_PORT}."
curl -fsS -o /dev/null "http://127.0.0.1:${WEB_PORT}/login" || die "frontend /login not responding on 127.0.0.1:${WEB_PORT}."
ok "Services running and answering on loopback (root path + /health + /login all verified)."

# ---- 10. nginx — rebuilt from zero every run -------------------------------
say "Configuring nginx (clean slate — removing any other enabled sites)..."
rm -f /etc/nginx/sites-enabled/*
rm -f /etc/nginx/sites-available/aqsatt.conf
sed "s/YOUR_DOMAIN/${DOMAIN}/g" "$SRC_DIR/nginx/aqsatt.conf" > /etc/nginx/sites-available/aqsatt.conf
ln -sf /etc/nginx/sites-available/aqsatt.conf /etc/nginx/sites-enabled/aqsatt.conf
nginx -t || die "nginx config test failed — see output above."
systemctl reload nginx
ok "nginx configured (HTTP only — TLS is added by certbot below)."
curl -fsS -o /dev/null -H "Host: ${DOMAIN}" "http://127.0.0.1/login" \
  || warn "nginx did not proxy /login successfully on port 80 — check 'nginx -T' and 'journalctl -u nginx'."
# Regression guard: /api/auth/login and /api/v1/* must reach the FRONTEND (which
# injects the Bearer token from the httpOnly cookie before calling the backend),
# never the backend directly — the backend only knows /api/v1/auth/login, not
# /api/auth/login, and only accepts Authorization: Bearer, never a raw cookie.
AUTH_LOGIN_STATUS="$(curl -s -o /dev/null -w '%{http_code}' -H "Host: ${DOMAIN}" -X POST \
  -H 'Content-Type: application/json' -d '{}' "http://127.0.0.1/api/auth/login" || true)"
[ -n "$AUTH_LOGIN_STATUS" ] || die "Could not reach nginx on port 80 at all (curl couldn't connect) — check 'systemctl status nginx' and 'journalctl -u nginx'."
[ "$AUTH_LOGIN_STATUS" != "404" ] || die "nginx is routing /api/auth/login to the backend (got 404 — backend has no such path). It must reach the frontend's own /api/auth/login route. Check nginx/aqsatt.conf has no /api/ location before the catch-all."
ok "nginx routes /api/auth/* to the frontend correctly (got ${AUTH_LOGIN_STATUS}, not 404)."

# ---- 11. TLS (certbot) ------------------------------------------------------
if [[ "${DNS_READY,,}" == "y" ]]; then
  say "Obtaining Let's Encrypt certificate..."
  apt-get install -y -qq certbot python3-certbot-nginx >/dev/null
  certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos -m "${LE_EMAIL}" --redirect \
    || warn "certbot failed (often: DNS not actually resolving yet, or port 80/443 blocked upstream of this box — check your cloud provider's firewall/security group, not just ufw). Site is up on HTTP. Re-run: certbot --nginx -d ${DOMAIN}"
  ok "TLS step finished — check the output above for success/failure."
else
  warn "DNS not ready: TLS skipped. Point DNS to this server, then run:"
  warn "   certbot --nginx -d ${DOMAIN} -m ${LE_EMAIL} --agree-tos --redirect"
  warn "Until HTTPS is live, auth cookies are NOT Secure and login may misbehave."
fi

# ---- done ------------------------------------------------------------------
echo ""
ok "AQSATT installed (frontend running via .next/standalone/server.js, not npm run start)."
echo "  URL:            https://${DOMAIN}"
echo "  Admin user:     admin"
echo "  Admin password: ${ADMIN_PW}"
echo "  WARNING: this is a fixed, known default password by design (not random)."
echo "  It is reset to '${ADMIN_PW}' on every install.sh run. Change it from Settings"
echo "  right after first login if this server is reachable from the internet."
echo ""
echo "  Logs:  journalctl -u aqsatt-backend -f | journalctl -u aqsatt-frontend -f | journalctl -u nginx -f"
echo "  Re-run this script any time to redeploy from scratch — it tears down and rebuilds cleanly."
