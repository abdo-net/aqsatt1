# AQSATT — Integration Report

Code-grounded reconciliation of the new Next.js frontend (QUSITT) with the
existing FastAPI backend (ccs_full). Every claim below was verified against the
actual source, not the blueprint documents.

## 1. Topology (final)

```
PostgreSQL (loopback)
  -> FastAPI / gunicorn   127.0.0.1:8000
  -> Next.js              127.0.0.1:3000   (BFF proxy + pages)
  -> nginx                :80/:443         (sole public face, TLS)
```
Browser never sees raw tokens: the Next.js Route Handler (`/api/v1/[[...path]]`)
holds the httpOnly cookies and injects `Authorization: Bearer` server-side.

## 2. Mismatches found (verified) and resolution

### Auth / session (root cause of the "logout after 12h")
| Finding | Resolution |
|---|---|
| Backend issued a single 12h access JWT; no refresh, no `/auth/refresh`, no `/auth/logout`. | Added access(120m)+refresh(30d) system: `create_refresh_token`, `/auth/refresh` (rotating), `/auth/logout` (revoking), server-side `refresh_tokens` registry. |
| BFF `/api/auth/refresh` was a no-op (returned success, issued nothing) → interceptor retried the same expired token. | Rewrote it to call the backend, rotate, and reset both cookies. |
| JWT secret defaults differed (backend 20 chars vs frontend 34, frontend zod requires ≥32) → silent total lockout if env unset. | Backend default unified to ≥32 chars; installer generates ONE shared secret written to BOTH `.env` files. |
| Login cookie `maxAge` hardcoded 12h. | Driven by backend-returned TTLs; refresh cookie added (30d). |
| Middleware redirected to /login the moment the access token expired, even with a valid refresh token. | Middleware made refresh-aware: access invalid + refresh present → allow through; client interceptor renews. |

### Wrong paths
| Frontend called | Backend exposes | Fix |
|---|---|---|
| `GET/PATCH /auth/profile` | `/me` | frontend hook repointed to `/me` |
| `POST /auth/change-password` | `/me/password` | frontend hook repointed |
| `GET /sales/{id}/schedule` | (absent) | **added** to backend, shaped to `SaleSchedule` |

### Missing endpoints
| Call | Fix |
|---|---|
| `GET /ledger/summary` | **added** (aggregates debit/credit/count, integer dinars) |
| `DELETE /users/{id}` | backend never hard-deletes → frontend switched to `PATCH {is_active:false}` (`useDeactivateUser`, alias kept) |

## 3. Refresh-token design (implemented)

- Access JWT: `typ:"access"`, 120 min. Refresh JWT: `typ:"refresh"` + `jti`, 30 days.
- `decode_token` rejects refresh tokens; `decode_refresh_token` rejects access tokens (typ-guards, unit-tested both directions).
- `refresh_tokens` table is auth-plumbing (NOT RLS-scoped, same class as `users`), FK to users/tenants, `jti` unique, `revoked_at` for revocation. Grants: `SELECT, INSERT, UPDATE` to `ccs_app` — no DELETE (system never hard-deletes).
- `/auth/refresh` validates the registry row (exists, not revoked, not expired), then ROTATES: revokes the presented `jti` and issues a new pair. A leaked old refresh token cannot be replayed.
- `/auth/logout` revokes the presented `jti` (idempotent).
- Migration `c3d4e5f6a7b8` is self-contained (imports no app state) — migration immutability preserved.

## 4. Validation performed (in build env)
- All backend Python compiles; `import app.main` succeeds — **51 routes** registered.
- New routes present: `/auth/login`, `/auth/refresh`, `/auth/logout`, `/sales/{sale_id}/schedule`, `/ledger/summary`.
- Token unit tests pass: access/refresh round-trip, jti match, typ-guards reject cross-use both ways.
- `install.sh` passes `bash -n`; `nginx/aqsatt.conf` templated.

## 5. NOT yet done — requires your input or a server

### OPEN DECISION — ledger & payments list shape (financial semantics)
This is a genuine architectural divergence, not a typo, so it is left for an
explicit decision rather than guessed:

- **Ledger:** backend `GET /ledger` returns a **grouped, bare array**
  (`transaction_group_id`, `lines[]`, `total`). The frontend `ledger-table.tsx`
  consumes a **flat, paginated, enriched** model (`customer_name`, `entry_type`,
  `balance_after`). `balance_after` is a running per-row balance with real
  accounting meaning; `entry_type` is a derived classification. Fabricating
  these would violate the financial-safety rule.
  - Option A: rewrite backend `/ledger` to flat + paginated + enriched.
  - Option B: rewrite frontend ledger feature to the grouped model.
- **Payments:** backend `GET /payments` returns a bare array with
  `{receipt_number, fee_amount, paid_at, allocations}`; frontend `Payment`
  expects `{public_id, sale_number, customer_name, reference_number, source,
  created_at, created_by}`. Same fork: enrich backend vs realign frontend type.
- `GET /users` envelope wrap (low risk) is also pending — backend returns a bare
  array, frontend expects `Paginated<User>`.

### Server-only (cannot run in this build env)
- `alembic upgrade head` + seed against a live PostgreSQL.
- `npm ci && next build` / `tsc --noEmit` (frontend type/build check).
- End-to-end runtime: login → create sale → record payment → ledger → refresh after access expiry.
- Let's Encrypt certificate issuance (needs public DNS).

The installer performs all of the above on the target server and verifies each
step (service active, `/health` reachable, nginx config valid).
