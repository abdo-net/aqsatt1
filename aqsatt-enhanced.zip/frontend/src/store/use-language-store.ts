import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Language = "ar" | "en";

export const LANGUAGE_STORAGE_KEY = "aqsatt-language";

function applyLanguage(lang: Language) {
  if (typeof document !== "undefined") {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }
}

interface LanguageState {
  lang: Language;
  setLang: (lang: Language) => void;
  toggleLang: () => void;
}

export const useLanguageStore = create<LanguageState>()(
  persist(
    (set, get) => ({
      lang: "ar",
      setLang: (lang) => {
        applyLanguage(lang);
        set({ lang });
      },
      toggleLang: () => {
        const next: Language = get().lang === "ar" ? "en" : "ar";
        applyLanguage(next);
        set({ lang: next });
      },
    }),
    {
      name: LANGUAGE_STORAGE_KEY,
      onRehydrateStorage: () => (state) => {
        if (state) applyLanguage(state.lang);
      },
    }
  )
);
