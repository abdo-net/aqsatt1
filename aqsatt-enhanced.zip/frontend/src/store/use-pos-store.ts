import { create } from "zustand";

export interface CartItem {
  productId: number;
  variantId: number | null;
  name: string;
  variantName: string;
  priceCash: number;
  priceInstallment: number;
  quantity: number;
}

interface PosState {
  customerId: number | null;
  items: CartItem[];
  saleType: "cash" | "installment";
  downPayment: number;
  months: number;
  frequency: "weekly" | "monthly";
  startDate: string;
  discountAmount: number;
  notes: string;
  setCustomer: (id: number | null) => void;
  addItem: (item: Omit<CartItem, "quantity">) => void;
  updateQty: (variantId: number | null, productId: number, quantity: number) => void;
  removeItem: (variantId: number | null, productId: number) => void;
  setSaleType: (type: "cash" | "installment") => void;
  setDownPayment: (amount: number) => void;
  setMonths: (months: number) => void;
  setFrequency: (f: "weekly" | "monthly") => void;
  setStartDate: (d: string) => void;
  setDiscountAmount: (amount: number) => void;
  setNotes: (notes: string) => void;
  clearCart: () => void;
  subtotal: () => number;
  totalPrice: () => number;
  principal: () => number;
  baseInstallment: () => number;
  remainder: () => number;
}

export const usePosStore = create<PosState>((set, get) => ({
  customerId: null,
  items: [],
  saleType: "installment",
  downPayment: 0,
  months: 6,
  frequency: "monthly",
  startDate: new Date().toISOString().split("T")[0],
  discountAmount: 0,
  notes: "",

  setCustomer: (id) => set({ customerId: id }),
  addItem: (item) => {
    const existing = get().items.find(
      (i) => i.productId === item.productId && i.variantId === item.variantId
    );
    if (existing) {
      set({
        items: get().items.map((i) =>
          i.productId === item.productId && i.variantId === item.variantId
            ? { ...i, quantity: i.quantity + 1 }
            : i
        ),
      });
    } else {
      set({ items: [...get().items, { ...item, quantity: 1 }] });
    }
  },
  updateQty: (variantId, productId, quantity) => {
    if (quantity <= 0) {
      set({
        items: get().items.filter(
          (i) => !(i.productId === productId && i.variantId === variantId)
        ),
      });
    } else {
      set({
        items: get().items.map((i) =>
          i.productId === productId && i.variantId === variantId
            ? { ...i, quantity }
            : i
        ),
      });
    }
  },
  removeItem: (variantId, productId) => {
    set({
      items: get().items.filter(
        (i) => !(i.productId === productId && i.variantId === variantId)
      ),
    });
  },
  setSaleType: (type) => set({ saleType: type }),
  setDownPayment: (amount) => set({ downPayment: amount }),
  setMonths: (months) => set({ months }),
  setFrequency: (f) => set({ frequency: f }),
  setStartDate: (d) => set({ startDate: d }),
  setDiscountAmount: (amount) => set({ discountAmount: amount }),
  setNotes: (notes) => set({ notes }),
  clearCart: () =>
    set({
      items: [],
      customerId: null,
      downPayment: 0,
      discountAmount: 0,
      notes: "",
    }),
  subtotal: () => {
    return get().items.reduce((sum, item) => {
      const price = get().saleType === "cash" ? item.priceCash : item.priceInstallment;
      return sum + price * item.quantity;
    }, 0);
  },
  totalPrice: () => {
    return Math.max(0, get().subtotal() - get().discountAmount);
  },
  principal: () => {
    return Math.max(0, get().totalPrice() - get().downPayment);
  },
  baseInstallment: () => {
    const p = get().principal();
    return Math.floor(p / get().months);
  },
  remainder: () => {
    const p = get().principal();
    const base = Math.floor(p / get().months);
    return p - base * get().months;
  },
}));
