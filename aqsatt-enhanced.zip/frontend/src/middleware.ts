import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

const SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "dev-secret-change-me-32-chars-long");
const API_INTERNAL_URL = process.env.API_INTERNAL_URL || "http://127.0.0.1:8000";

// Routes that require specific permissions. /settings is intentionally absent —
// every authenticated user can view their own profile/password there; the
// users.manage-gated tab inside that page checks permissions itself.
const PERMISSION_MAP: Record<string, string[]> = {
  "/products": ["products.read", "products.write"],
};

type RefreshPayload = {
  access_token: string;
  refresh_token: string;
  access_expires_in: number;
  refresh_expires_in: number;
  permissions?: string[];
};

// Applies the permission-map + auth-route guards shared by both the
// fresh-token path and the post-refresh path. Returns a redirect response if
// a guard fires, otherwise null (caller falls through to NextResponse.next()).
function applyRouteGuards(
  pathname: string, base: string, isAuthRoute: boolean, perms: string[]
): NextResponse | null {
  for (const [routePrefix, requiredPerms] of Object.entries(PERMISSION_MAP)) {
    if (pathname.startsWith(routePrefix) && !requiredPerms.some((p) => perms.includes(p))) {
      return NextResponse.redirect(new URL("/", base));
    }
  }
  if (isAuthRoute) {
    return NextResponse.redirect(new URL("/", base));
  }
  return null;
}

function setAuthCookies(response: NextResponse, data: RefreshPayload, isSecure: boolean) {
  response.cookies.set({
    name: "aqsatt_access", value: data.access_token, httpOnly: true,
    secure: isSecure, sameSite: "lax", path: "/", maxAge: data.access_expires_in,
  });
  response.cookies.set({
    name: "aqsatt_refresh", value: data.refresh_token, httpOnly: true,
    secure: isSecure, sameSite: "lax", path: "/", maxAge: data.refresh_expires_in,
  });
}

// Mirrors app/api/auth/refresh/route.ts. Page navigations hit middleware, not
// that route handler, so without this an expired access token forced a full
// /login redirect on every nav even with a valid 30-day refresh token still
// sitting in the cookie jar — the API-call path (shared/api/client.ts) already
// refreshes silently on a 401; this brings page navigation to parity with it.
async function tryRefresh(refreshToken: string): Promise<RefreshPayload | null> {
  try {
    const r = await fetch(`${API_INTERNAL_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

export async function middleware(request: NextRequest) {
  const token = request.cookies.get("aqsatt_access")?.value;
  const pathname = request.nextUrl.pathname;
  const isAuthRoute = pathname.startsWith("/login");
  const isApiRoute = pathname.startsWith("/api/");

  // Build the redirect origin from the headers nginx actually forwards
  // (Host + X-Forwarded-Proto), not from request.url/nextUrl.origin. Behind a
  // custom/standalone Next.js server, those can resolve against the internal
  // 127.0.0.1:3000 connection nginx makes rather than the public Host header,
  // which is how a redirect ends up pointing at the loopback address instead
  // of the real domain. Headers are the one source that's unambiguous here.
  const host = request.headers.get("host") || request.nextUrl.host;
  const proto = request.headers.get("x-forwarded-proto") || "http";
  const base = `${proto}://${host}`;
  const isSecure = proto === "https";

  // Allow API routes and static files to pass through
  if (isApiRoute) {
    return NextResponse.next();
  }

  if (!token) {
    return isAuthRoute ? NextResponse.next() : NextResponse.redirect(new URL("/login", base));
  }

  try {
    const { payload } = await jwtVerify(token, SECRET, { clockTolerance: 60 });
    const perms = (payload.perms as string[]) || [];
    return applyRouteGuards(pathname, base, isAuthRoute, perms) ?? NextResponse.next();
  } catch {
    // Access token invalid or expired — attempt the same rotation the
    // API-call path already does silently before giving up. Worst case (the
    // refresh also fails or there's no refresh cookie) this falls through to
    // exactly the prior behavior: redirect to /login.
    const refreshToken = request.cookies.get("aqsatt_refresh")?.value;
    const refreshed = refreshToken ? await tryRefresh(refreshToken) : null;
    if (refreshed) {
      const response = applyRouteGuards(pathname, base, isAuthRoute, refreshed.permissions || []) ?? NextResponse.next();
      setAuthCookies(response, refreshed, isSecure);
      return response;
    }
    const response = NextResponse.redirect(new URL("/login", base));
    response.cookies.delete("aqsatt_access");
    response.cookies.delete("aqsatt_refresh");
    return response;
  }
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.png$|.*\\.jpg$|.*\\.svg$).*)"],
};
