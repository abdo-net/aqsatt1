"use client";
import { SalesTable } from "@/features/sales/components/sales-table";

export default function SalesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Sales</h1>
      <SalesTable />
    </div>
  );
}
