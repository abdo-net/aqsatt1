"use client";
import { useRef, useState } from "react";
import { useParams } from "next/navigation";
import {
  useProductDetail,
  useUpdateVariant,
  useUploadProductImages,
  useDeleteProductImage,
} from "@/features/products/hooks/use-products";
import { GlassCard } from "@/shared/ui/glass-card";
import { NeonButton } from "@/shared/ui/neon-button";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { Skeleton } from "@/shared/ui/skeleton";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import Link from "next/link";
import { ArrowRight, ImagePlus, Trash2, Pencil, Check, X } from "lucide-react";
import { toast } from "react-hot-toast";

export default function ProductDetailPage() {
  const params = useParams();
  const id = parseInt(params.id as string, 10);
  const { data, isLoading } = useProductDetail(id);
  const updateVariant = useUpdateVariant();
  const uploadImages = useUploadProductImages();
  const deleteImage = useDeleteProductImage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [editingVariant, setEditingVariant] = useState<number | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [editStock, setEditStock] = useState("");

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!data) {
    return <div className="text-center py-12 text-fg-muted">المنتج غير موجود.</div>;
  }

  const handleFilesSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    uploadImages.mutate(
      { productId: data.id, files },
      {
        onSuccess: () => toast.success("تم رفع الصور بنجاح"),
        onSettled: () => {
          if (fileInputRef.current) fileInputRef.current.value = "";
        },
      },
    );
  };

  const handleDeleteImage = (imageId: number) => {
    deleteImage.mutate({ productId: data.id, imageId }, { onSuccess: () => toast.success("تم حذف الصورة") });
  };

  const startEdit = (variantId: number) => {
    const v = data.variants.find((v) => v.id === variantId);
    if (!v) return;
    setEditingVariant(variantId);
    setEditPrice(String(v.price_cash));
    setEditStock(String(v.stock_quantity));
  };

  const handleUpdateVariant = (variantId: number) => {
    const v = data.variants.find((v) => v.id === variantId);
    if (!v) return;
    const price_cash = parseInt(editPrice);
    const stock_quantity = parseInt(editStock);
    updateVariant.mutate(
      {
        productId: data.id,
        variantId,
        data: {
          price_cash: Number.isNaN(price_cash) ? v.price_cash : price_cash,
          stock_quantity: Number.isNaN(stock_quantity) ? v.stock_quantity : stock_quantity,
        },
      },
      {
        onSuccess: () => {
          setEditingVariant(null);
          toast.success("تم تحديث المتغير");
        },
      },
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/products" className="text-fg-muted hover:text-white transition-colors">
          <ArrowRight className="h-5 w-5" />
        </Link>
        <h1 className="text-2xl font-bold tracking-tight text-white">{data.name_ar || data.name}</h1>
        <Badge variant={data.is_active ? "success" : "secondary"}>{data.status}</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">SKU</p>
          <p className="text-lg font-semibold text-white num-ltr">{data.sku}</p>
        </GlassCard>
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">الفئة</p>
          <p className="text-lg font-semibold text-white">{data.category?.name_ar || data.category?.name || "—"}</p>
        </GlassCard>
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">المخزون</p>
          <p className="text-lg font-semibold text-white num-ltr">{data.stock_quantity}</p>
        </GlassCard>
      </div>

      <GlassCard>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-white">الصور</h2>
          <input ref={fileInputRef} type="file" accept="image/*" multiple hidden onChange={handleFilesSelected} />
          <NeonButton
            size="sm"
            variant="cyan"
            leftIcon={<ImagePlus className="w-4 h-4" />}
            loading={uploadImages.isPending}
            onClick={() => fileInputRef.current?.click()}
          >
            رفع صور
          </NeonButton>
        </div>
        {data.images.length === 0 ? (
          <p className="text-sm text-fg-muted">لا توجد صور لهذا المنتج.</p>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {data.images.map((img) => (
              <div key={img.id} className="relative aspect-square rounded-xl overflow-hidden border border-white/10 group">
                <img src={img.thumb_path || img.path} alt="" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => handleDeleteImage(img.id)}
                  aria-label="حذف الصورة"
                  className="absolute top-1.5 left-1.5 p-1.5 rounded-lg bg-black/60 text-red-400 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </GlassCard>

      <GlassCard>
        <h2 className="font-semibold text-white mb-4">المتغيرات</h2>
        {data.variants.length === 0 ? (
          <p className="text-sm text-fg-muted">لا توجد متغيرات لهذا المنتج.</p>
        ) : (
          <div className="rounded-xl border border-white/10 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>SKU</TableHead>
                  <TableHead>الخصائص</TableHead>
                  <TableHead>سعر النقد</TableHead>
                  <TableHead>التقسيط</TableHead>
                  <TableHead>المخزون</TableHead>
                  <TableHead>افتراضي</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.variants.map((v) => {
                  const isEditing = editingVariant === v.id;
                  return (
                    <TableRow key={v.id}>
                      <TableCell className="font-medium num-ltr">{v.sku}</TableCell>
                      <TableCell>
                        {Object.entries(v.attributes || {}).map(([k, val]) => (
                          <span key={k} className="inline-flex items-center rounded-md bg-[rgba(37,99,235,0.1)] text-[#2563EB] px-2 py-0.5 text-xs mr-1">
                            {k}: {val}
                          </span>
                        ))}
                      </TableCell>
                      <TableCell>
                        {isEditing ? (
                          <input
                            type="number"
                            value={editPrice}
                            onChange={(e) => setEditPrice(e.target.value)}
                            className="input-cyber w-24 px-2 py-1 rounded-lg text-white num-ltr"
                          />
                        ) : (
                          <Num currency>{v.price_cash}</Num>
                        )}
                      </TableCell>
                      <TableCell><Num currency>{v.price_installment}</Num></TableCell>
                      <TableCell>
                        {isEditing ? (
                          <input
                            type="number"
                            value={editStock}
                            onChange={(e) => setEditStock(e.target.value)}
                            className="input-cyber w-20 px-2 py-1 rounded-lg text-white num-ltr"
                          />
                        ) : (
                          v.stock_quantity
                        )}
                      </TableCell>
                      <TableCell>{v.is_default ? "نعم" : "لا"}</TableCell>
                      <TableCell>
                        {isEditing ? (
                          <div className="flex gap-1">
                            <button onClick={() => handleUpdateVariant(v.id)} className="p-1.5 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20">
                              <Check className="w-4 h-4" />
                            </button>
                            <button onClick={() => setEditingVariant(null)} className="p-1.5 rounded-lg bg-white/5 text-fg-muted hover:bg-white/10">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <button onClick={() => startEdit(v.id)} className="p-1.5 rounded-lg bg-white/5 text-fg-muted hover:bg-[rgba(37,99,235,0.1)] hover:text-[#2563EB]">
                            <Pencil className="w-4 h-4" />
                          </button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </GlassCard>
    </div>
  );
}
