"use client";
import { useState } from "react";
import { useProducts, useCreateProduct } from "@/features/products/hooks/use-products";
import { useCategories } from "@/features/products/hooks/use-categories";
import { ProductCard as ProductCardComponent } from "@/features/products/components/product-card";
import { ProductForm } from "@/features/products/components/product-form";
import { NeonButton } from "@/shared/ui/neon-button";
import { EmptyState, TableSkeleton } from "@/shared/ui/empty-state";
import { Plus, ChevronRight, ChevronLeft, Package, Search } from "lucide-react";
import { toast } from "react-hot-toast";

export default function ProductsPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [formOpen, setFormOpen] = useState(false);
  const pageSize = 20;

  const { data, isLoading } = useProducts({
    page,
    page_size: pageSize,
    q: search || undefined,
    category_id: categoryId ? parseInt(categoryId) : undefined,
  });
  const { data: categories } = useCategories();
  const createProduct = useCreateProduct();

  const products = data?.data || [];
  const totalPages = data?.total_pages || 1;

  const handleCreate = (data: unknown) => {
    createProduct.mutate(data as Parameters<typeof createProduct.mutate>[0], {
      onSuccess: () => {
        setFormOpen(false);
        toast.success("تم إضافة المنتج بنجاح");
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight text-white">المنتجات</h1>
        <NeonButton variant="purple" leftIcon={<Plus className="w-4 h-4" />} onClick={() => setFormOpen(true)}>
          منتج جديد
        </NeonButton>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <input
            placeholder="بحث عن منتج..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="input-cyber w-64 px-4 py-2.5 pr-10 rounded-xl text-white placeholder:text-white/30"
          />
          <Search className="w-4 h-4 text-fg-faint absolute right-3.5 top-1/2 -translate-y-1/2" />
        </div>
        <select
          value={categoryId}
          onChange={(e) => { setCategoryId(e.target.value); setPage(1); }}
          className="input-cyber px-4 py-2.5 rounded-xl text-white bg-bg-elevated appearance-none w-44"
        >
          <option value="" className="bg-bg-elevated">كل الفئات</option>
          {categories?.map((c) => (
            <option key={c.id} value={c.id} className="bg-bg-elevated">{c.name_ar || c.name}</option>
          ))}
        </select>
      </div>

      {isLoading ? (
        <TableSkeleton rows={4} cols={4} />
      ) : products.length === 0 ? (
        <EmptyState icon={Package} title="لا توجد منتجات" description="ابدأ بإضافة أول منتج" actionLabel="منتج جديد" onAction={() => setFormOpen(true)} accent="purple" />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCardComponent key={p.id} product={p} />
            ))}
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-fg-muted num-ltr">{page} / {totalPages}</div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="p-2 rounded-lg glass-cyber disabled:opacity-30 hover:bg-white/5 transition-colors"
              >
                <ChevronRight className="h-4 w-4 text-fg-secondary" />
              </button>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
                className="p-2 rounded-lg glass-cyber disabled:opacity-30 hover:bg-white/5 transition-colors"
              >
                <ChevronLeft className="h-4 w-4 text-fg-secondary" />
              </button>
            </div>
          </div>
        </>
      )}

      <ProductForm open={formOpen} onOpenChange={setFormOpen} onSubmit={handleCreate} isLoading={createProduct.isPending} />
    </div>
  );
}
