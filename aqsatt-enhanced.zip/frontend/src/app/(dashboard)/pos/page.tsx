"use client";
import { useState } from "react";
import { usePosStore } from "@/store/use-pos-store";
import { ProductCatalog } from "@/features/sales/components/product-catalog";
import { CartPanel } from "@/features/sales/components/cart-panel";
import { CheckoutDrawer } from "@/features/sales/components/checkout-drawer";
import { Sheet, SheetContent, SheetTrigger } from "@/shared/ui/sheet";
import { ShoppingCart } from "lucide-react";

export default function PosPage() {
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const store = usePosStore();

  const handleAddToCart = (
    productId: number,
    variantId: number | null,
    priceCash: number,
    priceInstallment: number,
    name: string,
    variantName: string,
  ) => {
    store.addItem({ productId, variantId, name, variantName, priceCash, priceInstallment });
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col lg:flex-row gap-4 -m-4 lg:-m-6 p-4 lg:p-6">
      <div className="flex-1 overflow-auto min-h-0">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold tracking-tight text-white">نقطة البيع</h1>
          <Sheet open={cartOpen} onOpenChange={setCartOpen}>
            <SheetTrigger asChild>
              <button className="lg:hidden relative p-2.5 rounded-xl glass-cyber">
                <ShoppingCart className="h-5 w-5 text-[#2563EB]" />
                {store.items.length > 0 && (
                  <span className="absolute -top-1 -left-1 h-4 w-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                    {store.items.length}
                  </span>
                )}
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh] bg-[#0F172A] border-white/10">
              <CartPanel onCheckout={() => { setCartOpen(false); setCheckoutOpen(true); }} />
            </SheetContent>
          </Sheet>
        </div>
        <ProductCatalog onSelect={handleAddToCart} />
      </div>

      <div className="hidden lg:block w-[380px] shrink-0">
        <CartPanel onCheckout={() => setCheckoutOpen(true)} />
      </div>

      <CheckoutDrawer open={checkoutOpen} onOpenChange={setCheckoutOpen} onSuccess={() => {}} />
    </div>
  );
}
