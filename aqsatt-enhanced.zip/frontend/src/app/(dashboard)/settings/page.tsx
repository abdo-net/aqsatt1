"use client";
import { ProfileForm } from "@/features/settings/components/profile-form";
import { PasswordForm } from "@/features/settings/components/password-form";
import { UserManagement } from "@/features/settings/components/user-management";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/shared/ui/tabs";

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
      <Tabs defaultValue="profile">
        <TabsList>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="password">Password</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>
        <TabsContent value="profile" className="mt-4 max-w-lg">
          <ProfileForm />
        </TabsContent>
        <TabsContent value="password" className="mt-4 max-w-lg">
          <PasswordForm />
        </TabsContent>
        <TabsContent value="users" className="mt-4">
          <UserManagement />
        </TabsContent>
      </Tabs>
    </div>
  );
}
