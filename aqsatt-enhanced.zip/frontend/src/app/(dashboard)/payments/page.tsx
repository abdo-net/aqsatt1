"use client";
import { useMemo, useState } from "react";
import { PaymentHistory } from "@/features/payments/components/payment-history";
import { PaymentModal } from "@/features/payments/components/payment-modal";
import { useSales } from "@/features/sales/hooks/use-sales";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { Button } from "@/shared/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/shared/ui/select";
import { Plus } from "lucide-react";

export default function PaymentsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSaleId, setSelectedSaleId] = useState<number | null>(null);
  const { data: sales } = useSales({ page: 1, page_size: 100, status: "active" });
  const { data: customers } = useCustomers({ page: 1, page_size: 100 });
  const customerNames = useMemo(() => {
    const map = new Map<number, string>();
    customers?.data.forEach((c) => map.set(c.id, c.full_name));
    return map;
  }, [customers]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Payments</h1>
        <div className="flex items-center gap-3">
          <Select value={selectedSaleId?.toString() || ""} onValueChange={(v) => setSelectedSaleId(v ? parseInt(v) : null)}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Select sale to pay..." />
            </SelectTrigger>
            <SelectContent>
              {sales?.data.map((s) => (
                <SelectItem key={s.id} value={s.id.toString()}>
                  {s.sale_number} — {customerNames.get(s.customer_id) ?? "—"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => setModalOpen(true)} disabled={!selectedSaleId}>
            <Plus className="mr-2 h-4 w-4" />
            Record Payment
          </Button>
        </div>
      </div>
      <PaymentHistory />
      <PaymentModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        saleId={selectedSaleId}
      />
    </div>
  );
}
