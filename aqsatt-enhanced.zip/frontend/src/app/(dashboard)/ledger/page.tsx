"use client";
import { LedgerTable } from "@/features/ledger/components/ledger-table";

export default function LedgerPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Ledger</h1>
      <LedgerTable />
    </div>
  );
}
