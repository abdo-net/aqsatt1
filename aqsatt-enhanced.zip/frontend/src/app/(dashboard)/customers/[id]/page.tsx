"use client";
import { useParams } from "next/navigation";
import { useCustomerDetail } from "@/features/customers/hooks/use-customers";
import { DebtProgressBar } from "@/features/customers/components/debt-progress-bar";
import { PaymentModal } from "@/features/payments/components/payment-modal";
import { GlassCard } from "@/shared/ui/glass-card";
import { NeonButton } from "@/shared/ui/neon-button";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { Skeleton } from "@/shared/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/shared/ui/tabs";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { formatDate } from "@/shared/lib/formatters";
import Link from "next/link";
import { ArrowRight, Wallet } from "lucide-react";
import { useState } from "react";

export default function CustomerDetailPage() {
  const params = useParams();
  const id = parseInt(params.id as string, 10);
  const { data, isLoading } = useCustomerDetail(id);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedSaleId, setSelectedSaleId] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!data) {
    return <div className="text-center py-12 text-fg-muted">العميل غير موجود.</div>;
  }

  const paid = data.sales.reduce((sum, s) => sum + s.schedule.reduce((sSum, inst) => sSum + inst.paid, 0), 0);
  const upcoming = data.sales.reduce((sum, s) => sum + s.schedule.reduce((sSum, inst) => sSum + (inst.status === "pending" ? inst.amount : 0), 0), 0);
  const overdue = data.sales.reduce((sum, s) => sum + s.schedule.reduce((sSum, inst) => sSum + (inst.status === "late" || inst.status === "partially_paid" ? inst.remaining : 0), 0), 0);

  const activeSales = data.sales.filter((s) => s.status === "active");

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/customers" className="text-fg-muted hover:text-white transition-colors">
          <ArrowRight className="h-5 w-5" />
        </Link>
        <h1 className="text-2xl font-bold tracking-tight text-white">{data.full_name}</h1>
        {data.is_overdue ? <Badge variant="destructive">متأخر</Badge> : <Badge variant="success">منتظم</Badge>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">الهاتف</p>
          <p className="text-lg font-semibold text-white num-ltr" dir="ltr">{data.phone}</p>
        </GlassCard>
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">نوع العميل</p>
          <p className="text-lg font-semibold text-white">
            {data.customer_type === "guarantor" ? "كفيل (بطاقة كي)" : "بدون كفيل"}
          </p>
        </GlassCard>
        <GlassCard padding="sm">
          <p className="text-xs text-fg-muted mb-1">الرصيد المستحق</p>
          <p className="text-lg font-semibold text-white"><Num currency>{data.receivable_balance}</Num></p>
        </GlassCard>
      </div>

      <DebtProgressBar paidFils={paid} upcomingFils={upcoming} overdueFils={overdue} />

      <Tabs defaultValue="sales">
        <TabsList>
          <TabsTrigger value="sales">المبيعات</TabsTrigger>
          <TabsTrigger value="schedule">جدول الأقساط</TabsTrigger>
        </TabsList>
        <TabsContent value="sales" className="mt-4">
          {activeSales.length === 0 ? (
            <p className="text-fg-muted">لا توجد مبيعات نشطة.</p>
          ) : (
            <div className="rounded-xl border border-white/10 overflow-hidden glass-cyber">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم البيع</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead className="w-32">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeSales.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium num-ltr">{s.sale_number}</TableCell>
                      <TableCell>{s.type === "cash" ? "نقدي" : "تقسيط"}</TableCell>
                      <TableCell className="text-white"><Num currency>{s.total_price}</Num></TableCell>
                      <TableCell>
                        <Badge variant={s.status === "active" ? "default" : s.status === "completed" ? "success" : "secondary"}>
                          {s.status === "active" ? "نشط" : s.status === "completed" ? "مكتمل" : "ملغي"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <NeonButton size="sm" variant="green" leftIcon={<Wallet className="h-3.5 w-3.5" />} onClick={() => { setSelectedSaleId(s.id); setPaymentModalOpen(true); }}>
                          دفع
                        </NeonButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        <TabsContent value="schedule" className="mt-4">
          {data.sales.flatMap((s) => s.schedule).length === 0 ? (
            <p className="text-fg-muted">لا توجد أقساط.</p>
          ) : (
            <div className="rounded-xl border border-white/10 overflow-hidden glass-cyber">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>تاريخ الاستحقاق</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>مدفوع</TableHead>
                    <TableHead>المتبقي</TableHead>
                    <TableHead>الحالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.sales.flatMap((s) => s.schedule).map((inst, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="num-ltr">{inst.installment_number}</TableCell>
                      <TableCell className="text-fg-secondary">{formatDate(inst.due_date)}</TableCell>
                      <TableCell><Num currency>{inst.amount}</Num></TableCell>
                      <TableCell className="text-fg-secondary"><Num currency>{inst.paid}</Num></TableCell>
                      <TableCell className="text-white font-medium"><Num currency>{inst.remaining}</Num></TableCell>
                      <TableCell>
                        <Badge variant={inst.status === "paid" ? "success" : inst.status === "late" ? "destructive" : inst.status === "partially_paid" ? "warning" : "default"}>
                          {inst.status === "paid" ? "مدفوع" : inst.status === "late" ? "متأخر" : inst.status === "partially_paid" ? "جزئي" : inst.status === "cancelled" ? "ملغي" : "قادم"}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <PaymentModal open={paymentModalOpen} onOpenChange={setPaymentModalOpen} saleId={selectedSaleId} />
    </div>
  );
}
