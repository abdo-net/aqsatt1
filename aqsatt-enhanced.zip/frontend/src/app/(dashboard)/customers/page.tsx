"use client";
import { useState } from "react";
import { CustomerTable } from "@/features/customers/components/customer-table";
import { CustomerForm } from "@/features/customers/components/customer-form";
import { NeonButton } from "@/shared/ui/neon-button";
import { useCreateCustomer, useUpdateCustomer, type Customer } from "@/features/customers/hooks/use-customers";
import { Plus } from "lucide-react";
import { toast } from "react-hot-toast";

export default function CustomersPage() {
  const [formOpen, setFormOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const createCustomer = useCreateCustomer();
  const updateCustomer = useUpdateCustomer();

  const handleCreate = (data: unknown) => {
    createCustomer.mutate(data as Parameters<typeof createCustomer.mutate>[0], {
      onSuccess: () => {
        setFormOpen(false);
        toast.success("تم إضافة العميل بنجاح");
      },
    });
  };

  const handleUpdate = (data: unknown) => {
    if (!editingCustomer) return;
    updateCustomer.mutate(
      { id: editingCustomer.id, data: data as Parameters<typeof updateCustomer.mutate>[0]["data"] },
      {
        onSuccess: () => {
          setFormOpen(false);
          setEditingCustomer(null);
          toast.success("تم تحديث العميل بنجاح");
        },
      },
    );
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormOpen(true);
  };

  const handleOpenChange = (open: boolean) => {
    setFormOpen(open);
    if (!open) setEditingCustomer(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight text-white">العملاء</h1>
        <NeonButton variant="cyan" leftIcon={<Plus className="w-4 h-4" />} onClick={() => { setEditingCustomer(null); setFormOpen(true); }}>
          عميل جديد
        </NeonButton>
      </div>
      <CustomerTable onEdit={handleEdit} />
      <CustomerForm
        open={formOpen}
        onOpenChange={handleOpenChange}
        customer={editingCustomer}
        onSubmit={editingCustomer ? handleUpdate : handleCreate}
        isLoading={createCustomer.isPending || updateCustomer.isPending}
      />
    </div>
  );
}
