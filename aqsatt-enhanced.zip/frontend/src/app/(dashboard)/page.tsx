"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";
import { Topbar } from "@/components/shell/topbar";
import { useProfile } from "@/features/settings/hooks/use-settings";
import { DashboardKpis } from "@/features/analytics/components/dashboard-kpis";
import { QuickActions, type QuickActionKey } from "@/features/analytics/components/quick-actions";
import { RecentSales } from "@/features/analytics/components/recent-sales";
import { CashflowChart } from "@/features/analytics/components/cashflow-chart";
import { RiskSegmentation } from "@/features/analytics/components/risk-segmentation";
import { OverdueAccounts } from "@/features/analytics/components/overdue-accounts";
import { StatsMini } from "@/features/analytics/components/stats-mini";
import { CustomerForm } from "@/features/customers/components/customer-form";
import { useCreateCustomer } from "@/features/customers/hooks/use-customers";
import { ProductForm } from "@/features/products/components/product-form";
import { useCreateProduct } from "@/features/products/hooks/use-products";
import { QuickSaleModal } from "@/features/sales/components/quick-sale-modal";
import { SaleDetailModal } from "@/features/sales/components/sale-detail-modal";
import type { SaleListItem } from "@/features/sales/hooks/use-sales";

export default function DashboardPage() {
  const router = useRouter();
  const { data: profile } = useProfile();

  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [saleModalOpen, setSaleModalOpen] = useState(false);
  const [detailSaleId, setDetailSaleId] = useState<number | null>(null);

  const createCustomer = useCreateCustomer();
  const createProduct = useCreateProduct();

  const handleQuickAction = (key: QuickActionKey) => {
    if (key === "customer") setCustomerModalOpen(true);
    else if (key === "product") setProductModalOpen(true);
    else if (key === "sale") setSaleModalOpen(true);
    else if (key === "payment") router.push("/payments");
  };

  const handleCreateCustomer = (data: unknown) => {
    createCustomer.mutate(data as Parameters<typeof createCustomer.mutate>[0], {
      onSuccess: () => {
        setCustomerModalOpen(false);
        toast.success("تم إضافة العميل بنجاح");
      },
    });
  };

  const handleCreateProduct = (data: unknown) => {
    createProduct.mutate(data as Parameters<typeof createProduct.mutate>[0], {
      onSuccess: () => {
        setProductModalOpen(false);
        toast.success("تم إضافة المنتج بنجاح");
      },
    });
  };

  return (
    <div className="-m-4 lg:-m-6 pb-12">
      <Topbar userName={profile?.name} onQuickAdd={() => setSaleModalOpen(true)} />

      <div className="px-4 lg:px-8 space-y-6">
        <DashboardKpis />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <QuickActions onAction={handleQuickAction} className="lg:col-span-2" />
          <StatsMini />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <CashflowChart />
          <RiskSegmentation />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <RecentSales onRowClick={(sale: SaleListItem) => setDetailSaleId(sale.id)} />
          <OverdueAccounts />
        </div>
      </div>

      <CustomerForm
        open={customerModalOpen}
        onOpenChange={setCustomerModalOpen}
        onSubmit={handleCreateCustomer}
        isLoading={createCustomer.isPending}
      />
      <ProductForm
        open={productModalOpen}
        onOpenChange={setProductModalOpen}
        onSubmit={handleCreateProduct}
        isLoading={createProduct.isPending}
      />
      <QuickSaleModal open={saleModalOpen} onOpenChange={setSaleModalOpen} />
      <SaleDetailModal
        open={detailSaleId !== null}
        onOpenChange={(open) => !open && setDetailSaleId(null)}
        saleId={detailSaleId}
        onRecordPayment={() => router.push("/payments")}
      />
    </div>
  );
}
