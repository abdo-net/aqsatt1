"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginInput } from "@/shared/lib/zod-schemas";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Label } from "@/shared/ui/label";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/shared/ui/card";
import axios from "axios";
import { toast } from "react-hot-toast";
import { useT } from "@/shared/lib/i18n-dict";

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const { t } = useT();
  const { register, handleSubmit, formState: { errors } } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginInput) => {
    setLoading(true);
    try {
      await axios.post("/api/auth/login", data, { withCredentials: true });
      window.location.href = "/";
    } catch (err) {
      // This call intentionally uses the raw axios import, not the shared
      // apiClient instance — its interceptors are scoped to that instance and
      // never run for this request, so errors must be surfaced here directly
      // or they fail silently (confirmed: this was previously an empty catch).
      const errBody = axios.isAxiosError(err) ? (err.response?.data as { detail?: string; error?: string } | undefined) : undefined;
      toast.error(errBody?.detail || errBody?.error || t("login.failed"));
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader className="text-center px-4 sm:px-6">
        <CardTitle className="text-2xl">{t("login.appName")}</CardTitle>
        <CardDescription>{t("login.tagline")}</CardDescription>
      </CardHeader>
      <CardContent className="px-4 sm:px-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username">{t("login.username")}</Label>
            <Input id="username" className="h-11 text-base" {...register("username")} />
            {errors.username && <p className="text-xs text-red-600">{errors.username.message}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">{t("login.password")}</Label>
            <Input id="password" type="password" className="h-11 text-base" {...register("password")} />
            {errors.password && <p className="text-xs text-red-600">{errors.password.message}</p>}
          </div>
          <Button type="submit" className="w-full h-11 text-base" loading={loading}>{t("login.submit")}</Button>
        </form>
      </CardContent>
    </Card>
  );
}
