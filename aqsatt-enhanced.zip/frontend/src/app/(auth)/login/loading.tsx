import { Skeleton } from "@/shared/ui/skeleton";

export default function LoginLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-md space-y-4">
        <Skeleton className="h-12 w-32 mx-auto" />
        <Skeleton className="h-64" />
      </div>
    </div>
  );
}
