import { NextResponse } from "next/server";
import { cookies } from "next/headers";

const API_INTERNAL_URL = process.env.API_INTERNAL_URL || "http://127.0.0.1:8000";

export async function POST(request: Request) {
  const cookieStore = cookies();
  const refreshToken = cookieStore.get("aqsatt_refresh")?.value;
  const isSecure = request.headers.get("x-forwarded-proto") === "https";

  if (refreshToken) {
    try {
      await fetch(`${API_INTERNAL_URL}/api/v1/auth/logout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });
    } catch {
      // best-effort revoke; cookies are cleared regardless
    }
  }

  cookieStore.delete("aqsatt_access");
  cookieStore.set({ name: "aqsatt_refresh", value: "", path: "/", maxAge: 0, secure: isSecure });
  return NextResponse.json({ success: true });
}
