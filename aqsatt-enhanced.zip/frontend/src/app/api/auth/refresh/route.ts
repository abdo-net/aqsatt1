import { NextResponse } from "next/server";
import { cookies } from "next/headers";

const API_INTERNAL_URL = process.env.API_INTERNAL_URL || "http://127.0.0.1:8000";

function clearAuthCookies(isSecure: boolean) {
  const cookieStore = cookies();
  cookieStore.delete("aqsatt_access");
  cookieStore.set({ name: "aqsatt_refresh", value: "", path: "/", maxAge: 0, secure: isSecure });
}

export async function POST(request: Request) {
  const cookieStore = cookies();
  const refreshToken = cookieStore.get("aqsatt_refresh")?.value;
  if (!refreshToken) {
    return NextResponse.json({ error: "No refresh token" }, { status: 401 });
  }
  const isSecure = request.headers.get("x-forwarded-proto") === "https";

  try {
    const backendResponse = await fetch(`${API_INTERNAL_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });

    if (!backendResponse.ok) {
      clearAuthCookies(isSecure);
      return NextResponse.json({ error: "Refresh rejected" }, { status: 401 });
    }

    const data = await backendResponse.json();

    cookieStore.set({
      name: "aqsatt_access",
      value: data.access_token,
      httpOnly: true,
      secure: isSecure,
      sameSite: "lax",
      path: "/",
      maxAge: data.access_expires_in,
    });
    cookieStore.set({
      name: "aqsatt_refresh",
      value: data.refresh_token,
      httpOnly: true,
      secure: isSecure,
      sameSite: "lax",
      path: "/",
      maxAge: data.refresh_expires_in,
    });

    return NextResponse.json({ success: true });
  } catch {
    clearAuthCookies(isSecure);
    return NextResponse.json({ error: "Refresh failed" }, { status: 401 });
  }
}
