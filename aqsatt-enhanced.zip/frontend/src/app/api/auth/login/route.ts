import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";

const API_INTERNAL_URL = process.env.API_INTERNAL_URL || "http://127.0.0.1:8000";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const backendResponse = await fetch(`${API_INTERNAL_URL}/api/v1/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!backendResponse.ok) {
      return NextResponse.json(await backendResponse.json(), { status: backendResponse.status });
    }

    const data = await backendResponse.json();
    const cookieStore = cookies();
    // Secure must reflect the connection the BROWSER actually used, not NODE_ENV —
    // browsers silently drop Secure cookies set over a plain-HTTP response. nginx
    // forwards the real scheme via X-Forwarded-Proto (http pre-certbot, https after).
    const isSecure = request.headers.get("x-forwarded-proto") === "https";

    // Access token: readable by the proxy + middleware, lifetime = backend access TTL.
    cookieStore.set({
      name: "aqsatt_access",
      value: data.access_token,
      httpOnly: true,
      secure: isSecure,
      sameSite: "lax",
      path: "/",
      maxAge: data.access_expires_in,
    });
    // Refresh token: only ever sent to /api/auth/refresh + /api/auth/logout.
    cookieStore.set({
      name: "aqsatt_refresh",
      value: data.refresh_token,
      httpOnly: true,
      secure: isSecure,
      sameSite: "lax",
      path: "/",
      maxAge: data.refresh_expires_in,
    });

    return NextResponse.json({
      success: true,
      user: { id: data.user_id, name: body.username, permissions: data.permissions },
    });
  } catch {
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
