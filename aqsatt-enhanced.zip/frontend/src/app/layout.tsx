import type { Metadata } from "next";
import { Exo_2, IBM_Plex_Sans_Arabic } from "next/font/google";
import "./globals.css";
import { Toaster } from "react-hot-toast";
import { Providers } from "./providers";

const exo2 = Exo_2({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  variable: "--font-exo",
  display: "swap",
});

const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-arabic",
  display: "swap",
});

export const metadata: Metadata = {
  title: "أقساط - نظام إدارة التقسيط",
  description: "نظام إدارة التجارة الائتمانية والتقسيط",
};

// Runs before hydration so a previously-chosen theme/language applies
// instantly on load instead of flashing the dark/Arabic default first.
const THEME_LANG_INIT_SCRIPT = `(function(){try{
  var t=JSON.parse(localStorage.getItem('aqsatt-theme')||'null');
  if(t&&t.state&&t.state.theme){document.documentElement.setAttribute('data-theme',t.state.theme);}
  var l=JSON.parse(localStorage.getItem('aqsatt-language')||'null');
  if(l&&l.state&&l.state.lang){document.documentElement.lang=l.state.lang;document.documentElement.dir=l.state.lang==='ar'?'rtl':'ltr';}
}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      data-theme="dark"
      suppressHydrationWarning
      className={`${exo2.variable} ${ibmPlexArabic.variable}`}
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_LANG_INIT_SCRIPT }} />
      </head>
      <body>
        <Providers>{children}</Providers>
        <Toaster position="top-center" toastOptions={{ duration: 4000 }} />
      </body>
    </html>
  );
}
