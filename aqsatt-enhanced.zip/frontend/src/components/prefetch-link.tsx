"use client";
import Link from "next/link";
import { useQueryClient } from "@tanstack/react-query";
import { type ComponentProps } from "react";

type PrefetchLinkProps = ComponentProps<typeof Link> & {
  queryKey?: string[];
};

export function PrefetchLink({ queryKey, ...props }: PrefetchLinkProps) {
  const queryClient = useQueryClient();
  return (
    <Link
      {...props}
      onMouseEnter={(e) => {
        if (queryKey) {
          queryClient.prefetchQuery({ queryKey });
        }
        props.onMouseEnter?.(e);
      }}
    />
  );
}
