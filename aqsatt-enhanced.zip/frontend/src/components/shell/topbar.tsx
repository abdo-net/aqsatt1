'use client';

/**
 * Topbar — Dashboard hero greeting + search stub + quick-add button.
 * Rendered only from the dashboard page itself (its content is page-specific,
 * not generic chrome) — other routes keep the shared layout's plain header.
 */
import * as React from 'react';
import { Search, Plus, Bell } from 'lucide-react';
import { NeonButton } from '@/shared/ui/neon-button';
import { useT } from '@/shared/lib/i18n-dict';

type Props = {
  userName?: string;
  notificationCount?: number;
  onQuickAdd?: () => void;
  onNotificationsClick?: () => void;
  onSearchSubmit?: (q: string) => void;
};

export function Topbar({
  userName,
  notificationCount = 0,
  onQuickAdd,
  onNotificationsClick,
  onSearchSubmit,
}: Props) {
  const [q, setQ] = React.useState('');
  const { t } = useT();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit?.(q);
  };

  return (
    <header className="px-4 sm:px-6 py-5 sm:py-6 relative">
      <div className="flex items-center justify-between gap-6 flex-wrap">
        {/* Greeting */}
        <div>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold text-fg-primary mb-1">
            {t('topbar.greeting', { name: userName ?? t('topbar.defaultUser') })} 👋
          </h1>
          <p className="text-fg-muted">{t('topbar.subtitle')}</p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 flex-wrap">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t('topbar.searchPlaceholder')}
              className="w-64 px-4 py-2.5 pr-10 rounded-lg input-cyber text-fg-primary placeholder:text-fg-faint"
            />
            <Search className="w-4 h-4 text-fg-faint absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </form>

          <button
            type="button"
            onClick={onNotificationsClick}
            aria-label={t('topbar.notifications', { count: notificationCount })}
            className="relative p-2.5 rounded-lg border border-[var(--border-subtle)] hover:bg-overlay-subtle transition-colors"
          >
            <Bell className="w-5 h-5 text-fg-muted" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[18px] h-[18px] px-1 bg-[#EF4444] rounded-full text-[10px] font-bold flex items-center justify-center">
                <span className="num-ltr">{notificationCount}</span>
              </span>
            )}
          </button>

          {onQuickAdd && (
            <NeonButton variant="cyan" onClick={onQuickAdd} leftIcon={<Plus className="w-4 h-4" />}>
              {t('topbar.quickAdd')}
            </NeonButton>
          )}
        </div>
      </div>
    </header>
  );
}
