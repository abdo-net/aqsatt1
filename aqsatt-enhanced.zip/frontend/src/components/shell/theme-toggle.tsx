"use client";

import * as React from "react";
import { Moon, Sun, Droplet } from "lucide-react";
import { cn } from "@/shared/lib/utils";
import { useThemeStore, type Theme } from "@/store/use-theme-store";

const OPTIONS: { value: Theme; icon: typeof Moon; label: string }[] = [
  { value: "dark", icon: Moon, label: "Dark" },
  { value: "light", icon: Sun, label: "Light" },
  { value: "soft-blue", icon: Droplet, label: "Soft blue" },
];

export function ThemeToggle() {
  const { theme, setTheme } = useThemeStore();

  return (
    <div
      role="group"
      aria-label="Theme"
      className="inline-flex items-center gap-0.5 rounded-lg border border-[var(--border-subtle)] bg-bg-input p-0.5"
    >
      {OPTIONS.map(({ value, icon: Icon, label }) => {
        const active = theme === value;
        return (
          <button
            key={value}
            type="button"
            title={label}
            aria-label={label}
            aria-pressed={active}
            onClick={() => setTheme(value)}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-md transition-colors",
              active ? "bg-[#2563EB] text-white" : "text-fg-muted hover:bg-overlay hover:text-fg-primary"
            )}
          >
            <Icon className="h-4 w-4" />
          </button>
        );
      })}
    </div>
  );
}
