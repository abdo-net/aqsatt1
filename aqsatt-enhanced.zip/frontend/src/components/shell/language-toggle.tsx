"use client";

import * as React from "react";
import { Languages } from "lucide-react";
import { useLanguageStore } from "@/store/use-language-store";

export function LanguageToggle() {
  const { lang, toggleLang } = useLanguageStore();

  return (
    <button
      type="button"
      onClick={toggleLang}
      title={lang === "ar" ? "Switch to English" : "التبديل إلى العربية"}
      aria-label="Toggle language"
      className="flex h-9 items-center gap-1.5 rounded-lg border border-[var(--border-subtle)] bg-bg-input px-3 text-sm font-medium text-fg-muted transition-colors hover:text-fg-primary"
    >
      <Languages className="h-4 w-4" />
      <span className="num-ltr">{lang === "ar" ? "EN" : "AR"}</span>
    </button>
  );
}
