'use client';

/**
 * Sidebar — flat dark navigation, RTL-aware (sidebar on the right).
 * Permission gating reads from GET /me permissions[] (mirrors backend enforcement).
 */
import * as React from 'react';
import { usePathname } from 'next/navigation';
import axios from 'axios';
import {
  Home,
  Users,
  Package,
  Receipt,
  ShoppingCart,
  Wallet,
  BookOpen,
  Settings,
  LogOut,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '@/shared/lib/utils';
import { PrefetchLink } from '@/components/prefetch-link';
import { useProfile } from '@/features/settings/hooks/use-settings';
import { useT, type DictKey } from '@/shared/lib/i18n-dict';

type NavItem = {
  href: string;
  labelKey: DictKey;
  icon: LucideIcon;
  /** Optional permission key; if omitted, always visible */
  permission?: string;
  queryKey: string[];
};

const navItems: NavItem[] = [
  { href: '/', labelKey: 'sidebar.dashboard', icon: Home, queryKey: ['dashboard', 'summary'] },
  { href: '/customers', labelKey: 'sidebar.customers', icon: Users, permission: 'customers.read', queryKey: ['customers', 'list'] },
  { href: '/products', labelKey: 'sidebar.products', icon: Package, permission: 'products.read', queryKey: ['products', 'list'] },
  { href: '/pos', labelKey: 'sidebar.pos', icon: Receipt, queryKey: ['products', 'list'] },
  { href: '/sales', labelKey: 'sidebar.sales', icon: ShoppingCart, permission: 'sales.read', queryKey: ['sales', 'list'] },
  { href: '/payments', labelKey: 'sidebar.payments', icon: Wallet, permission: 'payments.read', queryKey: ['payments', 'list'] },
  { href: '/ledger', labelKey: 'sidebar.ledger', icon: BookOpen, permission: 'ledger.read', queryKey: ['ledger', 'list'] },
  { href: '/settings', labelKey: 'sidebar.settings', icon: Settings, queryKey: ['profile'] },
];

type Props = { className?: string };

export function Sidebar({ className }: Props) {
  const pathname = usePathname();
  const { data: profile } = useProfile();
  const { t } = useT();
  const allowed = new Set(profile?.permissions ?? []);
  const items = navItems.filter((i) => !i.permission || allowed.has(i.permission));

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout', {}, { withCredentials: true });
    } finally {
      window.location.href = '/login';
    }
  };

  return (
    <aside className={cn('sidebar-cyber w-60 h-screen sticky top-0 flex flex-col shrink-0 z-40', className)}>
      {/* Logo */}
      <div className="flex h-16 items-center px-6">
        <PrefetchLink href="/" queryKey={['dashboard', 'summary']} className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#2563EB] flex items-center justify-center shrink-0">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
              />
            </svg>
          </div>
          <h1 className="font-bold text-lg text-fg-primary">أقساط</h1>
        </PrefetchLink>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1 no-scrollbar">
        {items.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <PrefetchLink
              key={item.href}
              href={item.href}
              queryKey={item.queryKey}
              className={cn(
                'sidebar-item flex items-center gap-3 px-4 py-3.5 sm:py-3 rounded-lg text-sm font-medium',
                active ? 'active' : 'text-fg-muted',
              )}
            >
              <Icon className="w-5 h-5 shrink-0" />
              <span className="flex-1 truncate">{t(item.labelKey)}</span>
            </PrefetchLink>
          );
        })}
      </nav>

      {/* User card */}
      <div className="border-t border-[var(--border-subtle)] p-4">
        <div className="flex items-center gap-3 rounded-lg bg-overlay-subtle px-3 py-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#2563EB] text-sm font-medium text-white">
            {(profile?.name ?? '?').trim().charAt(0) || '?'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-fg-primary">{profile?.name ?? '...'}</p>
            <p className="truncate text-xs text-fg-muted">{t('sidebar.member')}</p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            aria-label={t('sidebar.logout')}
            title={t('sidebar.logout')}
            className="p-1.5 hover:bg-overlay rounded-md transition-colors shrink-0"
          >
            <LogOut className="w-4 h-4 text-fg-muted" />
          </button>
        </div>
      </div>
    </aside>
  );
}
