"use client";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface SaleItem {
  product_id: number;
  variant_id: number | null;
  name: string;
  name_ar: string | null;
  quantity: number;
  unit_price: number;
  item_discount: number;
  line_total: number;
}

export interface InstallmentRow {
  installment_number: number;
  due_date: string;
  amount: number;
  paid: number;
  remaining: number;
  status: "pending" | "partially_paid" | "paid" | "late" | "cancelled";
  late_days: number;
}

export interface InstallmentPlanInfo {
  id: number;
  principal_amount: number;
  months: number;
  monthly_amount: number;
  frequency: string;
  start_date: string;
  end_date: string;
  status: string;
  schedule: InstallmentRow[];
}

export interface SaleListItem {
  id: number;
  public_id: string;
  sale_number: string;
  customer_id: number;
  sale_type: "cash" | "installment";
  sale_channel: string;
  subtotal: number;
  discount_amount: number;
  total_price: number;
  down_payment: number;
  status: "active" | "completed" | "cancelled";
  notes: string | null;
  created_at: string;
  items: SaleItem[];
  plan: InstallmentPlanInfo | null;
}

export interface Paginated<T> {
  data: T[];
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export function useSales(params: { page?: number; page_size?: number; customer_id?: number; sale_type?: string; status?: string }) {
  return useQuery<Paginated<SaleListItem>>({
    queryKey: ["sales", "list", params],
    queryFn: () => api.get("/sales", params),
    staleTime: 60000,
  });
}
