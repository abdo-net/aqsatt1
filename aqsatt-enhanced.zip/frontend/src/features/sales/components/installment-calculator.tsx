"use client";
import { usePosStore } from "@/store/use-pos-store";
import { calculateInstallments, formatCurrency, formatDate, type InstallmentScheduleItem } from "@/shared/lib/formatters";
import { Num } from "@/shared/ui/num";
import { GlassCard } from "@/shared/ui/glass-card";
import { cn } from "@/shared/lib/utils";

const DURATION_CHIPS = [3, 6, 9, 12];

export function InstallmentCalculator() {
  const store = usePosStore();
  const totalPrice = store.totalPrice();
  const downPayment = store.downPayment;
  const months = store.months;
  const frequency = store.frequency;
  const startDate = store.startDate;

  const principal = Math.max(0, totalPrice - downPayment);
  const base = Math.floor(principal / months);
  const remainder = principal - base * months;

  let schedule: InstallmentScheduleItem[] = [];
  if (base > 0) {
    try {
      schedule = calculateInstallments(totalPrice, downPayment, months, frequency, new Date(startDate));
    } catch {
      // invalid parameters
    }
  }

  return (
    <GlassCard>
      <h3 className="font-semibold text-white mb-4">حاسبة التقسيط</h3>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-fg-secondary mb-2">الدفعة الأولى</label>
            <input
              type="number"
              value={downPayment}
              onChange={(e) => store.setDownPayment(Math.max(0, parseInt(e.target.value) || 0))}
              min={0}
              max={totalPrice}
              className="input-cyber w-full px-4 py-2.5 rounded-xl text-white num-ltr"
            />
          </div>
          <div>
            <label className="block text-sm text-fg-secondary mb-2">تاريخ البدء</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => store.setStartDate(e.target.value)}
              className="input-cyber w-full px-4 py-2.5 rounded-xl text-white num-ltr"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm text-fg-secondary mb-2">عدد الأشهر (أي قيمة)</label>
          <input
            type="number"
            min={1}
            max={60}
            value={months}
            onChange={(e) => store.setMonths(Math.max(1, parseInt(e.target.value) || 1))}
            className="input-cyber w-full px-4 py-2.5 rounded-xl text-white num-ltr mb-2"
          />
          <div className="flex gap-2">
            {DURATION_CHIPS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => store.setMonths(m)}
                className={cn(
                  "px-4 py-2 rounded-xl text-sm font-medium border transition-colors num-ltr",
                  months === m ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-transparent" : "bg-white/5 text-fg-muted border-white/10 hover:bg-white/10",
                )}
              >
                {m} شهر
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm text-fg-secondary mb-2">التكرار</label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => store.setFrequency("monthly")}
              className={cn("px-4 py-2 rounded-xl text-sm font-medium border transition-colors", frequency === "monthly" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-transparent" : "bg-white/5 text-fg-muted border-white/10 hover:bg-white/10")}
            >
              شهري
            </button>
            <button
              type="button"
              onClick={() => store.setFrequency("weekly")}
              className={cn("px-4 py-2 rounded-xl text-sm font-medium border transition-colors", frequency === "weekly" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-transparent" : "bg-white/5 text-fg-muted border-white/10 hover:bg-white/10")}
            >
              أسبوعي
            </button>
          </div>
        </div>

        <div className="rounded-xl p-4 bg-white/5 border border-white/10 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-fg-muted">الإجمالي</span>
            <span className="font-medium text-white"><Num currency>{totalPrice}</Num></span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-fg-muted">الدفعة الأولى</span>
            <span className="font-medium text-white"><Num currency>{downPayment}</Num></span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-fg-muted">الأصل</span>
            <span className="font-medium text-white"><Num currency>{principal}</Num></span>
          </div>
          <div className="flex justify-between text-sm font-semibold">
            <span className="text-white">القسط الأساسي</span>
            <span className="text-[#2563EB]"><Num currency>{base}</Num></span>
          </div>
          {remainder > 0 && (
            <div className="text-xs text-fg-muted">القسط الأخير يضيف {formatCurrency(remainder)} لتغطية الباقي</div>
          )}
        </div>

        {schedule.length > 0 && (
          <div className="rounded-xl border border-white/10 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-3 py-2 text-right text-fg-secondary">#</th>
                  <th className="px-3 py-2 text-right text-fg-secondary">تاريخ الاستحقاق</th>
                  <th className="px-3 py-2 text-left text-fg-secondary">المبلغ</th>
                </tr>
              </thead>
              <tbody>
                {schedule.map((inst) => (
                  <tr key={inst.installmentNumber} className="border-t border-white/5">
                    <td className="px-3 py-2 text-white num-ltr">{inst.installmentNumber}</td>
                    <td className="px-3 py-2 text-fg-secondary">{formatDate(inst.dueDate)}</td>
                    <td className="px-3 py-2 text-left font-medium text-white"><Num currency>{inst.amount}</Num></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {base <= 0 && principal > 0 && (
          <div className="text-sm text-red-400 bg-red-500/10 p-3 rounded-xl border border-red-500/30">
            قيمة القسط تصل إلى صفر. زد الدفعة الأولى أو قلّل عدد الأشهر.
          </div>
        )}
      </div>
    </GlassCard>
  );
}
