"use client";
import { useMemo, useState } from "react";
import { useSales } from "@/features/sales/hooks/use-sales";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { Skeleton } from "@/shared/ui/skeleton";
import { Button } from "@/shared/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/shared/ui/select";
import { formatDate } from "@/shared/lib/formatters";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SaleDetailModal } from "@/features/sales/components/sale-detail-modal";
import { useRouter } from "next/navigation";

export function SalesTable() {
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [customerId, setCustomerId] = useState<string>("");
  const [saleType, setSaleType] = useState<string>("");
  const [status, setStatus] = useState<string>("");
  const [detailSaleId, setDetailSaleId] = useState<number | null>(null);
  const pageSize = 50;

  const { data, isLoading } = useSales({
    page,
    page_size: pageSize,
    customer_id: customerId ? parseInt(customerId) : undefined,
    sale_type: saleType || undefined,
    status: status || undefined,
  });

  const { data: customers } = useCustomers({ page: 1, page_size: 100 });
  const customerNames = useMemo(() => {
    const map = new Map<number, string>();
    customers?.data.forEach((c) => map.set(c.id, c.full_name));
    return map;
  }, [customers]);

  const sales = data?.data || [];
  const totalPages = data?.total_pages || 1;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Select value={customerId} onValueChange={(v) => { setCustomerId(v); setPage(1); }}>
          <SelectTrigger>
            <SelectValue placeholder="All Customers" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Customers</SelectItem>
            {customers?.data.map((c) => (
              <SelectItem key={c.id} value={c.id.toString()}>{c.full_name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={saleType} onValueChange={(v) => { setSaleType(v); setPage(1); }}>
          <SelectTrigger>
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Types</SelectItem>
            <SelectItem value="cash">Cash</SelectItem>
            <SelectItem value="installment">Installment</SelectItem>
          </SelectContent>
        </Select>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger>
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          <Skeleton className="h-10" />
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12" />
          ))}
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sale #</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Down</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sales.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    No sales found.
                  </TableCell>
                </TableRow>
              ) : (
                sales.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-medium">
                      <button type="button" onClick={() => setDetailSaleId(s.id)} className="hover:underline">
                        {s.sale_number}
                      </button>
                    </TableCell>
                    <TableCell>{customerNames.get(s.customer_id) ?? "—"}</TableCell>
                    <TableCell className="capitalize">
                      <Badge variant={s.sale_type === "cash" ? "secondary" : "default"}>{s.sale_type}</Badge>
                    </TableCell>
                    <TableCell><Num currency>{s.total_price}</Num></TableCell>
                    <TableCell><Num currency>{s.down_payment}</Num></TableCell>
                    <TableCell>
                      <Badge variant={s.status === "active" ? "default" : s.status === "completed" ? "success" : "secondary"}>
                        {s.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">{formatDate(s.created_at)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">Page {page} of {totalPages}</div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <SaleDetailModal
        open={detailSaleId !== null}
        onOpenChange={(open) => !open && setDetailSaleId(null)}
        saleId={detailSaleId}
        onRecordPayment={() => router.push("/payments")}
      />
    </div>
  );
}
