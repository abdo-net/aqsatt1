"use client";
import { usePosStore } from "@/store/use-pos-store";
import { GlassCard } from "@/shared/ui/glass-card";
import { NeonButton } from "@/shared/ui/neon-button";
import { Num } from "@/shared/ui/num";
import { Minus, Plus, Trash2, ShoppingCart } from "lucide-react";
import { cn } from "@/shared/lib/utils";

interface CartPanelProps {
  onCheckout: () => void;
}

export function CartPanel({ onCheckout }: CartPanelProps) {
  const store = usePosStore();
  const items = store.items;
  const subtotal = store.subtotal();
  const totalPrice = store.totalPrice();
  const saleType = store.saleType;

  if (items.length === 0) {
    return (
      <GlassCard className="h-full flex flex-col items-center justify-center text-center">
        <ShoppingCart className="h-12 w-12 text-fg-faint mb-4" />
        <h3 className="text-lg font-medium text-white">السلة فارغة</h3>
        <p className="text-sm text-fg-muted mt-1">أضف منتجات للبدء</p>
      </GlassCard>
    );
  }

  return (
    <GlassCard padding="none" className="h-full flex flex-col overflow-hidden">
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <span className="font-semibold text-white">السلة ({items.length})</span>
        <div className="flex gap-1.5">
          <button
            onClick={() => store.setSaleType("cash")}
            className={cn("text-xs px-3 py-1.5 rounded-lg transition-colors", saleType === "cash" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB]" : "bg-white/5 text-fg-muted")}
          >
            نقدي
          </button>
          <button
            onClick={() => store.setSaleType("installment")}
            className={cn("text-xs px-3 py-1.5 rounded-lg transition-colors", saleType === "installment" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB]" : "bg-white/5 text-fg-muted")}
          >
            تقسيط
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-auto space-y-2 p-3">
        {items.map((item) => (
          <div key={`${item.productId}-${item.variantId}`} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm truncate text-white">{item.name}</div>
              <div className="text-xs text-fg-muted">{item.variantName}</div>
              <div className="text-xs font-semibold mt-0.5 text-[#2563EB]">
                <Num currency>{saleType === "cash" ? item.priceCash : item.priceInstallment}</Num>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => store.updateQty(item.variantId, item.productId, item.quantity - 1)}
                className="h-8 w-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10"
              >
                {item.quantity <= 1 ? <Trash2 className="h-3.5 w-3.5 text-red-400" /> : <Minus className="h-3.5 w-3.5 text-white" />}
              </button>
              <span className="w-8 text-center text-sm font-medium text-white num-ltr">{item.quantity}</span>
              <button
                type="button"
                onClick={() => store.updateQty(item.variantId, item.productId, item.quantity + 1)}
                className="h-8 w-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10"
              >
                <Plus className="h-3.5 w-3.5 text-white" />
              </button>
            </div>
            <div className="text-sm font-bold min-w-[80px] text-left text-white">
              <Num currency>{(saleType === "cash" ? item.priceCash : item.priceInstallment) * item.quantity}</Num>
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 border-t border-white/10 space-y-3 bg-bg-elevated/40">
        <div className="flex items-center gap-2">
          <span className="text-sm text-fg-muted">خصم:</span>
          <input
            type="number"
            value={store.discountAmount}
            onChange={(e) => store.setDiscountAmount(parseInt(e.target.value) || 0)}
            className="input-cyber h-8 text-sm w-28 px-2 rounded-lg text-white num-ltr"
            min={0}
          />
          <span className="text-sm text-fg-muted">IQD</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-fg-muted">المجموع الفرعي</span>
          <span className="font-medium text-white"><Num currency>{subtotal}</Num></span>
        </div>
        {store.discountAmount > 0 && (
          <div className="flex justify-between text-sm">
            <span className="text-fg-muted">الخصم</span>
            <span className="font-medium text-red-400">-<Num currency>{store.discountAmount}</Num></span>
          </div>
        )}
        <div className="flex justify-between text-lg font-bold text-white">
          <span>الإجمالي</span>
          <span className="text-[#2563EB]"><Num currency>{totalPrice}</Num></span>
        </div>
        <NeonButton variant="cyan" className="w-full" size="lg" onClick={onCheckout}>
          إتمام البيع
        </NeonButton>
      </div>
    </GlassCard>
  );
}
