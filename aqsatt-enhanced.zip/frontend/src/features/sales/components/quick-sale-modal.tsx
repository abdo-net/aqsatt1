"use client";

import { useEffect, useState } from "react";
import { Trash2, Plus } from "lucide-react";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { cn } from "@/shared/lib/utils";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { useProducts } from "@/features/products/hooks/use-products";
import { useCreateSale } from "@/features/sales/hooks/use-create-sale";
import { generateIdempotencyKey } from "@/shared/lib/formatters";
import { toast } from "react-hot-toast";

type ItemDraft = {
  product_id: number | "";
  quantity: number;
  unit_price: number;
  item_discount: number;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const inputCls = "input-cyber w-full px-4 py-3 rounded-xl text-white placeholder:text-white/30";
const labelCls = "block text-sm text-fg-secondary mb-2";
const formatIQD = (n: number) => new Intl.NumberFormat("en-US").format(n);

function calculateInstallments(total: number, down: number, months: number) {
  const principal = Math.max(0, total - down);
  const base = Math.floor(principal / months);
  const remainder = principal - base * months;
  return Array.from({ length: months }, (_, i) => base + (i === months - 1 ? remainder : 0));
}

export function QuickSaleModal({ open, onOpenChange }: Props) {
  const { data: customers } = useCustomers({ page: 1, page_size: 200 });
  const { data: products } = useProducts({ page: 1, page_size: 200, status: "active" });
  const createSale = useCreateSale();

  const [error, setError] = useState<string | null>(null);
  const [customerId, setCustomerId] = useState("");
  const [saleType, setSaleType] = useState<"cash" | "installment">("installment");
  const [months, setMonths] = useState(6);
  const [frequency, setFrequency] = useState<"weekly" | "monthly">("monthly");
  const [downPayment, setDownPayment] = useState(0);
  const [discount, setDiscount] = useState(0);
  const [items, setItems] = useState<ItemDraft[]>([{ product_id: "", quantity: 1, unit_price: 0, item_discount: 0 }]);

  useEffect(() => {
    if (open) {
      setCustomerId("");
      setSaleType("installment");
      setMonths(6);
      setFrequency("monthly");
      setDownPayment(0);
      setDiscount(0);
      setItems([{ product_id: "", quantity: 1, unit_price: 0, item_discount: 0 }]);
      setError(null);
    }
  }, [open]);

  const subtotal = items.reduce((acc, it) => acc + Math.max(0, it.unit_price * it.quantity - it.item_discount), 0);
  const total = Math.max(0, subtotal - discount);
  const schedule = saleType === "installment" && months > 0 ? calculateInstallments(total, downPayment, months) : [];

  const updateItem = (i: number, patch: Partial<ItemDraft>) =>
    setItems((prev) => prev.map((it, idx) => (idx === i ? { ...it, ...patch } : it)));

  const pickProduct = (i: number, productId: string) => {
    const p = products?.data.find((p) => String(p.id) === productId);
    if (!p) return updateItem(i, { product_id: "" });
    updateItem(i, { product_id: p.id, unit_price: p.price_cash });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    if (!customerId) return setError("اختر العميل");
    if (items.some((it) => !it.product_id || it.quantity <= 0)) return setError("تأكد من بيانات المنتجات");
    if (total <= 0) return setError("المبلغ الإجمالي يجب أن يكون موجباً");
    if (saleType === "installment") {
      if (months < 1) return setError("عدد الأشهر يجب أن يكون ≥ 1");
      if (downPayment >= total) return setError("الدفعة الأولى يجب أن تكون أقل من الإجمالي");
    }

    createSale.mutate(
      {
        idempotency_key: generateIdempotencyKey(),
        customer_id: Number(customerId),
        sale_type: saleType,
        items: items.map((it) => ({
          product_id: Number(it.product_id),
          quantity: it.quantity,
          item_discount: it.item_discount,
        })),
        discount_amount: discount,
        down_payment: saleType === "installment" ? downPayment : 0,
        months: saleType === "installment" ? months : null,
        frequency: saleType === "installment" ? frequency : "monthly",
        start_date: saleType === "installment" ? new Date().toISOString().slice(0, 10) : null,
        sale_channel: "store",
      },
      {
        onSuccess: () => {
          toast.success("تم إنشاء البيع بنجاح");
          onOpenChange(false);
        },
      },
    );
  };

  return (
    <CyberModal open={open} onOpenChange={onOpenChange} title="بيع جديد" description="أنشئ عملية بيع جديدة (نقدي أو بالأقساط)" accent="pink" size="xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className={labelCls}>العميل *</label>
            <select required value={customerId} onChange={(e) => setCustomerId(e.target.value)} className={inputCls + " bg-bg-elevated appearance-none"}>
              <option value="">اختر العميل...</option>
              {customers?.data.map((c) => (
                <option key={c.id} value={c.id} className="bg-bg-elevated">
                  {c.full_name} — {c.phone}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={labelCls}>نوع البيع</label>
            <select value={saleType} onChange={(e) => setSaleType(e.target.value as "cash" | "installment")} className={inputCls + " bg-bg-elevated appearance-none"}>
              <option value="cash" className="bg-bg-elevated">نقدي</option>
              <option value="installment" className="bg-bg-elevated">قسط</option>
            </select>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className={labelCls + " mb-0"}>المنتجات</label>
            <button
              type="button"
              onClick={() => setItems((p) => [...p, { product_id: "", quantity: 1, unit_price: 0, item_discount: 0 }])}
              className="text-xs px-3 py-1.5 rounded-lg bg-[rgba(37,99,235,0.1)] text-[#2563EB] hover:bg-[rgba(37,99,235,0.2)] transition-colors flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              إضافة منتج
            </button>
          </div>

          <div className="space-y-2">
            {items.map((it, i) => (
              <div key={i} className="grid grid-cols-12 gap-2 p-3 rounded-xl bg-white/5 border border-white/5">
                <select
                  className={cn(inputCls, "col-span-5 bg-bg-elevated appearance-none")}
                  value={String(it.product_id)}
                  onChange={(e) => pickProduct(i, e.target.value)}
                  required
                >
                  <option value="">اختر المنتج...</option>
                  {products?.data.map((p) => (
                    <option key={p.id} value={p.id} className="bg-bg-elevated">
                      {p.name_ar || p.name}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min={1}
                  value={it.quantity}
                  onChange={(e) => updateItem(i, { quantity: Number(e.target.value) })}
                  placeholder="الكمية"
                  className={cn(inputCls, "col-span-2 num-ltr")}
                />
                <input type="number" readOnly value={it.unit_price} placeholder="السعر" className={cn(inputCls, "col-span-3 num-ltr opacity-60")} />
                <button
                  type="button"
                  onClick={() => setItems((p) => p.filter((_, idx) => idx !== i))}
                  disabled={items.length === 1}
                  className="col-span-2 p-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {saleType === "installment" && (
          <div className="grid grid-cols-3 gap-4 p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
            <div>
              <label className={labelCls}>عدد الأشهر</label>
              <input
                type="number"
                min={1}
                max={60}
                value={months}
                onChange={(e) => setMonths(Math.max(1, Number(e.target.value) || 1))}
                className={inputCls + " num-ltr"}
              />
            </div>
            <div>
              <label className={labelCls}>التكرار</label>
              <select value={frequency} onChange={(e) => setFrequency(e.target.value as "weekly" | "monthly")} className={inputCls + " bg-bg-elevated appearance-none"}>
                <option value="monthly" className="bg-bg-elevated">شهري</option>
                <option value="weekly" className="bg-bg-elevated">أسبوعي</option>
              </select>
            </div>
            <div>
              <label className={labelCls}>الدفعة الأولى</label>
              <input type="number" min={0} value={downPayment} onChange={(e) => setDownPayment(Number(e.target.value))} className={inputCls + " num-ltr"} />
            </div>
          </div>
        )}

        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="grid grid-cols-3 gap-4 mb-3">
            <div>
              <span className="text-xs text-fg-muted">المجموع الفرعي</span>
              <p className="text-lg font-bold text-white num-ltr">{formatIQD(subtotal)}</p>
            </div>
            <div>
              <label className="text-xs text-fg-muted">خصم</label>
              <input
                type="number"
                min={0}
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="input-cyber w-full px-3 py-1.5 rounded-lg mt-1 num-ltr text-sm"
              />
            </div>
            <div>
              <span className="text-xs text-fg-muted">الإجمالي</span>
              <p className="text-2xl font-bold text-[#2563EB] num-ltr">
                {formatIQD(total)} <span className="text-xs text-fg-muted">IQD</span>
              </p>
            </div>
          </div>

          {saleType === "installment" && schedule.length > 0 && (
            <div className="mt-3 pt-3 border-t border-white/10">
              <p className="text-xs text-fg-muted mb-2">معاينة جدول الأقساط (تقدير — الخادم مرجعي):</p>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                {schedule.slice(0, 6).map((amt, i) => (
                  <div key={i} className="text-center p-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
                    <div className="text-xs text-fg-muted">{i + 1}</div>
                    <div className="text-sm font-bold text-purple-300 num-ltr">{formatIQD(amt)}</div>
                  </div>
                ))}
                {schedule.length > 6 && <div className="text-center p-2 text-xs text-fg-muted">+{schedule.length - 6}</div>}
              </div>
            </div>
          )}
        </div>

        {error && <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm">⚠️ {error}</div>}

        <div className="flex gap-4 pt-4 border-t border-white/5">
          <NeonButton type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)} disabled={createSale.isPending}>
            إلغاء
          </NeonButton>
          <NeonButton type="submit" variant="pink" className="flex-1" loading={createSale.isPending}>
            إنشاء البيع
          </NeonButton>
        </div>
      </form>
    </CyberModal>
  );
}
