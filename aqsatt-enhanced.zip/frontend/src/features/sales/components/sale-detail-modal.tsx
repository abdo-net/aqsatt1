"use client";

import { Printer, DollarSign, Calendar, User } from "lucide-react";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { useSaleSchedule, type InstallmentRow } from "@/features/payments/hooks/use-payments";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saleId: number | null;
  onRecordPayment?: () => void;
};

const formatIQD = (n: number) => new Intl.NumberFormat("en-US").format(n);
const formatDate = (iso: string) => {
  try {
    return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(iso));
  } catch {
    return iso;
  }
};

const stateMap: Record<InstallmentRow["status"], { label: string; cls: string }> = {
  paid: { label: "مدفوع", cls: "bg-green-500/10 border-green-500/20 text-green-400" },
  late: { label: "متأخر", cls: "bg-red-500/10 border-red-500/20 text-red-400" },
  partially_paid: { label: "جزئي", cls: "bg-amber-500/10 border-amber-500/20 text-amber-400" },
  pending: { label: "قادم", cls: "bg-blue-500/10 border-blue-500/20 text-blue-400" },
  cancelled: { label: "ملغي", cls: "bg-white/5 border-white/10 text-white/40" },
};

export function SaleDetailModal({ open, onOpenChange, saleId, onRecordPayment }: Props) {
  const { data: schedule, isLoading } = useSaleSchedule(saleId);

  const remaining = schedule
    ? schedule.installments.filter((i) => i.status !== "paid" && i.status !== "cancelled").reduce((acc, i) => acc + i.remaining, 0)
    : 0;

  return (
    <CyberModal
      open={open}
      onOpenChange={onOpenChange}
      title="تفاصيل البيع"
      description={schedule ? `العملية ${schedule.sale_number}` : ""}
      accent="cyan"
      size="xl"
    >
      {isLoading || !schedule ? (
        <div className="space-y-3">
          <div className="h-24 rounded-xl animate-shimmer bg-white/5" />
          <div className="h-40 rounded-xl animate-shimmer bg-white/5" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <div className="flex items-center gap-2 text-fg-secondary text-xs mb-1">
                <User className="w-3.5 h-3.5" />
                العميل
              </div>
              <p className="font-semibold text-white truncate">{schedule.customer_name}</p>
            </div>
            <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
              <div className="flex items-center gap-2 text-fg-secondary text-xs mb-1">
                <DollarSign className="w-3.5 h-3.5" />
                الإجمالي
              </div>
              <p className="font-bold text-white num-ltr">{formatIQD(schedule.total_price)}</p>
            </div>
            <div className="p-4 rounded-xl bg-pink-500/10 border border-pink-500/20">
              <div className="flex items-center gap-2 text-fg-secondary text-xs mb-1">الدفعة الأولى</div>
              <p className="font-bold text-white num-ltr">{formatIQD(schedule.down_payment)}</p>
            </div>
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
              <div className="flex items-center gap-2 text-fg-secondary text-xs mb-1">المتبقي</div>
              <p className="font-bold text-red-400 num-ltr">{formatIQD(remaining)}</p>
            </div>
          </div>

          <h3 className="font-semibold text-white mb-3">جدول الأقساط</h3>
          <div className="max-h-72 overflow-y-auto pr-2 space-y-2">
            {schedule.installments.length === 0 ? (
              <p className="text-sm text-fg-muted text-center py-6">بيع نقدي — لا يوجد جدول أقساط</p>
            ) : (
              schedule.installments.map((ins) => {
                const st = stateMap[ins.status] ?? stateMap.pending;
                return (
                  <div key={ins.installment_number} className={`flex items-center justify-between p-3 rounded-lg border ${st.cls}`}>
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-8 h-8 rounded-lg bg-black/30 flex items-center justify-center text-xs font-bold shrink-0">
                        {ins.installment_number}
                      </span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-white">
                          قسط #{ins.installment_number}
                          {ins.late_days > 0 && <span className="text-xs text-red-400 mr-2 num-ltr">({ins.late_days} يوم تأخير)</span>}
                        </p>
                        <p className="text-xs text-fg-muted flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span className="num-ltr">{formatDate(ins.due_date)}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      <p className="font-bold num-ltr">{formatIQD(ins.remaining)}</p>
                      {ins.paid > 0 && ins.paid < ins.amount && <p className="text-xs text-fg-muted num-ltr">مدفوع {formatIQD(ins.paid)}</p>}
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-medium shrink-0">{st.label}</span>
                  </div>
                );
              })
            )}
          </div>

          <div className="flex gap-4 pt-6 mt-6 border-t border-white/5">
            <NeonButton variant="outline" className="flex-1" leftIcon={<Printer className="w-4 h-4" />} onClick={() => window.print()}>
              طباعة
            </NeonButton>
            {onRecordPayment && (
              <NeonButton variant="green" className="flex-1" onClick={onRecordPayment}>
                تسجيل دفعة
              </NeonButton>
            )}
          </div>
        </>
      )}
    </CyberModal>
  );
}
