"use client";
import { useState } from "react";
import { useProducts } from "@/features/products/hooks/use-products";
import { ProductCard } from "@/features/products/components/product-card";
import { TableSkeleton, EmptyState } from "@/shared/ui/empty-state";
import { Search, PackageSearch } from "lucide-react";

interface ProductCatalogProps {
  onSelect: (productId: number, variantId: number | null, priceCash: number, priceInstallment: number, name: string, variantName: string) => void;
}

export function ProductCatalog({ onSelect }: ProductCatalogProps) {
  const [search, setSearch] = useState("");
  const { data, isLoading } = useProducts({ page: 1, page_size: 50, q: search || undefined });
  const products = data?.data || [];

  return (
    <div className="space-y-4">
      <div className="relative">
        <input
          placeholder="بحث عن منتج..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input-cyber w-full px-4 py-2.5 pr-10 rounded-xl text-white placeholder:text-white/30"
        />
        <Search className="w-4 h-4 text-fg-faint absolute right-3.5 top-1/2 -translate-y-1/2" />
      </div>
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-64 rounded-2xl animate-shimmer bg-white/5" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <EmptyState icon={PackageSearch} title="لا توجد منتجات" description="جرّب كلمة بحث مختلفة" />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} onSelect={onSelect} selectable />
          ))}
        </div>
      )}
    </div>
  );
}
