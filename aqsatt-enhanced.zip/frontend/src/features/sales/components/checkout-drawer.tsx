"use client";
import { useState } from "react";
import { usePosStore } from "@/store/use-pos-store";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { useCreateSale } from "@/features/sales/hooks/use-create-sale";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { Num } from "@/shared/ui/num";
import { InstallmentCalculator } from "./installment-calculator";
import { generateIdempotencyKey } from "@/shared/lib/formatters";
import { toast } from "react-hot-toast";
import { Search, User } from "lucide-react";

interface CheckoutDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function CheckoutDrawer({ open, onOpenChange, onSuccess }: CheckoutDrawerProps) {
  const store = usePosStore();
  const [customerSearch, setCustomerSearch] = useState("");
  const { data: customersData } = useCustomers({ page: 1, page_size: 10, name: customerSearch || undefined });
  const createSale = useCreateSale();
  const [showCustomerSearch, setShowCustomerSearch] = useState(false);

  const selectedCustomer = customersData?.data.find((c) => c.id === store.customerId);
  const totalPrice = store.totalPrice();
  const items = store.items;

  const handleSubmit = () => {
    if (!store.customerId) {
      toast.error("اختر العميل أولاً");
      return;
    }
    if (items.length === 0) {
      toast.error("السلة فارغة");
      return;
    }
    if (store.saleType === "installment") {
      const principal = totalPrice - store.downPayment;
      const base = Math.floor(principal / store.months);
      if (base <= 0) {
        toast.error("معاملات التقسيط غير صحيحة");
        return;
      }
    }

    const payload = {
      idempotency_key: generateIdempotencyKey(),
      customer_id: store.customerId,
      sale_type: store.saleType,
      items: items.map((item) => ({
        product_id: item.productId,
        variant_id: item.variantId,
        quantity: item.quantity,
        item_discount: 0,
      })),
      discount_amount: store.discountAmount,
      down_payment: store.saleType === "installment" ? store.downPayment : 0,
      months: store.saleType === "installment" ? store.months : null,
      frequency: store.frequency,
      start_date: store.saleType === "installment" ? store.startDate : null,
      sale_channel: "store" as const,
      salesperson_id: null,
      notes: store.notes || null,
    };

    createSale.mutate(payload, {
      onSuccess: () => {
        toast.success("تم إنشاء البيع بنجاح");
        store.clearCart();
        onOpenChange(false);
        onSuccess();
      },
    });
  };

  return (
    <CyberModal open={open} onOpenChange={onOpenChange} title="إتمام البيع" description="راجع البيانات وأكمل عملية البيع" accent="cyan" size="xl">
      <div className="space-y-6">
        <div className="rounded-xl border border-white/10 p-4 space-y-3 bg-white/5">
          <div className="font-medium text-sm text-white">العميل</div>
          {selectedCustomer ? (
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-[#2563EB] text-white flex items-center justify-center font-medium text-sm">
                  {selectedCustomer.full_name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="font-medium text-white">{selectedCustomer.full_name}</div>
                  <div className="text-xs text-fg-muted num-ltr" dir="ltr">{selectedCustomer.phone}</div>
                </div>
              </div>
              <button
                onClick={() => { store.setCustomer(null); setShowCustomerSearch(true); }}
                className="text-xs px-3 py-1.5 rounded-lg bg-white/5 text-fg-secondary hover:bg-white/10 transition-colors"
              >
                تغيير
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="relative">
                <input
                  placeholder="بحث بالاسم أو الهاتف..."
                  value={customerSearch}
                  onChange={(e) => { setCustomerSearch(e.target.value); setShowCustomerSearch(true); }}
                  className="input-cyber w-full px-4 py-2.5 pr-10 rounded-xl text-white placeholder:text-white/30"
                />
                <Search className="w-4 h-4 text-fg-faint absolute right-3.5 top-1/2 -translate-y-1/2" />
              </div>
              {showCustomerSearch && customersData && customersData.data.length > 0 && (
                <div className="rounded-xl border border-white/10 divide-y divide-white/5 overflow-hidden">
                  {customersData.data.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => { store.setCustomer(c.id); setShowCustomerSearch(false); setCustomerSearch(""); }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-white/5 text-right transition-colors"
                    >
                      <User className="h-4 w-4 text-fg-muted" />
                      <div>
                        <div className="font-medium text-sm text-white">{c.full_name}</div>
                        <div className="text-xs text-fg-muted num-ltr" dir="ltr">{c.phone}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-white/10 p-4 space-y-3 bg-white/5">
          <div className="font-medium text-sm text-white">ملخص الطلب</div>
          {items.map((item) => (
            <div key={`${item.productId}-${item.variantId}`} className="flex justify-between text-sm">
              <span className="text-fg-secondary">{item.name} × {item.quantity}</span>
              <span className="font-medium text-white">
                <Num currency>{(store.saleType === "cash" ? item.priceCash : item.priceInstallment) * item.quantity}</Num>
              </span>
            </div>
          ))}
          <div className="border-t border-white/10 pt-2 space-y-1">
            {store.discountAmount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-fg-muted">الخصم</span>
                <span className="text-red-400">-<Num currency>{store.discountAmount}</Num></span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold text-white">
              <span>الإجمالي</span>
              <span className="text-[#2563EB]"><Num currency>{totalPrice}</Num></span>
            </div>
          </div>
        </div>

        {store.saleType === "installment" && <InstallmentCalculator />}

        <div>
          <label className="block text-sm font-medium text-fg-secondary mb-2">ملاحظات</label>
          <input
            value={store.notes}
            onChange={(e) => store.setNotes(e.target.value)}
            placeholder="ملاحظات اختيارية..."
            className="input-cyber w-full px-4 py-2.5 rounded-xl text-white placeholder:text-white/30"
          />
        </div>

        <NeonButton
          variant="cyan"
          className="w-full"
          size="lg"
          loading={createSale.isPending}
          onClick={handleSubmit}
          disabled={!store.customerId || items.length === 0}
        >
          إتمام البيع {store.saleType === "cash" ? "النقدي" : "بالتقسيط"}
        </NeonButton>
      </div>
    </CyberModal>
  );
}
