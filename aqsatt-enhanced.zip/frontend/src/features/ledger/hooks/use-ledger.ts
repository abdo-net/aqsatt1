"use client";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface LedgerLine {
  account_code: string;
  account_name: string;
  account_name_ar: string;
  debit: number;
  credit: number;
  description: string | null;
  customer_id: number | null;
  sale_id: number | null;
}

export interface LedgerEntry {
  transaction_group_id: string;
  reference_type: "sale" | "payment" | "reversal" | "reschedule";
  reference_id: number;
  created_at: string;
  lines: LedgerLine[];
  total: number;
}

export interface LedgerSummary {
  total_debits: number;
  total_credits: number;
  net_balance: number;
  entry_count: number;
}

export function useLedger(params: { customer_id?: number; limit?: number }) {
  return useQuery<LedgerEntry[]>({
    queryKey: ["ledger", "list", params],
    queryFn: () => api.get("/ledger", params),
    staleTime: 30000,
  });
}

export function useLedgerSummary(params: { customer_id?: number; date_from?: string; date_to?: string }) {
  return useQuery<LedgerSummary>({
    queryKey: ["ledger", "summary", params],
    queryFn: () => api.get("/ledger/summary", params),
    staleTime: 30000,
  });
}
