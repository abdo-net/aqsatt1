"use client";
import { useMemo, useState } from "react";
import { useLedger, useLedgerSummary } from "@/features/ledger/hooks/use-ledger";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { Skeleton } from "@/shared/ui/skeleton";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/shared/ui/select";
import { Card, CardContent } from "@/shared/ui/card";
import { formatDateTime } from "@/shared/lib/formatters";
import { ChevronLeft, ChevronRight } from "lucide-react";

const ENTRY_TYPES = ["sale", "payment", "reversal", "reschedule"];

export function LedgerTable() {
  const [page, setPage] = useState(1);
  const [customerId, setCustomerId] = useState<string>("");
  const [entryType, setEntryType] = useState<string>("");
  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");
  const pageSize = 50;

  const { data, isLoading } = useLedger({
    customer_id: customerId ? parseInt(customerId) : undefined,
    limit: 300,
  });

  const { data: summary } = useLedgerSummary({
    customer_id: customerId ? parseInt(customerId) : undefined,
    date_from: dateFrom || undefined,
    date_to: dateTo || undefined,
  });

  const { data: customers } = useCustomers({ page: 1, page_size: 100 });
  const customerNames = useMemo(() => {
    const map = new Map<number, string>();
    customers?.data.forEach((c) => map.set(c.id, c.full_name));
    return map;
  }, [customers]);

  const rows = useMemo(() => {
    const out: Array<{
      key: string;
      created_at: string;
      reference_type: string;
      customer_id: number | null;
      description: string | null;
      debit: number;
      credit: number;
    }> = [];
    (data ?? []).forEach((group) => {
      if (entryType && group.reference_type !== entryType) return;
      if (dateFrom && group.created_at < dateFrom) return;
      if (dateTo && group.created_at > dateTo) return;
      group.lines.forEach((line, i) => {
        out.push({
          key: `${group.transaction_group_id}-${i}`,
          created_at: group.created_at,
          reference_type: group.reference_type,
          customer_id: line.customer_id,
          description: line.description,
          debit: line.debit,
          credit: line.credit,
        });
      });
    });
    return out;
  }, [data, entryType, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const entries = rows.slice((page - 1) * pageSize, page * pageSize);

  const getEntryBadge = (type: string) => {
    switch (type) {
      case "sale": return <Badge variant="default">Sale</Badge>;
      case "payment": return <Badge variant="success">Payment</Badge>;
      case "reversal": return <Badge variant="destructive">Reversal</Badge>;
      case "reschedule": return <Badge variant="secondary">Reschedule</Badge>;
      default: return <Badge variant="outline">{type}</Badge>;
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <Select value={customerId} onValueChange={(v) => { setCustomerId(v); setPage(1); }}>
          <SelectTrigger>
            <SelectValue placeholder="All Customers" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Customers</SelectItem>
            {customers?.data.map((c) => (
              <SelectItem key={c.id} value={c.id.toString()}>{c.full_name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={entryType} onValueChange={(v) => { setEntryType(v); setPage(1); }}>
          <SelectTrigger>
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Types</SelectItem>
            {ENTRY_TYPES.map((t) => (
              <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          type="date"
          placeholder="From"
          value={dateFrom}
          onChange={(e) => { setDateFrom(e.target.value); setPage(1); }}
        />
        <Input
          type="date"
          placeholder="To"
          value={dateTo}
          onChange={(e) => { setDateTo(e.target.value); setPage(1); }}
        />
      </div>

      {summary && (
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-xs text-muted-foreground">Total Debits</div>
              <div className="text-lg font-bold text-red-600"><Num currency>{summary.total_debits}</Num></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-xs text-muted-foreground">Total Credits</div>
              <div className="text-lg font-bold text-emerald-600"><Num currency>{summary.total_credits}</Num></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-xs text-muted-foreground">Net Balance</div>
              <div className="text-lg font-bold"><Num currency>{summary.net_balance}</Num></div>
            </CardContent>
          </Card>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-2">
          <Skeleton className="h-10" />
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12" />
          ))}
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Debit</TableHead>
                <TableHead className="text-right">Credit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {entries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No ledger entries found.
                  </TableCell>
                </TableRow>
              ) : (
                entries.map((e) => (
                  <TableRow key={e.key}>
                    <TableCell className="text-xs">{formatDateTime(e.created_at)}</TableCell>
                    <TableCell className="font-medium">{e.customer_id ? customerNames.get(e.customer_id) ?? "—" : "—"}</TableCell>
                    <TableCell>{getEntryBadge(e.reference_type)}</TableCell>
                    <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{e.description || "—"}</TableCell>
                    <TableCell className="text-right font-medium text-red-600">
                      {e.debit > 0 ? <Num currency>{e.debit}</Num> : "—"}
                    </TableCell>
                    <TableCell className="text-right font-medium text-emerald-600">
                      {e.credit > 0 ? <Num currency>{e.credit}</Num> : "—"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">Page {page} of {totalPages}</div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
