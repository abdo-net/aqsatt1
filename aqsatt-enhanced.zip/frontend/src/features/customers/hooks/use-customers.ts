import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface Customer {
  id: number;
  public_id: string;
  full_name: string;
  phone: string;
  alt_phone: string | null;
  national_id: string | null;
  address: string | null;
  notes: string | null;
  customer_type: "guarantor" | "non_guarantor";
  birth_date: string | null;
  nearest_landmark: string | null;
  status: "active" | "blocked";
  created_at: string;
  receivable_balance: number;
  next_due: string | null;
  is_overdue: boolean;
}

export interface CustomerDetail extends Customer {
  sales: Array<{
    id: number;
    sale_number: string;
    type: "cash" | "installment";
    total_price: number;
    status: "active" | "completed" | "cancelled";
    schedule: Array<{
      installment_number: number;
      due_date: string;
      amount: number;
      paid: number;
      remaining: number;
      status: string;
      late_days: number;
    }>;
  }>;
}

export interface CustomerCreate {
  full_name: string;
  phone: string;
  alt_phone?: string | null;
  national_id?: string | null;
  address?: string | null;
  notes?: string | null;
  customer_type?: "guarantor" | "non_guarantor";
  birth_date?: string | null;
  nearest_landmark?: string | null;
}

export interface CustomerUpdate {
  full_name?: string | null;
  phone?: string | null;
  alt_phone?: string | null;
  national_id?: string | null;
  address?: string | null;
  notes?: string | null;
  customer_type?: "guarantor" | "non_guarantor" | null;
  birth_date?: string | null;
  nearest_landmark?: string | null;
  status?: string | null;
}

export interface Paginated<T> {
  data: T[];
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export function useCustomers(params: { page?: number; page_size?: number; phone?: string; name?: string }) {
  return useQuery<Paginated<Customer>>({
    queryKey: ["customers", "list", params],
    queryFn: () => api.get("/customers", params),
    staleTime: 60000,
  });
}

export function useCustomerDetail(id: number) {
  return useQuery<CustomerDetail>({
    queryKey: ["customers", "detail", id],
    queryFn: () => api.get(`/customers/${id}`),
    enabled: !!id,
  });
}

export function useCreateCustomer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CustomerCreate) => api.post("/customers", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
    },
  });
}

export function useUpdateCustomer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: CustomerUpdate }) => api.patch(`/customers/${id}`, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      queryClient.invalidateQueries({ queryKey: ["customers", "detail", variables.id] });
    },
  });
}
