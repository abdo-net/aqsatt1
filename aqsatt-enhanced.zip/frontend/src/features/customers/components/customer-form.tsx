"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { customerCreateSchema, customerUpdateSchema, type CustomerCreateInput, type CustomerUpdateInput } from "@/shared/lib/zod-schemas";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { useEffect } from "react";

interface CustomerFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customer?: {
    id: number;
    full_name: string;
    phone: string;
    alt_phone: string | null;
    national_id: string | null;
    address: string | null;
    notes: string | null;
    customer_type: "guarantor" | "non_guarantor";
    birth_date: string | null;
    nearest_landmark: string | null;
  } | null;
  onSubmit: (data: CustomerCreateInput | CustomerUpdateInput) => void;
  isLoading?: boolean;
}

const inputCls = "input-cyber w-full px-4 py-3 rounded-xl text-white placeholder:text-white/30";
const labelCls = "block text-sm text-fg-secondary mb-2";

export function CustomerForm({ open, onOpenChange, customer, onSubmit, isLoading }: CustomerFormProps) {
  const isEdit = !!customer;
  const schema = isEdit ? customerUpdateSchema : customerCreateSchema;
  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<CustomerCreateInput | CustomerUpdateInput>({
    resolver: zodResolver(schema),
    defaultValues: {
      full_name: "",
      phone: "",
      alt_phone: null,
      national_id: null,
      address: null,
      notes: null,
      customer_type: "non_guarantor",
      birth_date: null,
      nearest_landmark: null,
    },
  });

  useEffect(() => {
    if (customer) {
      reset({
        full_name: customer.full_name,
        phone: customer.phone,
        alt_phone: customer.alt_phone,
        national_id: customer.national_id,
        address: customer.address,
        notes: customer.notes,
        customer_type: customer.customer_type,
        birth_date: customer.birth_date,
        nearest_landmark: customer.nearest_landmark,
      });
    } else {
      reset({
        full_name: "",
        phone: "",
        alt_phone: null,
        national_id: null,
        address: null,
        notes: null,
        customer_type: "non_guarantor",
        birth_date: null,
        nearest_landmark: null,
      });
    }
  }, [customer, reset]);

  const customerType = watch("customer_type");

  return (
    <CyberModal
      open={open}
      onOpenChange={onOpenChange}
      title={isEdit ? "تعديل العميل" : "عميل جديد"}
      description="أدخل بيانات العميل أدناه"
      accent="cyan"
      size="md"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className={labelCls}>الاسم الكامل *</label>
          <input className={inputCls} {...register("full_name")} />
          {errors.full_name && <p className="text-xs text-red-400 mt-1">{errors.full_name.message}</p>}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>الهاتف *</label>
            <input type="tel" className={inputCls + " num-ltr"} {...register("phone")} />
            {errors.phone && <p className="text-xs text-red-400 mt-1">{errors.phone.message}</p>}
          </div>
          <div>
            <label className={labelCls}>هاتف إضافي</label>
            <input type="tel" className={inputCls + " num-ltr"} {...register("alt_phone")} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>الرقم الوطني</label>
            <input className={inputCls + " num-ltr"} {...register("national_id")} />
          </div>
          <div>
            <label className={labelCls}>نوع العميل</label>
            <select
              value={customerType || "non_guarantor"}
              onChange={(e) => setValue("customer_type", e.target.value as "guarantor" | "non_guarantor")}
              className={inputCls + " bg-bg-elevated appearance-none"}
            >
              <option value="non_guarantor" className="bg-bg-elevated">بدون كفيل</option>
              <option value="guarantor" className="bg-bg-elevated">كفيل (بطاقة كي)</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>تاريخ الميلاد (اختياري)</label>
            <input type="date" className={inputCls + " num-ltr"} {...register("birth_date")} />
          </div>
          <div>
            <label className={labelCls}>أقرب نقطة دالة (اختياري)</label>
            <input className={inputCls} {...register("nearest_landmark")} />
          </div>
        </div>
        <div>
          <label className={labelCls}>العنوان</label>
          <input className={inputCls} {...register("address")} />
        </div>
        <div>
          <label className={labelCls}>ملاحظات</label>
          <input className={inputCls} {...register("notes")} />
        </div>
        <div className="flex gap-4 pt-4 border-t border-white/5">
          <NeonButton type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)} disabled={isLoading}>
            إلغاء
          </NeonButton>
          <NeonButton type="submit" variant="cyan" className="flex-1" loading={isLoading}>
            {isEdit ? "تحديث" : "إضافة"}
          </NeonButton>
        </div>
      </form>
    </CyberModal>
  );
}
