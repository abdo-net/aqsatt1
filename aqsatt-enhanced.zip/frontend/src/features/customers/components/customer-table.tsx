"use client";
import { useState } from "react";
import { useCustomers, type Customer } from "@/features/customers/hooks/use-customers";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { EmptyState, TableSkeleton } from "@/shared/ui/empty-state";
import { formatDate } from "@/shared/lib/formatters";
import Link from "next/link";
import { ChevronRight, ChevronLeft, Pencil, Search, Users } from "lucide-react";

interface CustomerTableProps {
  onEdit: (customer: Customer) => void;
}

export function CustomerTable({ onEdit }: CustomerTableProps) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const pageSize = 50;
  const { data, isLoading } = useCustomers({ page, page_size: pageSize, name: search || undefined });

  const customers = data?.data || [];
  const totalPages = data?.total_pages || 1;

  return (
    <div className="space-y-4">
      <div className="relative max-w-sm">
        <input
          placeholder="بحث بالاسم أو الهاتف..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          className="input-cyber w-full px-4 py-2.5 pr-10 rounded-xl text-white placeholder:text-white/30"
        />
        <Search className="w-4 h-4 text-fg-faint absolute right-3.5 top-1/2 -translate-y-1/2" />
      </div>

      {isLoading ? (
        <TableSkeleton rows={6} cols={6} />
      ) : (
        <div className="rounded-xl border border-white/10 overflow-hidden glass-cyber">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الاسم</TableHead>
                <TableHead>الهاتف</TableHead>
                <TableHead>الدين</TableHead>
                <TableHead>الاستحقاق القادم</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="w-20">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="p-0">
                    <EmptyState icon={Users} title="لا يوجد عملاء" description="لم يتم العثور على عملاء مطابقين" />
                  </TableCell>
                </TableRow>
              ) : (
                customers.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>
                      <Link href={`/customers/${c.id}`} className="font-medium text-white hover:text-[#2563EB] transition-colors">
                        {c.full_name}
                      </Link>
                    </TableCell>
                    <TableCell dir="ltr" className="num-ltr text-fg-secondary">{c.phone}</TableCell>
                    <TableCell className="text-white font-medium"><Num currency>{c.receivable_balance}</Num></TableCell>
                    <TableCell className="text-fg-secondary">{c.next_due ? formatDate(c.next_due) : "—"}</TableCell>
                    <TableCell>
                      {c.is_overdue ? <Badge variant="destructive">متأخر</Badge> : <Badge variant="success">منتظم</Badge>}
                    </TableCell>
                    <TableCell>
                      <button
                        onClick={() => onEdit(c)}
                        className="p-2 rounded-lg text-fg-muted hover:bg-white/5 hover:text-[#2563EB] transition-colors"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="text-sm text-fg-muted num-ltr">{page} / {totalPages}</div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="p-2 rounded-lg glass-cyber disabled:opacity-30 hover:bg-white/5 transition-colors"
          >
            <ChevronRight className="h-4 w-4 text-fg-secondary" />
          </button>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="p-2 rounded-lg glass-cyber disabled:opacity-30 hover:bg-white/5 transition-colors"
          >
            <ChevronLeft className="h-4 w-4 text-fg-secondary" />
          </button>
        </div>
      </div>
    </div>
  );
}
