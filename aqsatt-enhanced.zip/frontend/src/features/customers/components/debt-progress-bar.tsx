"use client";
import { formatCurrency } from "@/shared/lib/formatters";
import { GlassCard } from "@/shared/ui/glass-card";
import { Num } from "@/shared/ui/num";

interface DebtProgressBarProps {
  paidFils: number;
  upcomingFils: number;
  overdueFils: number;
}

export const DebtProgressBar = ({ paidFils, upcomingFils, overdueFils }: DebtProgressBarProps) => {
  const total = paidFils + upcomingFils + overdueFils;
  const getPercentage = (val: number) => (total > 0 ? (val / total) * 100 : 0);

  return (
    <GlassCard padding="sm" className="space-y-3">
      <div className="flex justify-between text-xs font-semibold text-fg-secondary">
        <span>توزيع الالتزامات المالية</span>
        <span className="num-ltr">الإجمالي: <Num>{formatCurrency(total)}</Num></span>
      </div>
      <div className="h-4 w-full rounded-full bg-white/5 overflow-hidden flex">
        <div style={{ width: `${getPercentage(paidFils)}%` }} className="bg-green-500 transition-all duration-300" title="مدفوع" />
        <div style={{ width: `${getPercentage(upcomingFils)}%` }} className="bg-[#2563EB] transition-all duration-300" title="قادم" />
        <div style={{ width: `${getPercentage(overdueFils)}%` }} className="bg-red-500 transition-all duration-300" title="متأخر" />
      </div>
      <div className="grid grid-cols-3 gap-2 pt-1 text-center text-xs num-ltr">
        <div className="text-green-400 font-medium">مدفوع: <Num>{formatCurrency(paidFils)}</Num></div>
        <div className="text-[#2563EB] font-medium">قادم: <Num>{formatCurrency(upcomingFils)}</Num></div>
        <div className="text-red-400 font-medium">متأخر: <Num>{formatCurrency(overdueFils)}</Num></div>
      </div>
    </GlassCard>
  );
};
