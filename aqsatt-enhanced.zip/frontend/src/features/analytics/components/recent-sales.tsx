"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import { ChevronLeft, FileText } from "lucide-react";
import { GlassCard } from "@/shared/ui/glass-card";
import { useSales, type SaleListItem } from "@/features/sales/hooks/use-sales";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { cn } from "@/shared/lib/utils";

type Props = {
  onRowClick?: (sale: SaleListItem) => void;
};

const statusMap: Record<string, { label: string; cls: string }> = {
  active: { label: "نشط", cls: "bg-[rgba(34,197,94,0.1)] text-[#22C55E]" },
  completed: { label: "مكتمل", cls: "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]" },
  cancelled: { label: "ملغي", cls: "bg-[rgba(239,68,68,0.1)] text-[#EF4444]" },
};

const accentColors = ["#2563EB", "#8B5CF6", "#F59E0B", "#EF4444", "#22C55E"];

const initials = (name: string) => name.trim().charAt(0) || "#";
const formatIQD = (n: number) => new Intl.NumberFormat("en-US").format(n);
const formatDate = (iso: string) => {
  try {
    return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short" }).format(new Date(iso));
  } catch {
    return iso;
  }
};

export function RecentSales({ onRowClick }: Props) {
  const router = useRouter();
  const { data, isLoading } = useSales({ page: 1, page_size: 5 });
  const { data: customers } = useCustomers({ page: 1, page_size: 100 });

  const customerNames = useMemo(() => {
    const map = new Map<number, string>();
    customers?.data.forEach((c) => map.set(c.id, c.full_name));
    return map;
  }, [customers]);

  const sales = data?.data ?? [];

  return (
    <GlassCard className="lg:col-span-3 overflow-hidden" padding="none">
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div>
          <h3 className="text-base font-semibold text-white">أحدث المبيعات</h3>
          <p className="text-sm text-fg-muted">آخر 5 معاملات</p>
        </div>
        <button
          type="button"
          onClick={() => router.push("/sales")}
          className="text-[#2563EB] hover:text-[#3B82F6] font-medium text-sm flex items-center gap-1 transition-colors"
        >
          عرض الكل
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      <div className="divide-y divide-white/10">
        {isLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg animate-shimmer" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-1/3 rounded animate-shimmer" />
                <div className="h-3 w-1/4 rounded animate-shimmer" />
              </div>
              <div className="h-6 w-20 rounded animate-shimmer" />
            </div>
          ))
        ) : sales.length === 0 ? (
          <div className="p-12 text-center">
            <FileText className="w-10 h-10 text-fg-faint mx-auto mb-2" />
            <p className="text-fg-muted">لا توجد مبيعات بعد</p>
          </div>
        ) : (
          sales.map((sale, i) => {
            const status = statusMap[sale.status] ?? { label: sale.status, cls: "bg-white/10 text-fg-secondary" };
            const color = accentColors[i % accentColors.length];
            const customerName = customerNames.get(sale.customer_id);
            return (
              <button
                key={sale.id}
                type="button"
                onClick={() => onRowClick?.(sale)}
                className="w-full text-right p-4 hover:bg-white/5 transition-colors flex items-center gap-3"
              >
                <div
                  className="w-10 h-10 shrink-0 rounded-lg flex items-center justify-center font-semibold text-sm"
                  style={{ backgroundColor: `${color}1A`, color }}
                >
                  {initials(customerName ?? sale.sale_number)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white truncate text-sm">{customerName ?? sale.sale_number}</p>
                  <p className="text-[13px] text-fg-muted truncate">
                    {sale.sale_type === "installment" ? "قسط" : "نقدي"} · {sale.sale_number}
                  </p>
                </div>
                <div className="text-left shrink-0">
                  <p className="font-semibold text-white text-sm num-ltr">{formatIQD(sale.total_price)}</p>
                  <p className="text-xs text-fg-muted">IQD</p>
                </div>
                <span className={cn("px-2 py-0.5 rounded-md text-[11px] font-medium shrink-0", status.cls)}>{status.label}</span>
                <span className="text-[13px] text-fg-muted num-ltr shrink-0 hidden md:inline">{formatDate(sale.created_at)}</span>
              </button>
            );
          })
        )}
      </div>
    </GlassCard>
  );
}
