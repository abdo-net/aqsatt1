"use client";

import { useMemo } from "react";
import { ShoppingCart, Banknote, Percent, Clock } from "lucide-react";
import { GlassCard } from "@/shared/ui/glass-card";
import { useDashboardSummary } from "@/features/analytics/hooks/use-dashboard-summary";
import { useSales } from "@/features/sales/hooks/use-sales";
import { usePayments } from "@/features/payments/hooks/use-payments";

function isToday(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

const items = [
  { key: "todaySales" as const, label: "مبيعات اليوم", icon: ShoppingCart, accent: "cyan" },
  { key: "todayPayments" as const, label: "مدفوعات اليوم", icon: Banknote, accent: "green" },
  { key: "collectionRate" as const, label: "نسبة التحصيل", icon: Percent, accent: "purple" },
  { key: "avgCollectionDays" as const, label: "متوسط التحصيل", icon: Clock, accent: "amber" },
];

const accentBar: Record<string, string> = {
  cyan: "from-[#2563EB] to-[#3B82F6]",
  green: "from-[#22C55E] to-[#4ADE80]",
  purple: "from-[#8B5CF6] to-[#A78BFA]",
  amber: "from-[#F59E0B] to-[#FBBF24]",
};
const accentBg: Record<string, string> = {
  cyan: "bg-[rgba(37,99,235,0.1)] text-[#2563EB]",
  green: "bg-[rgba(34,197,94,0.1)] text-[#22C55E]",
  purple: "bg-[rgba(139,92,246,0.1)] text-[#8B5CF6]",
  amber: "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]",
};

export function StatsMini() {
  const { data: summary, isLoading: summaryLoading } = useDashboardSummary();
  const { data: sales, isLoading: salesLoading } = useSales({ page: 1, page_size: 100 });
  const { data: payments, isLoading: paymentsLoading } = usePayments({ limit: 300 });

  const loading = summaryLoading || salesLoading || paymentsLoading;

  const data = useMemo(() => {
    const todaySales = (sales?.data ?? []).filter((s) => isToday(s.created_at)).length;
    const todayPayments = (payments ?? []).filter((p) => p.status === "confirmed" && p.paid_at && isToday(p.paid_at)).length;
    const collected = summary?.total_cash_collected ?? 0;
    const outstanding = summary?.total_outstanding ?? 0;
    const collectionRate = collected + outstanding > 0 ? collected / (collected + outstanding) : 0;
    return { todaySales, todayPayments, collectionRate, avgCollectionDays: 0 };
  }, [sales, payments, summary]);

  const displayValue = (key: typeof items[number]["key"]): string => {
    switch (key) {
      case "todaySales":
        return new Intl.NumberFormat("en-US").format(data.todaySales);
      case "todayPayments":
        return new Intl.NumberFormat("en-US").format(data.todayPayments);
      case "collectionRate":
        return `${(data.collectionRate * 100).toFixed(1)}%`;
      case "avgCollectionDays":
        return `${data.avgCollectionDays.toFixed(1)} يوم`;
    }
  };

  const barWidth = (key: typeof items[number]["key"]): number => {
    if (key === "collectionRate") return data.collectionRate * 100;
    if (key === "todaySales") return Math.min(100, data.todaySales * 8);
    if (key === "todayPayments") return Math.min(100, data.todayPayments * 3);
    if (key === "avgCollectionDays") return 0;
    return 0;
  };

  return (
    <GlassCard>
      <h3 className="text-base font-semibold text-white mb-5 flex items-center gap-2">
        <span className="text-lg">📊</span>
        إحصائيات سريعة
      </h3>

      <div className="space-y-4">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <div key={it.key} className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${accentBg[it.accent]}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-fg-secondary">{it.label}</span>
                  {loading ? (
                    <span className="h-4 w-10 rounded animate-shimmer bg-white/10 inline-block" />
                  ) : (
                    <span className="font-bold text-white num-ltr">{displayValue(it.key)}</span>
                  )}
                </div>
                <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <div
                    className={`h-full rounded-full progress-shine bg-gradient-to-r ${accentBar[it.accent]}`}
                    style={{ width: `${barWidth(it.key)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </GlassCard>
  );
}
