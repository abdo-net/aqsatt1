"use client";

import { useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Phone, AlertOctagon } from "lucide-react";
import { GlassCard } from "@/shared/ui/glass-card";
import { NeonButton } from "@/shared/ui/neon-button";
import { useCustomers } from "@/features/customers/hooks/use-customers";

const initials = (name: string) => name.trim().charAt(0) || "?";
const formatIQD = (n: number) => new Intl.NumberFormat("en-US").format(n);

export function OverdueAccounts() {
  const router = useRouter();
  const { data, isLoading } = useCustomers({ page: 1, page_size: 200 });

  const overdue = useMemo(
    () =>
      (data?.data ?? [])
        .filter((c) => c.is_overdue)
        .sort((a, b) => b.receivable_balance - a.receivable_balance)
        .slice(0, 5),
    [data],
  );

  return (
    <GlassCard className="overflow-hidden" padding="none">
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-[#EF4444]" />
              أبرز المتأخرات
            </h3>
            <p className="text-sm text-[#EF4444] mt-0.5">تحتاج متابعة فورية</p>
          </div>
          {!isLoading && (
            <span className="px-2.5 py-1 bg-[rgba(239,68,68,0.1)] text-[#EF4444] rounded-full text-sm font-semibold num-ltr">
              {overdue.length}
            </span>
          )}
        </div>
      </div>

      <div className="p-3 space-y-2">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-24 rounded-xl animate-shimmer" />)
        ) : overdue.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-fg-muted">لا توجد متأخرات حالياً 🎉</p>
          </div>
        ) : (
          overdue.map((c) => (
            <div key={c.id} className="p-3 rounded-xl bg-[rgba(239,68,68,0.05)] border border-[rgba(239,68,68,0.15)]">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center font-semibold text-sm shrink-0 bg-[rgba(239,68,68,0.1)] text-[#EF4444]">
                    {initials(c.full_name)}
                  </div>
                  <div className="min-w-0">
                    <Link href={`/customers/${c.id}`} className="font-medium text-white text-sm truncate hover:underline">
                      {c.full_name}
                    </Link>
                    <p className="text-xs truncate text-[#EF4444]">{c.next_due ? `مستحق منذ ${c.next_due}` : "متأخر"}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={`tel:${c.phone}`}
                    aria-label={`اتصل بـ ${c.full_name}`}
                    className="p-2 rounded-lg bg-[rgba(239,68,68,0.1)] text-[#EF4444] hover:bg-[rgba(239,68,68,0.2)] transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                  <NeonButton size="sm" variant="green" onClick={() => router.push("/payments")}>
                    دفع
                  </NeonButton>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between">
                <span className="text-lg font-semibold num-ltr text-[#EF4444]">{formatIQD(c.receivable_balance)}</span>
                <span className="text-xs text-fg-muted">IQD</span>
              </div>
            </div>
          ))
        )}
      </div>
    </GlassCard>
  );
}
