"use client";

import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { GlassCard } from "@/shared/ui/glass-card";
import { usePayments } from "@/features/payments/hooks/use-payments";
import { cn } from "@/shared/lib/utils";

const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

function lastNMonthBuckets(n: number) {
  const buckets: { key: string; label: string; collected: number; outstanding: number }[] = [];
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      key: `${d.getFullYear()}-${d.getMonth()}`,
      label: ARABIC_MONTHS[d.getMonth()],
      collected: 0,
      outstanding: 0,
    });
  }
  return buckets;
}

export function CashflowChart() {
  const [period, setPeriod] = useState<"6m" | "1y">("6m");
  const { data, isLoading } = usePayments({ limit: 300 });

  const chartData = useMemo(() => {
    const months = period === "6m" ? 6 : 12;
    const buckets = lastNMonthBuckets(months);
    const byKey = new Map(buckets.map((b) => [b.key, b]));
    (data ?? []).forEach((p) => {
      if (p.status !== "confirmed" || !p.paid_at) return;
      const d = new Date(p.paid_at);
      const key = `${d.getFullYear()}-${d.getMonth()}`;
      const bucket = byKey.get(key);
      if (bucket) bucket.collected += p.amount - p.fee_amount;
    });
    return buckets;
  }, [data, period]);

  return (
    <GlassCard className="lg:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-white">التدفق النقدي</h3>
          <p className="text-sm text-fg-muted">{period === "6m" ? "آخر 6 أشهر" : "السنة الحالية"}</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setPeriod("6m")}
            className={cn(
              "px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors border",
              period === "6m" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-transparent" : "bg-transparent text-fg-muted border-white/10 hover:bg-white/5",
            )}
          >
            6 أشهر
          </button>
          <button
            type="button"
            onClick={() => setPeriod("1y")}
            className={cn(
              "px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors border",
              period === "1y" ? "bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-transparent" : "bg-transparent text-fg-muted border-white/10 hover:bg-white/5",
            )}
          >
            سنة
          </button>
        </div>
      </div>

      <div className="h-64 relative">
        {isLoading ? (
          <div className="absolute inset-0 animate-shimmer rounded-xl" />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <defs>
                <linearGradient id="collectedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity={0.2} />
                </linearGradient>
                <linearGradient id="outstandingGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0.2} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(226,232,240,0.05)" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "#94A3B8", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis
                tick={{ fill: "#94A3B8", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `${Number(v) / 1_000_000}M`}
              />
              <Tooltip
                contentStyle={{ backgroundColor: "#111827", border: "1px solid rgba(226,232,240,0.1)", borderRadius: 8 }}
                labelStyle={{ color: "#fff" }}
                itemStyle={{ color: "#fff" }}
                formatter={(v: number) => `${new Intl.NumberFormat("en-US").format(v)} IQD`}
              />
              <Legend verticalAlign="bottom" formatter={(value) => <span style={{ color: "#94A3B8" }}>{value}</span>} />
              <Bar dataKey="collected" name="المتحصلات" fill="url(#collectedGradient)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="outstanding" name="المستحقات" fill="url(#outstandingGradient)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </GlassCard>
  );
}
