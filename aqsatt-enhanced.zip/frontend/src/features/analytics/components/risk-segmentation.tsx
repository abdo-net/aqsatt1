"use client";

import { useMemo } from "react";
import { GlassCard } from "@/shared/ui/glass-card";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { cn } from "@/shared/lib/utils";

const R = 40;
const C = 2 * Math.PI * R;

const segments = [
  { key: "guarantor" as const, label: "كفيل (بطاقة كي)", color: "#22C55E" },
  { key: "non_guarantor" as const, label: "بدون كفيل", color: "#F59E0B" },
];

export function RiskSegmentation() {
  const { data, isLoading } = useCustomers({ page: 1, page_size: 200 });

  const counts = useMemo(() => {
    const c = { guarantor: 0, non_guarantor: 0 };
    data?.data.forEach((cust) => {
      c[cust.customer_type] += 1;
    });
    return c;
  }, [data]);

  const total = counts.guarantor + counts.non_guarantor;

  const arcs = useMemo(() => {
    if (total === 0) return [];
    let acc = 0;
    return segments.map((seg) => {
      const value = counts[seg.key];
      const portion = value / total;
      const length = C * portion;
      const offset = -C * acc;
      acc += portion;
      return { ...seg, value, portion, length, offset };
    });
  }, [counts, total]);

  const dominant = arcs[0];

  return (
    <GlassCard>
      <h3 className="text-lg font-semibold text-white mb-5">توزيع نوع العملاء</h3>

      <div className="relative w-36 h-36 mx-auto mb-5">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r={R} stroke="rgba(255,255,255,0.05)" strokeWidth="12" fill="none" />
          {arcs.map((seg) => (
            <circle
              key={seg.key}
              cx="50"
              cy="50"
              r={R}
              stroke={seg.color}
              strokeWidth="12"
              fill="none"
              strokeDasharray={`${seg.length} ${C}`}
              strokeDashoffset={seg.offset}
              strokeLinecap="round"
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {isLoading || !dominant ? (
            <div className="w-12 h-6 animate-shimmer rounded bg-white/10" />
          ) : (
            <>
              <span className="text-3xl font-bold text-white num-ltr">{Math.round(dominant.portion * 100)}%</span>
              <span className="text-xs text-fg-muted">{dominant.label}</span>
            </>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {arcs.length === 0 ? (
          <div className="h-20 animate-shimmer rounded-xl bg-white/5" />
        ) : (
          arcs.map((seg) => (
            <div key={seg.key} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full" style={{ background: seg.color }} />
                <span className="font-medium text-fg-secondary">{seg.label}</span>
              </div>
              <div className="text-left">
                <span className="font-semibold text-white num-ltr">{new Intl.NumberFormat("en-US").format(seg.value)}</span>
                <span className="text-xs text-fg-muted mr-1 num-ltr">({Math.round(seg.portion * 100)}%)</span>
              </div>
            </div>
          ))
        )}
      </div>
    </GlassCard>
  );
}
