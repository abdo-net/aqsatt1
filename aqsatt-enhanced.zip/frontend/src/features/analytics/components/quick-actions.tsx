"use client";

import { UserPlus, FilePlus, DollarSign, PackagePlus, type LucideIcon } from "lucide-react";
import { cn } from "@/shared/lib/utils";

export type QuickActionKey = "customer" | "sale" | "payment" | "product";

type Props = {
  onAction: (key: QuickActionKey) => void;
  className?: string;
};

const actions: {
  key: QuickActionKey;
  label: string;
  subtitle: string;
  icon: LucideIcon;
  color: string;
}[] = [
  { key: "customer", label: "عميل جديد", subtitle: "إضافة عميل", icon: UserPlus, color: "#2563EB" },
  { key: "sale", label: "بيع جديد", subtitle: "إنشاء طلب بيع", icon: FilePlus, color: "#EC4899" },
  { key: "payment", label: "استلام دفعة", subtitle: "عرض السجل", icon: DollarSign, color: "#22C55E" },
  { key: "product", label: "منتج جديد", subtitle: "إضافة للكتالوج", icon: PackagePlus, color: "#8B5CF6" },
];

export function QuickActions({ onAction, className }: Props) {
  return (
    <div className={cn("glass-cyber rounded-xl p-4", className)}>
      <h3 className="text-base font-semibold text-white mb-3">إجراءات سريعة</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {actions.map(({ key, label, subtitle, icon: Icon, color }) => (
          <button
            key={key}
            type="button"
            onClick={() => onAction(key)}
            className="btn-cyber flex flex-col items-center gap-2 rounded-xl border border-white/10 bg-[#111827] p-4 text-center hover:bg-white/5 transition-colors"
          >
            <Icon size={22} style={{ color }} />
            <div>
              <div className="text-sm font-medium text-white">{label}</div>
              <div className="mt-0.5 text-xs text-fg-muted">{subtitle}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
