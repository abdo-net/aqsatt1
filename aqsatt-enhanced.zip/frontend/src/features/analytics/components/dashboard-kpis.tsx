"use client";

import {
  Wallet,
  Banknote,
  Receipt,
  AlertTriangle,
  Users,
  ShoppingCart,
} from "lucide-react";
import { KpiCard } from "@/shared/ui/kpi-card";
import { useDashboardSummary } from "@/features/analytics/hooks/use-dashboard-summary";

const formatIQD = (n: number) => new Intl.NumberFormat("en-US").format(n);

export function DashboardKpis() {
  const { data, isLoading } = useDashboardSummary();

  const cards = [
    {
      label: "إجمالي المستحقات",
      value: data ? formatIQD(data.total_outstanding) : "—",
      unit: "IQD",
      icon: Wallet,
      accent: "cyan" as const,
    },
    {
      label: "المتحصلات النقدية",
      value: data ? formatIQD(data.total_cash_collected) : "—",
      unit: "IQD",
      icon: Banknote,
      accent: "green" as const,
    },
    {
      label: "مدفوعات اليوم",
      value: data ? formatIQD(data.today_payments) : "—",
      unit: "IQD",
      icon: Receipt,
      accent: "purple" as const,
    },
    {
      label: "العملاء",
      value: data ? formatIQD(data.customers_count) : "—",
      unit: "عميل",
      icon: Users,
      accent: "pink" as const,
    },
    {
      label: "المبيعات النشطة",
      value: data ? formatIQD(data.active_sales_count) : "—",
      unit: "بيع",
      icon: ShoppingCart,
      accent: "amber" as const,
    },
    {
      label: "المتأخرات",
      value: data ? formatIQD(data.overdue_count) : "—",
      unit: "حالة",
      icon: AlertTriangle,
      accent: "red" as const,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
      {cards.map((c) => (
        <KpiCard
          key={c.label}
          label={c.label}
          value={c.value}
          unit={c.unit}
          icon={c.icon}
          accent={c.accent}
          loading={isLoading}
        />
      ))}
    </div>
  );
}
