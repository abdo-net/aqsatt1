"use client";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface DashboardSummary {
  total_outstanding: number;
  total_cash_collected: number;
  today_payments: number;
  overdue_count: number;
  customers_count: number;
  active_sales_count: number;
}

export function useDashboardSummary() {
  return useQuery<DashboardSummary>({
    queryKey: ["dashboard", "summary"],
    queryFn: () => api.get("/dashboard/summary"),
    refetchInterval: 300000,
  });
}
