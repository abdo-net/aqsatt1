"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { profileUpdateSchema, type ProfileUpdateInput } from "@/shared/lib/zod-schemas";
import { useUpdateProfile, useProfile } from "@/features/settings/hooks/use-settings";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Label } from "@/shared/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/shared/ui/card";
import { toast } from "react-hot-toast";
import { useEffect } from "react";

export function ProfileForm() {
  const { data: profile } = useProfile();
  const updateProfile = useUpdateProfile();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ProfileUpdateInput>({
    resolver: zodResolver(profileUpdateSchema),
  });

  useEffect(() => {
    if (profile) {
      reset({ name: profile.name });
    }
  }, [profile, reset]);

  const onSubmit = (data: ProfileUpdateInput) => {
    updateProfile.mutate(data, {
      onSuccess: () => toast.success("Profile updated"),
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input {...register("name")} />
            {errors.name && <p className="text-xs text-red-600">{errors.name.message}</p>}
          </div>
          <div className="space-y-2">
            <Label>Username</Label>
            <Input value={profile?.username || ""} disabled />
          </div>
          <Button type="submit" loading={updateProfile.isPending} size="sm">Update Profile</Button>
        </form>
      </CardContent>
    </Card>
  );
}
