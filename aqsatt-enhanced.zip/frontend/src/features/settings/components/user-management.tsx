"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { userCreateSchema, type UserCreateInput } from "@/shared/lib/zod-schemas";
import { useUsers, useCreateUser, useDeleteUser, useRoles } from "@/features/settings/hooks/use-users";
import { useProfile } from "@/features/settings/hooks/use-settings";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Label } from "@/shared/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/shared/ui/select";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { Badge } from "@/shared/ui/badge";
import { Skeleton } from "@/shared/ui/skeleton";
import { Card, CardContent } from "@/shared/ui/card";
import { toast } from "react-hot-toast";
import { Plus, Trash2 } from "lucide-react";

export function UserManagement() {
  const { data: profile } = useProfile();
  const isAdmin = profile?.permissions?.includes("users.manage");
  const [showForm, setShowForm] = useState(false);
  const { data, isLoading } = useUsers();
  const { data: roles } = useRoles();
  const createUser = useCreateUser();
  const deleteUser = useDeleteUser();

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<UserCreateInput>({
    resolver: zodResolver(userCreateSchema),
  });

  const roleId = watch("role_id");

  const onSubmit = (data: UserCreateInput) => {
    createUser.mutate(data, {
      onSuccess: () => {
        toast.success("User created");
        reset();
        setShowForm(false);
      },
    });
  };

  const users = data || [];

  if (!isAdmin) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          You do not have permission to manage users.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">User Management</h2>
        <Button size="sm" onClick={() => setShowForm((s) => !s)}>
          <Plus className="h-4 w-4 mr-1" />
          {showForm ? "Cancel" : "Add User"}
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Name *</Label>
                <Input {...register("name")} />
                {errors.name && <p className="text-xs text-red-600">{errors.name.message}</p>}
              </div>
              <div className="space-y-2">
                <Label>Username *</Label>
                <Input {...register("username")} />
                {errors.username && <p className="text-xs text-red-600">{errors.username.message}</p>}
              </div>
              <div className="space-y-2">
                <Label>Password *</Label>
                <Input type="password" {...register("password")} />
                {errors.password && <p className="text-xs text-red-600">{errors.password.message}</p>}
              </div>
              <div className="space-y-2">
                <Label>Role *</Label>
                <Select value={roleId?.toString() || ""} onValueChange={(v) => setValue("role_id", parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role..." />
                  </SelectTrigger>
                  <SelectContent>
                    {roles?.map((r) => (
                      <SelectItem key={r.id} value={r.id.toString()}>{r.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.role_id && <p className="text-xs text-red-600">{errors.role_id.message}</p>}
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <Button type="submit" loading={createUser.isPending} size="sm">Create User</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-2">
          <Skeleton className="h-10" />
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-12" />
          ))}
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Username</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-20">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No users found.
                  </TableCell>
                </TableRow>
              ) : (
                users.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.name}</TableCell>
                    <TableCell>{u.username}</TableCell>
                    <TableCell><Badge variant="outline">{u.role_name ?? "—"}</Badge></TableCell>
                    <TableCell>
                      <Badge variant={u.is_active ? "success" : "secondary"}>{u.is_active ? "Active" : "Inactive"}</Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (confirm(`Delete user ${u.name}?`)) {
                            deleteUser.mutate(u.id, { onSuccess: () => toast.success("User deleted") });
                          }
                        }}
                        disabled={u.id === profile?.id}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
