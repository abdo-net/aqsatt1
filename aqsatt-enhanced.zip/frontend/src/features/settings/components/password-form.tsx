"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { passwordChangeSchema, type PasswordChangeInput } from "@/shared/lib/zod-schemas";
import { useChangePassword } from "@/features/settings/hooks/use-settings";
import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import { Label } from "@/shared/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/shared/ui/card";
import { toast } from "react-hot-toast";

export function PasswordForm() {
  const changePassword = useChangePassword();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<PasswordChangeInput>({
    resolver: zodResolver(passwordChangeSchema),
  });

  const onSubmit = (data: PasswordChangeInput) => {
    changePassword.mutate(
      { old_password: data.old_password, new_password: data.new_password },
      {
        onSuccess: () => {
          toast.success("Password changed successfully");
          reset();
        },
        onError: () => {
          toast.error("Failed to change password. Check your current password.");
        },
      }
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Change Password</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label>Current Password</Label>
            <Input type="password" {...register("old_password")} />
            {errors.old_password && <p className="text-xs text-red-600">{errors.old_password.message}</p>}
          </div>
          <div className="space-y-2">
            <Label>New Password</Label>
            <Input type="password" {...register("new_password")} />
            {errors.new_password && <p className="text-xs text-red-600">{errors.new_password.message}</p>}
          </div>
          <div className="space-y-2">
            <Label>Confirm New Password</Label>
            <Input type="password" {...register("confirm_password")} />
            {errors.confirm_password && <p className="text-xs text-red-600">{errors.confirm_password.message}</p>}
          </div>
          <Button type="submit" loading={changePassword.isPending} size="sm">Change Password</Button>
        </form>
      </CardContent>
    </Card>
  );
}
