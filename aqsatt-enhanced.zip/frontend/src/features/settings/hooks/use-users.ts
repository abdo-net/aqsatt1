"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface User {
  id: number;
  name: string;
  username: string;
  is_active: boolean;
  role_id: number | null;
  role_name: string | null;
  created_at: string;
}

export interface Role {
  id: number;
  name: string;
  description: string | null;
  is_system: boolean;
  permissions: string[];
}

export function useUsers() {
  return useQuery<User[]>({
    queryKey: ["users", "list"],
    queryFn: () => api.get("/users"),
    staleTime: 60000,
  });
}

export function useRoles() {
  return useQuery<Role[]>({
    queryKey: ["roles"],
    queryFn: () => api.get("/roles"),
    staleTime: 10 * 60 * 1000,
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: { name: string; username: string; password: string; role_id: number }) => api.post("/users", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });
}

export function useDeactivateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    // Backend never hard-deletes users; deactivation = PATCH is_active=false.
    mutationFn: (id: number) => api.patch(`/users/${id}`, { is_active: false }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });
}

// Backward-compatible alias for existing imports.
export const useDeleteUser = useDeactivateUser;
