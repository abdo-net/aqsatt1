"use client";
import { usePayments } from "@/features/payments/hooks/use-payments";
import { useCustomers } from "@/features/customers/hooks/use-customers";
import { useSales } from "@/features/sales/hooks/use-sales";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/shared/ui/table";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { Skeleton } from "@/shared/ui/skeleton";
import { Button } from "@/shared/ui/button";
import { formatDateTime } from "@/shared/lib/formatters";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";

interface PaymentHistoryProps {
  saleId?: number;
  customerId?: number;
}

export function PaymentHistory({ saleId, customerId }: PaymentHistoryProps) {
  const [page, setPage] = useState(1);
  const pageSize = 20;
  const { data, isLoading } = usePayments({
    limit: 300,
    sale_id: saleId,
    customer_id: customerId,
  });
  const { data: customers } = useCustomers({ page: 1, page_size: 100 });
  const { data: sales } = useSales({ page: 1, page_size: 100 });

  const customerNames = useMemo(() => {
    const map = new Map<number, string>();
    customers?.data.forEach((c) => map.set(c.id, c.full_name));
    return map;
  }, [customers]);
  const saleNumbers = useMemo(() => {
    const map = new Map<number, string>();
    sales?.data.forEach((s) => map.set(s.id, s.sale_number));
    return map;
  }, [sales]);

  if (isLoading) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-10" />
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-12" />
        ))}
      </div>
    );
  }

  const allPayments = data || [];
  const totalPages = Math.max(1, Math.ceil(allPayments.length / pageSize));
  const payments = allPayments.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Sale #</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Method</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Receipt #</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {payments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                  No payments found.
                </TableCell>
              </TableRow>
            ) : (
              payments.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="text-xs">{p.paid_at ? formatDateTime(p.paid_at) : "—"}</TableCell>
                  <TableCell className="font-medium">{saleNumbers.get(p.sale_id) ?? "—"}</TableCell>
                  <TableCell>{customerNames.get(p.customer_id) ?? "—"}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">{p.payment_method}</Badge>
                  </TableCell>
                  <TableCell><Num currency>{p.amount}</Num></TableCell>
                  <TableCell className="text-xs text-muted-foreground">{p.receipt_number}</TableCell>
                  <TableCell>
                    <Badge variant={p.status === "confirmed" ? "success" : p.status === "pending" ? "secondary" : "destructive"} className="capitalize">
                      {p.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">Page {page} of {totalPages}</div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
