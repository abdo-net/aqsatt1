"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { paymentCreateSchema, type PaymentCreateInput } from "@/shared/lib/zod-schemas";
import { useCreatePayment, useSaleSchedule } from "@/features/payments/hooks/use-payments";
import { FifoAllocation } from "./fifo-allocation";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { Num } from "@/shared/ui/num";
import { generateIdempotencyKey } from "@/shared/lib/formatters";
import { toast } from "react-hot-toast";

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saleId: number | null;
  defaultAmount?: number;
}

const inputCls = "input-cyber w-full px-4 py-3 rounded-xl text-white placeholder:text-white/30";
const labelCls = "block text-sm text-fg-secondary mb-2";

const methodLabels: Record<PaymentCreateInput["payment_method"], string> = {
  cash: "نقدي",
  qi: "QI",
  transfer: "حوالة بنكية",
  zaincash: "ZainCash",
  visa: "فيزا",
};

export function PaymentModal({ open, onOpenChange, saleId, defaultAmount = 0 }: PaymentModalProps) {
  const { data: schedule } = useSaleSchedule(saleId);
  const createPayment = useCreatePayment();
  const [amount, setAmount] = useState(defaultAmount);

  const { register, handleSubmit, setValue, watch, formState: { errors }, reset } = useForm<PaymentCreateInput>({
    resolver: zodResolver(paymentCreateSchema),
    defaultValues: {
      idempotency_key: generateIdempotencyKey(),
      sale_id: saleId || 0,
      amount: defaultAmount,
      payment_method: "cash",
      reference_number: null,
      source: "manual",
    },
  });

  const paymentMethod = watch("payment_method");

  const totalOutstanding = schedule?.installments.reduce((s, i) => s + i.remaining, 0) || 0;

  const onSubmit = (data: PaymentCreateInput) => {
    if (!saleId) {
      toast.error("لم يتم اختيار عملية بيع");
      return;
    }
    if (data.amount <= 0) {
      toast.error("يجب أن يكون المبلغ أكبر من صفر");
      return;
    }
    createPayment.mutate({
      ...data,
      sale_id: saleId,
      idempotency_key: generateIdempotencyKey(),
    }, {
      onSuccess: () => {
        toast.success("تم تسجيل الدفعة بنجاح");
        reset();
        setAmount(0);
        onOpenChange(false);
      },
    });
  };

  return (
    <CyberModal
      open={open}
      onOpenChange={onOpenChange}
      title="تسجيل دفعة"
      description={schedule ? `العملية ${schedule.sale_number} — العميل: ${schedule.customer_name}` : "سجّل دفعة جديدة لهذه العملية"}
      accent="green"
      size="lg"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>المبلغ *</label>
            <input
              type="number"
              className={inputCls + " num-ltr"}
              {...register("amount", { valueAsNumber: true })}
              onChange={(e) => {
                const val = parseInt(e.target.value) || 0;
                setAmount(val);
                setValue("amount", val);
              }}
              min={1}
            />
            {errors.amount && <p className="text-xs text-red-400 mt-1">{errors.amount.message}</p>}
          </div>
          <div>
            <label className={labelCls}>طريقة الدفع *</label>
            <select
              value={paymentMethod}
              onChange={(e) => setValue("payment_method", e.target.value as PaymentCreateInput["payment_method"])}
              className={inputCls + " bg-bg-elevated appearance-none"}
            >
              {Object.entries(methodLabels).map(([value, label]) => (
                <option key={value} value={value} className="bg-bg-elevated">
                  {label}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <label className={labelCls}>رقم المرجع</label>
          <input className={inputCls} {...register("reference_number")} placeholder="رقم العملية أو الإيصال..." />
        </div>
        <div className="flex justify-between items-center text-sm rounded-xl p-4 bg-white/5 border border-white/10">
          <span className="text-fg-muted">إجمالي المتبقي</span>
          <span className="font-bold text-white num-ltr"><Num currency>{totalOutstanding}</Num></span>
        </div>
        {schedule && schedule.installments.length > 0 && amount > 0 && (
          <FifoAllocation installments={schedule.installments} inputAmount={amount} />
        )}
        <div className="flex gap-4 pt-4 border-t border-white/5">
          <NeonButton type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)} disabled={createPayment.isPending}>
            إلغاء
          </NeonButton>
          <NeonButton type="submit" variant="green" className="flex-1" loading={createPayment.isPending}>
            تسجيل الدفعة
          </NeonButton>
        </div>
      </form>
    </CyberModal>
  );
}
