"use client";
import { computeFifoAllocation, formatCurrency } from "@/shared/lib/formatters";
import { Num } from "@/shared/ui/num";
import { cn } from "@/shared/lib/utils";

interface FifoAllocationProps {
  installments: Array<{
    installment_number: number;
    amount: number;
    paid: number;
    remaining: number;
    status: string;
  }>;
  inputAmount: number;
}

export function FifoAllocation({ installments, inputAmount }: FifoAllocationProps) {
  if (!installments || installments.length === 0) return null;

  const allocated = computeFifoAllocation(installments, inputAmount);
  const totalRemaining = installments.reduce((s, i) => s + i.remaining, 0);
  const fullyCovered = inputAmount >= totalRemaining;

  return (
    <div className="space-y-3 rounded-xl p-4 bg-purple-500/5 border border-purple-500/20">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium text-fg-secondary">معاينة توزيع الدفعة (FIFO)</span>
        <span className={cn("font-semibold", fullyCovered ? "text-green-400" : "text-fg-muted")}>
          {fullyCovered ? "يغطي كامل المتبقي" : `يغطي ${formatCurrency(inputAmount)} من ${formatCurrency(totalRemaining)}`}
        </span>
      </div>
      <div className="space-y-2">
        {allocated.map((inst) => {
          const pctPaid = inst.amount > 0 ? ((inst.paid + inst.visualAllocation) / inst.amount) * 100 : 0;
          const isPartial = inst.visualStatus === "PARTIALLY_PAID";
          const isFullyPaid = inst.visualStatus === "FULLY_PAID";
          return (
            <div key={inst.installment_number} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-fg-muted">قسط #{inst.installment_number}</span>
                <span className="font-medium text-white num-ltr">
                  <Num currency>{inst.paid + inst.visualAllocation}</Num> / <Num currency>{inst.amount}</Num>
                </span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-white/5 overflow-hidden flex">
                <div
                  className={cn(
                    "h-full transition-all progress-shine",
                    isFullyPaid ? "bg-green-500" : isPartial ? "bg-amber-400" : "bg-white/10"
                  )}
                  style={{ width: `${Math.min(100, pctPaid)}%` }}
                />
              </div>
              {isPartial && (
                <div className="text-[10px] text-amber-400 font-medium">
                  +{formatCurrency(inst.visualAllocation)} دفعة جزئية
                </div>
              )}
              {isFullyPaid && inst.visualAllocation > 0 && (
                <div className="text-[10px] text-green-400 font-medium">
                  +{formatCurrency(inst.visualAllocation)} دفعة كاملة
                </div>
              )}
            </div>
          );
        })}
      </div>
      {inputAmount > totalRemaining && (
        <div className="text-xs text-red-400 bg-red-500/10 p-2 rounded border border-red-500/30">
          تنبيه: المبلغ المدفوع يتجاوز إجمالي المتبقي بـ {formatCurrency(inputAmount - totalRemaining)}. سيتم تسجيل الفائض كدفعة زائدة.
        </div>
      )}
    </div>
  );
}
