"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface PaymentAllocation {
  installment_number: number | null;
  amount: number;
}

export interface Payment {
  id: number;
  receipt_number: string;
  sale_id: number;
  customer_id: number;
  amount: number;
  fee_amount: number;
  payment_method: "cash" | "qi" | "transfer" | "zaincash" | "visa";
  status: "pending" | "confirmed" | "failed" | "reversed";
  paid_at: string | null;
  allocations: PaymentAllocation[];
}

export interface InstallmentRow {
  installment_number: number;
  due_date: string;
  amount: number;
  paid: number;
  remaining: number;
  status: "pending" | "partially_paid" | "paid" | "late" | "cancelled";
  late_days: number;
}

export interface SaleSchedule {
  id: number;
  sale_number: string;
  customer_name: string;
  total_price: number;
  down_payment: number;
  installments: InstallmentRow[];
}

export interface PaymentCreate {
  idempotency_key: string;
  sale_id: number;
  amount: number;
  payment_method: "cash" | "qi" | "transfer" | "zaincash" | "visa";
  reference_number?: string | null;
  source?: "manual" | "api" | "external";
}

export function usePayments(params: { limit?: number; sale_id?: number; customer_id?: number }) {
  return useQuery<Payment[]>({
    queryKey: ["payments", "list", params],
    queryFn: () => api.get("/payments", params),
    staleTime: 30000,
  });
}

export function useSaleSchedule(saleId: number | null) {
  return useQuery<SaleSchedule>({
    queryKey: ["sales", "schedule", saleId],
    queryFn: () => api.get(`/sales/${saleId}/schedule`),
    enabled: !!saleId,
  });
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: PaymentCreate) => api.post("/payments", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["payments"] });
      queryClient.invalidateQueries({ queryKey: ["sales"] });
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["ledger"] });
    },
  });
}
