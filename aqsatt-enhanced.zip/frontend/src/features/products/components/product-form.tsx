"use client";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { productCreateSchema, type ProductCreateInput } from "@/shared/lib/zod-schemas";
import { CyberModal } from "@/shared/ui/cyber-modal";
import { NeonButton } from "@/shared/ui/neon-button";
import { useCategories } from "@/features/products/hooks/use-categories";
import { Plus, Trash2 } from "lucide-react";

interface ProductFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: ProductCreateInput) => void;
  isLoading?: boolean;
}

const inputCls = "input-cyber w-full px-4 py-3 rounded-xl text-white placeholder:text-white/30";
const labelCls = "block text-sm text-fg-secondary mb-2";

export function ProductForm({ open, onOpenChange, onSubmit, isLoading }: ProductFormProps) {
  const { data: categories } = useCategories();
  const { register, handleSubmit, control, setValue, watch, formState: { errors } } = useForm<ProductCreateInput>({
    resolver: zodResolver(productCreateSchema),
    defaultValues: {
      sku: "",
      name: "",
      name_ar: null,
      category_id: null,
      base_price: null,
      stock_quantity: 0,
      description: null,
      brand: null,
      tags: null,
      status: "active",
      variants: [],
    },
  });

  const { fields, append, remove } = useFieldArray({ control, name: "variants" });
  const status = watch("status");
  const categoryId = watch("category_id");

  return (
    <CyberModal
      open={open}
      onOpenChange={onOpenChange}
      title="منتج جديد"
      description="أنشئ منتجاً جديداً مع متغيراته"
      accent="purple"
      size="xl"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>SKU *</label>
            <input className={inputCls + " num-ltr"} {...register("sku")} />
            {errors.sku && <p className="text-xs text-red-400 mt-1">{errors.sku.message}</p>}
          </div>
          <div>
            <label className={labelCls}>الحالة</label>
            <select
              value={status || "active"}
              onChange={(e) => setValue("status", e.target.value as "active" | "draft")}
              className={inputCls + " bg-bg-elevated appearance-none"}
            >
              <option value="active" className="bg-bg-elevated">نشط</option>
              <option value="draft" className="bg-bg-elevated">مسودة</option>
            </select>
          </div>
        </div>
        <div>
          <label className={labelCls}>الاسم *</label>
          <input className={inputCls} {...register("name")} />
          {errors.name && <p className="text-xs text-red-400 mt-1">{errors.name.message}</p>}
        </div>
        <div>
          <label className={labelCls}>الاسم بالعربية</label>
          <input className={inputCls} {...register("name_ar")} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>الفئة</label>
            <select
              value={categoryId?.toString() || ""}
              onChange={(e) => setValue("category_id", e.target.value ? parseInt(e.target.value) : null)}
              className={inputCls + " bg-bg-elevated appearance-none"}
            >
              <option value="" className="bg-bg-elevated">اختر...</option>
              {categories?.map((c) => (
                <option key={c.id} value={c.id} className="bg-bg-elevated">
                  {c.name_ar || c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={labelCls}>العلامة التجارية</label>
            <input className={inputCls} {...register("brand")} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>السعر الأساسي</label>
            <input type="number" className={inputCls + " num-ltr"} {...register("base_price", { valueAsNumber: true })} />
          </div>
          <div>
            <label className={labelCls}>الكمية المتوفرة</label>
            <input type="number" className={inputCls + " num-ltr"} {...register("stock_quantity", { valueAsNumber: true })} />
          </div>
        </div>
        <div>
          <label className={labelCls}>الوسوم</label>
          <input className={inputCls} {...register("tags")} placeholder="مفصولة بفواصل" />
        </div>
        <div>
          <label className={labelCls}>الوصف</label>
          <input className={inputCls} {...register("description")} />
        </div>

        <div className="rounded-xl border border-white/10 p-4 space-y-3 bg-white/5">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-white">المتغيرات</span>
            <button
              type="button"
              onClick={() =>
                append({ sku: "", price_cash: 0, price_installment: null, compare_price: null, cost_price: null, stock_quantity: 0, attributes: {}, is_default: false })
              }
              className="text-xs px-3 py-1.5 rounded-lg bg-[rgba(37,99,235,0.1)] text-[#2563EB] hover:bg-[rgba(37,99,235,0.2)] transition-colors flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              إضافة متغير
            </button>
          </div>
          {fields.map((field, index) => (
            <div key={field.id} className="grid grid-cols-12 gap-2 items-end pb-3 border-b border-white/5 last:border-0">
              <div className="col-span-3">
                <span className="text-xs text-fg-muted">SKU</span>
                <input className={inputCls + " py-2 num-ltr"} {...register(`variants.${index}.sku` as const)} />
              </div>
              <div className="col-span-3">
                <span className="text-xs text-fg-muted">سعر النقد *</span>
                <input type="number" className={inputCls + " py-2 num-ltr"} {...register(`variants.${index}.price_cash` as const, { valueAsNumber: true })} />
              </div>
              <div className="col-span-3">
                <span className="text-xs text-fg-muted">المخزون</span>
                <input type="number" className={inputCls + " py-2 num-ltr"} {...register(`variants.${index}.stock_quantity` as const, { valueAsNumber: true })} />
              </div>
              <div className="col-span-2 flex flex-col items-center">
                <span className="text-xs text-fg-muted mb-2">افتراضي</span>
                <input type="checkbox" {...register(`variants.${index}.is_default` as const)} className="h-5 w-5 accent-[#2563EB]" />
              </div>
              <div className="col-span-1">
                <button type="button" onClick={() => remove(index)} className="p-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-colors">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-4 pt-4 border-t border-white/5">
          <NeonButton type="button" variant="outline" className="flex-1" onClick={() => onOpenChange(false)} disabled={isLoading}>
            إلغاء
          </NeonButton>
          <NeonButton type="submit" variant="purple" className="flex-1" loading={isLoading}>
            إنشاء المنتج
          </NeonButton>
        </div>
      </form>
    </CyberModal>
  );
}
