"use client";
import { type Variant } from "@/features/products/hooks/use-products";
import { cn } from "@/shared/lib/utils";

interface VariantSelectorProps {
  variants: Variant[];
  selectedVariantId: number | null;
  onSelect: (variantId: number) => void;
}

export function VariantSelector({ variants, selectedVariantId, onSelect }: VariantSelectorProps) {
  const attributeKeys = Array.from(new Set(variants.flatMap((v) => Object.keys(v.attributes || {}))));

  if (attributeKeys.length === 0) return null;

  return (
    <div className="space-y-2 mb-3">
      {attributeKeys.map((key) => {
        const values = Array.from(new Set(variants.map((v) => v.attributes?.[key]).filter(Boolean)));
        return (
          <div key={key} className="space-y-1">
            <span className="text-xs font-medium text-fg-muted capitalize">{key}</span>
            <div className="flex flex-wrap gap-1.5">
              {values.map((value) => {
                const variantForValue = variants.find((v) => v.attributes?.[key] === value);
                const isActive = variantForValue?.id === selectedVariantId;
                const isColor = key.toLowerCase() === "color";

                return (
                  <button
                    key={value}
                    type="button"
                    onClick={() => variantForValue && onSelect(variantForValue.id)}
                    className={cn(
                      "rounded-lg border text-xs px-2.5 py-1 transition-colors",
                      isActive
                        ? "border-transparent bg-[rgba(37,99,235,0.1)] text-[#2563EB]"
                        : "border-white/10 bg-white/5 hover:bg-white/10 text-fg-secondary",
                    )}
                    title={value}
                  >
                    {isColor && value.startsWith("#") ? (
                      <span className="flex items-center gap-1.5">
                        <span className="h-3 w-3 rounded-full border border-white/20" style={{ backgroundColor: value }} />
                        <span className="sr-only">{value}</span>
                      </span>
                    ) : (
                      value
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
