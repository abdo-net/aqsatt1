"use client";
import { useProductDetail, type ProductCard as ProductCardType } from "@/features/products/hooks/use-products";
import { GlassCard } from "@/shared/ui/glass-card";
import { Badge } from "@/shared/ui/badge";
import { Num } from "@/shared/ui/num";
import { useState } from "react";
import { VariantSelector } from "./variant-selector";
import Link from "next/link";
import { ImageOff } from "lucide-react";

interface ProductCardProps {
  product: ProductCardType;
  onSelect?: (productId: number, variantId: number | null, priceCash: number, priceInstallment: number, name: string, variantName: string) => void;
  selectable?: boolean;
}

export function ProductCard({ product, onSelect, selectable }: ProductCardProps) {
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const { data: detail } = useProductDetail(product.id);

  const variants = detail?.variants || [];
  const selectedVariant = variants.find((v) => v.id === selectedVariantId) || variants.find((v) => v.is_default) || variants[0];

  const imageUrl = product.primary_image?.thumb_path || product.primary_image?.path || null;
  const discountPct = product.discount_pct || 0;
  const isOutOfStock = (selectedVariant?.stock_quantity || 0) <= 0;

  const handleVariantSelect = (variantId: number) => {
    setSelectedVariantId(variantId);
  };

  const handleAddToCart = () => {
    if (!onSelect || !selectedVariant) return;
    onSelect(
      product.id,
      selectedVariant.id,
      selectedVariant.price_cash,
      selectedVariant.price_installment,
      product.name,
      Object.values(selectedVariant.attributes).join(" / ") || "افتراضي",
    );
  };

  const titleEl = (
    <h3 className="font-semibold text-sm mb-1 line-clamp-2 text-white">{product.name_ar || product.name}</h3>
  );

  return (
    <GlassCard lift padding="none" className="overflow-hidden flex flex-col">
      <div className="relative aspect-square bg-white/5">
        {imageUrl ? (
          <img src={imageUrl} alt={product.name} className="object-cover w-full h-full" />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-fg-faint gap-2">
            <ImageOff className="w-8 h-8" />
            <span className="text-xs">بلا صورة</span>
          </div>
        )}
        {discountPct > 0 && (
          <Badge variant="destructive" className="absolute top-2 right-2">{discountPct}%-</Badge>
        )}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <Badge variant="secondary" className="text-sm">نفذ المخزون</Badge>
          </div>
        )}
      </div>
      <div className="p-4 flex flex-col flex-1">
        {selectable ? (
          titleEl
        ) : (
          <Link href={`/products/${product.id}`} className="hover:underline">
            {titleEl}
          </Link>
        )}
        <p className="text-xs text-fg-muted mb-2 num-ltr">{product.sku}</p>

        {variants.length > 1 && detail && (
          <VariantSelector variants={variants} selectedVariantId={selectedVariant?.id || null} onSelect={handleVariantSelect} />
        )}

        <div className="mt-auto pt-3 space-y-1">
          <div className="flex justify-between items-baseline">
            <span className="text-xs text-fg-muted">نقدي:</span>
            <span className="text-sm font-bold text-white"><Num currency>{selectedVariant?.price_cash || product.price_cash}</Num></span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-xs text-fg-muted">تقسيط:</span>
            <span className="text-xs font-semibold text-[#2563EB]">
              <Num currency>{selectedVariant?.price_installment || product.price_installment}</Num>/شهر
            </span>
          </div>
        </div>

        {selectable && (
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className="btn-cyber mt-3 w-full h-9 rounded-lg bg-[#2563EB] text-white text-sm font-medium hover:bg-[#1D4ED8] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            {isOutOfStock ? "نفذ المخزون" : "إضافة للسلة"}
          </button>
        )}
      </div>
    </GlassCard>
  );
}
