"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/shared/api/client";

export interface ProductImage {
  id: number;
  path: string;
  thumb_path: string | null;
  variant_id: number | null;
  sort_order: number;
}

export interface Variant {
  id: number;
  sku: string;
  price_cash: number;
  price_installment: number;
  compare_price: number | null;
  cost_price: number | null;
  stock_quantity: number;
  attributes: Record<string, string>;
  is_default: boolean;
  discount_pct: number | null;
}

export interface ProductCard {
  id: number;
  public_id: string;
  sku: string;
  name: string;
  name_ar: string;
  category_id: number | null;
  base_price: number;
  stock_quantity: number;
  is_active: boolean;
  status: string;
  brand: string | null;
  tags: string | null;
  variant_count: number;
  primary_image: ProductImage | null;
  price_cash: number;
  price_installment: number;
  compare_price: number | null;
  discount_pct: number | null;
}

export interface ProductDetail extends ProductCard {
  description: string | null;
  variants: Variant[];
  images: ProductImage[];
  category: { id: number; name: string; name_ar: string } | null;
}

export interface ProductCreate {
  sku: string;
  name: string;
  name_ar?: string | null;
  category_id?: number | null;
  base_price?: number | null;
  stock_quantity?: number;
  description?: string | null;
  brand?: string | null;
  tags?: string | null;
  status?: "draft" | "active";
  variants?: VariantIn[] | null;
}

export interface ProductUpdate {
  name?: string | null;
  name_ar?: string | null;
  category_id?: number | null;
  base_price?: number | null;
  stock_quantity?: number | null;
  description?: string | null;
  brand?: string | null;
  tags?: string | null;
  status?: string | null;
  is_active?: boolean | null;
}

export interface VariantIn {
  sku?: string | null;
  price_cash: number;
  price_installment?: number | null;
  compare_price?: number | null;
  cost_price?: number | null;
  stock_quantity?: number;
  attributes?: Record<string, string> | null;
  is_default?: boolean;
}

export interface VariantUpdate {
  sku?: string | null;
  price_cash?: number | null;
  price_installment?: number | null;
  compare_price?: number | null;
  cost_price?: number | null;
  stock_quantity?: number | null;
  attributes?: Record<string, string> | null;
}

export interface Paginated<T> {
  data: T[];
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export function useProducts(params: { page?: number; page_size?: number; category_id?: number; q?: string; status?: string }) {
  return useQuery<Paginated<ProductCard>>({
    queryKey: ["products", "list", params],
    queryFn: () => api.get("/products", params),
    staleTime: 5 * 60 * 1000,
  });
}

export function useProductDetail(id: number) {
  return useQuery<ProductDetail>({
    queryKey: ["products", "detail", id],
    queryFn: () => api.get(`/products/${id}`),
    enabled: !!id,
  });
}

export function useCreateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: ProductCreate) => api.post("/products", data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["products"] }),
  });
}

export function useUpdateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: ProductUpdate }) => api.patch(`/products/${id}`, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["products", "detail", variables.id] });
    },
  });
}

export function useCreateVariant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, data }: { productId: number; data: VariantIn }) => api.post(`/products/${productId}/variants`, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["products", "detail", variables.productId] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });
}

export function useUpdateVariant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, variantId, data }: { productId: number; variantId: number; data: VariantUpdate }) =>
      api.patch(`/products/${productId}/variants/${variantId}`, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["products", "detail", variables.productId] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });
}

export function useDeleteProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.delete(`/products/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["products"] }),
  });
}

export function useUploadProductImages() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, files }: { productId: number; files: File[] }) => {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f));
      return api.post<ProductImage[]>(`/products/${productId}/images`, formData);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["products", "detail", variables.productId] });
      queryClient.invalidateQueries({ queryKey: ["products", "list"] });
    },
  });
}

export function useDeleteProductImage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, imageId }: { productId: number; imageId: number }) =>
      api.delete(`/products/${productId}/images/${imageId}`),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["products", "detail", variables.productId] });
      queryClient.invalidateQueries({ queryKey: ["products", "list"] });
    },
  });
}
