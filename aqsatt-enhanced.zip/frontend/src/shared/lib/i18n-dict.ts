/**
 * Plain dictionary-based string lookup — deliberately not an i18n library.
 * Covers the sidebar, the dashboard topbar, and the login page only (the
 * scope this was requested for). Add new keys here as needed; everything
 * else in the app stays Arabic-only for now.
 */
import { useLanguageStore } from "@/store/use-language-store";

export const dict = {
  ar: {
    "sidebar.dashboard": "لوحة التحكم",
    "sidebar.customers": "العملاء",
    "sidebar.products": "المنتجات",
    "sidebar.pos": "نقطة البيع",
    "sidebar.sales": "المبيعات",
    "sidebar.payments": "المدفوعات",
    "sidebar.ledger": "دفتر الأستاذ",
    "sidebar.settings": "الإعدادات",
    "sidebar.member": "عضو",
    "sidebar.logout": "تسجيل خروج",
    "topbar.greeting": "مرحباً، {name}",
    "topbar.defaultUser": "مستخدم",
    "topbar.subtitle": "نظرة عامة على أداء النظام",
    "topbar.searchPlaceholder": "بحث سريع...",
    "topbar.quickAdd": "إضافة سريعة",
    "topbar.notifications": "{count} إشعار",
    "login.appName": "أقساط",
    "login.tagline": "نظام إدارة التقسيط والائتمان",
    "login.username": "اسم المستخدم",
    "login.password": "كلمة المرور",
    "login.submit": "تسجيل الدخول",
    "login.failed": "فشل تسجيل الدخول — تحقق من اسم المستخدم وكلمة المرور.",
  },
  en: {
    "sidebar.dashboard": "Dashboard",
    "sidebar.customers": "Customers",
    "sidebar.products": "Products",
    "sidebar.pos": "Point of Sale",
    "sidebar.sales": "Sales",
    "sidebar.payments": "Payments",
    "sidebar.ledger": "Ledger",
    "sidebar.settings": "Settings",
    "sidebar.member": "Member",
    "sidebar.logout": "Log out",
    "topbar.greeting": "Welcome, {name}",
    "topbar.defaultUser": "User",
    "topbar.subtitle": "An overview of your system's performance",
    "topbar.searchPlaceholder": "Quick search...",
    "topbar.quickAdd": "Quick add",
    "topbar.notifications": "{count} notifications",
    "login.appName": "Aqsatt",
    "login.tagline": "Installment & Credit Management System",
    "login.username": "Username",
    "login.password": "Password",
    "login.submit": "Sign In",
    "login.failed": "Login failed — check your username and password.",
  },
} as const;

export type DictKey = keyof typeof dict.ar;

function format(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return Object.entries(vars).reduce(
    (acc, [k, v]) => acc.replace(`{${k}}`, String(v)),
    template
  );
}

/** `const { t } = useT(); t("sidebar.dashboard")` — re-renders on language change. */
export function useT() {
  const lang = useLanguageStore((s) => s.lang);
  const t = (key: DictKey, vars?: Record<string, string | number>) =>
    format(dict[lang][key] ?? dict.ar[key], vars);
  return { t, lang };
}
