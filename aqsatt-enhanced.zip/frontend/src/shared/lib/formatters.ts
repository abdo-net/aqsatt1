/**
 * ALL monetary values are integers (whole IQD)
 * Backend sends whole dinars, not fils
 * No floating point arithmetic anywhere
 */
export const formatCurrency = (value: number): string => {
  if (value === null || value === undefined) return "0 IQD";
  return `${value.toLocaleString("en-US")} IQD`;
};
export const formatCurrencyShort = (value: number): string => {
  if (value === null || value === undefined) return "0";
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M IQD`;
  if (value >= 1000) return `${(value / 1000).toFixed(0)}K IQD`;
  return `${value} IQD`;
};
export const formatDate = (date: string | Date): string => {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" });
};
export const formatDateTime = (date: string | Date): string => {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
};
export const formatPhone = (phone: string): string => {
  if (!phone) return "—";
  return phone;
};
export const calculateDueDate = (
  startDate: Date,
  index: number,
  frequency: "weekly" | "monthly"
): Date => {
  if (frequency === "weekly") {
    return new Date(startDate.getTime() + index * 7 * 24 * 60 * 60 * 1000);
  }
  const d = new Date(startDate);
  const totalMonths = d.getMonth() + index;
  const year = d.getFullYear() + Math.floor(totalMonths / 12);
  const month = totalMonths % 12;
  const day = Math.min(d.getDate(), new Date(year, month + 1, 0).getDate());
  return new Date(year, month, day);
};
export interface InstallmentScheduleItem {
  installmentNumber: number;
  dueDate: Date;
  amount: number;
}
export const calculateInstallments = (
  totalPrice: number,
  downPayment: number,
  months: number,
  frequency: "weekly" | "monthly",
  startDate: Date
): InstallmentScheduleItem[] => {
  const principal = totalPrice - downPayment;
  const base = Math.floor(principal / months);
  const remainder = principal - base * months;
  if (base <= 0) throw new Error("Installment rounds to zero");
  const installments = [];
  for (let k = 0; k < months; k++) {
    installments.push({
      installmentNumber: k + 1,
      dueDate: calculateDueDate(startDate, k, frequency),
      amount: base + (k === months - 1 ? remainder : 0),
    });
  }
  return installments;
};
export const computeFifoAllocation = (
  installments: Array<{
    installment_number: number;
    amount: number;
    paid: number;
    remaining: number;
    status: string;
  }>,
  inputAmount: number
): Array<{
  installment_number: number;
  amount: number;
  paid: number;
  remaining: number;
  visualAllocation: number;
  visualStatus: "UNTOUCHED" | "PARTIALLY_PAID" | "FULLY_PAID";
}> => {
  let remainder = inputAmount;
  return installments.map((inst) => {
    const remainingToPay = inst.remaining;
    if (remainder <= 0)
      return { ...inst, visualAllocation: 0, visualStatus: "UNTOUCHED" as const };
    if (remainder >= remainingToPay) {
      remainder -= remainingToPay;
      return { ...inst, visualAllocation: remainingToPay, visualStatus: "FULLY_PAID" as const };
    } else {
      const partial = remainder;
      remainder = 0;
      return { ...inst, visualAllocation: partial, visualStatus: "PARTIALLY_PAID" as const };
    }
  });
};
export const generateIdempotencyKey = (): string => {
  return `front-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
};
