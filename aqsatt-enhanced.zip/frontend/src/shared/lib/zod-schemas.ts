import { z } from "zod";
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});
export type LoginInput = z.infer<typeof loginSchema>;
export const customerCreateSchema = z.object({
  full_name: z.string().min(2, "Name must be at least 2 characters").max(150),
  phone: z.string().min(5, "Phone is required").max(20),
  alt_phone: z.string().max(20).nullable().optional(),
  national_id: z.string().max(30).nullable().optional(),
  address: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  customer_type: z.enum(["guarantor", "non_guarantor"]).default("non_guarantor"),
  birth_date: z.string().nullable().optional(),
  nearest_landmark: z.string().nullable().optional(),
});
export type CustomerCreateInput = z.infer<typeof customerCreateSchema>;
export const customerUpdateSchema = customerCreateSchema.partial();
export type CustomerUpdateInput = z.infer<typeof customerUpdateSchema>;
export const variantCreateSchema = z.object({
  sku: z.string().max(60).nullable().optional(),
  price_cash: z.number().positive("Price must be greater than 0"),
  price_installment: z.number().positive().nullable().optional(),
  compare_price: z.number().positive().nullable().optional(),
  cost_price: z.number().min(0).nullable().optional(),
  stock_quantity: z.number().min(0).default(0),
  attributes: z.record(z.string()).nullable().optional(),
  is_default: z.boolean().default(false),
});
export type VariantCreateInput = z.infer<typeof variantCreateSchema>;
export const productCreateSchema = z.object({
  sku: z.string().min(1, "SKU is required").max(50),
  name: z.string().min(1, "Name is required").max(150),
  name_ar: z.string().max(150).nullable().optional(),
  category_id: z.number().nullable().optional(),
  base_price: z.number().positive().nullable().optional(),
  stock_quantity: z.number().min(0).default(0),
  description: z.string().nullable().optional(),
  brand: z.string().max(100).nullable().optional(),
  tags: z.string().max(300).nullable().optional(),
  status: z.enum(["active", "draft"]).default("active"),
  variants: z.array(variantCreateSchema).optional(),
});
export type ProductCreateInput = z.infer<typeof productCreateSchema>;
export const saleCreateSchema = z.object({
  idempotency_key: z.string().min(8).max(80),
  customer_id: z.number().positive(),
  sale_type: z.enum(["cash", "installment"]),
  items: z.array(
    z.object({
      product_id: z.number().positive(),
      variant_id: z.number().nullable().optional(),
      quantity: z.number().positive(),
      item_discount: z.number().min(0).default(0),
    })
  ).min(1, "At least one item is required"),
  discount_amount: z.number().min(0).default(0),
  down_payment: z.number().min(0).default(0),
  months: z.number().positive().nullable().optional(),
  frequency: z.enum(["weekly", "monthly"]).default("monthly"),
  start_date: z.string().nullable().optional(),
  sale_channel: z.enum(["store", "online", "agent"]).default("store"),
  salesperson_id: z.number().nullable().optional(),
  notes: z.string().nullable().optional(),
});
export type SaleCreateInput = z.infer<typeof saleCreateSchema>;
export const paymentCreateSchema = z.object({
  idempotency_key: z.string().min(8).max(80),
  sale_id: z.number().positive(),
  amount: z.number().positive("Amount must be greater than 0"),
  payment_method: z.enum(["cash", "qi", "transfer", "zaincash", "visa"]),
  reference_number: z.string().max(100).nullable().optional(),
  source: z.enum(["manual", "api", "external"]).default("manual"),
});
export type PaymentCreateInput = z.infer<typeof paymentCreateSchema>;
export const categoryCreateSchema = z.object({
  name: z.string().min(1).max(100),
  name_ar: z.string().max(100).nullable().optional(),
});
export type CategoryCreateInput = z.infer<typeof categoryCreateSchema>;
export const userCreateSchema = z.object({
  name: z.string().min(2).max(100),
  username: z.string().min(3).max(50),
  password: z.string().min(6).max(128),
  role_id: z.number().positive(),
});
export type UserCreateInput = z.infer<typeof userCreateSchema>;
export const profileUpdateSchema = z.object({
  name: z.string().min(2).max(100),
});
export type ProfileUpdateInput = z.infer<typeof profileUpdateSchema>;
export const passwordChangeSchema = z.object({
  old_password: z.string().min(1),
  new_password: z.string().min(6).max(128),
  confirm_password: z.string().min(6).max(128),
}).refine((data) => data.new_password === data.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"],
});
export type PasswordChangeInput = z.infer<typeof passwordChangeSchema>;
