import axios from "axios";
import { toast } from "react-hot-toast";

export const apiClient = axios.create({
  baseURL: "/api/v1",
  headers: { "Content-Type": "application/json" },
  withCredentials: true,
  timeout: 30000,
});

apiClient.interceptors.request.use((config) => {
  if (["POST", "PUT", "PATCH"].includes(config.method?.toUpperCase() || "")) {
    if (
      !config.headers["Idempotency-Key"] &&
      config.data &&
      typeof config.data === "object" &&
      !config.data.idempotency_key
    ) {
      const key = `front-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
      config.data.idempotency_key = key;
    }
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        await axios.post("/api/auth/refresh", {}, { withCredentials: true });
        return apiClient(originalRequest);
      } catch {
        window.location.href = "/login";
        return Promise.reject(error);
      }
    }
    if (!error.response && !originalRequest._retry) {
      originalRequest._retry = true;
      await new Promise((r) => setTimeout(r, 1000));
      return apiClient(originalRequest);
    }
    const status = error.response?.status;
    const body = error.response?.data || { detail: "Network Error" };
    // FastAPI's 422 detail is an array of pydantic error objects, not a string —
    // collapse it to one readable line instead of handing the array to toast().
    // body.message covers the Next.js proxy's own {error_code, message} shape
    // (returned when it can't reach the backend at all — see api/v1/[[...path]]).
    const detail = Array.isArray(body.detail)
      ? body.detail.map((d: { msg?: string }) => d.msg).filter(Boolean).join("; ") || "Validation failed"
      : body.detail || body.message;
    if (status >= 500) {
      toast.error(`${detail || "System failure"} (HTTP ${status}, ${error.config?.url})`);
    } else if (status === 409) {
      toast.error(detail || "Conflict: Record may already exist");
    } else if (status === 422) {
      toast.error(detail || "Validation failed");
    } else if (!error.response) {
      toast.error(`Network error reaching ${error.config?.url} — server unreachable`);
    } else {
      toast.error(`${detail || "Request failed"} (HTTP ${status})`);
    }
    // Preserve the HTTP status on the rejected value — callers (e.g. React Query's
    // global retry()) need error.status, not just the backend's response body.
    return Promise.reject({ ...body, detail, status });
  }
);

export const api = {
  get: <T>(url: string, params?: Record<string, unknown>) =>
    apiClient.get<T, T>(url, { params }),
  post: <T>(url: string, data?: unknown) => apiClient.post<T, T>(url, data),
  put: <T>(url: string, data?: unknown) => apiClient.put<T, T>(url, data),
  patch: <T>(url: string, data?: unknown) => apiClient.patch<T, T>(url, data),
  delete: <T>(url: string) => apiClient.delete<T, T>(url),
};
