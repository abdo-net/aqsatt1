'use client';

import * as React from 'react';
import { ArrowDown, ArrowUp, type LucideIcon } from 'lucide-react';
import { cn } from '@/shared/lib/utils';

type Accent = 'cyan' | 'pink' | 'purple' | 'green' | 'amber' | 'red';

const accentColor: Record<Accent, string> = {
  cyan: '#2563EB',
  pink: '#EC4899',
  purple: '#8B5CF6',
  green: '#22C55E',
  amber: '#F59E0B',
  red: '#EF4444',
};

const accentBar: Record<Accent, string> = {
  cyan: 'from-[#2563EB] to-[#3B82F6]',
  pink: 'from-[#EC4899] to-[#F472B6]',
  purple: 'from-[#8B5CF6] to-[#A78BFA]',
  green: 'from-[#22C55E] to-[#4ADE80]',
  amber: 'from-[#F59E0B] to-[#FBBF24]',
  red: 'from-[#EF4444] to-[#F87171]',
};

export type KpiCardProps = {
  label: string;
  value: number | string;
  unit?: string;
  /** Trend: positive number = up (green), negative = down (red). Decorative only — not bound to any endpoint. */
  trend?: number;
  /** Optional progress percentage 0-100. Decorative only — not bound to any endpoint. */
  progress?: number;
  icon: LucideIcon;
  accent?: Accent;
  loading?: boolean;
  onClick?: () => void;
};

export function KpiCard({
  label,
  value,
  unit,
  trend,
  progress,
  icon: Icon,
  accent = 'cyan',
  loading = false,
  onClick,
}: KpiCardProps) {
  const trendUp = (trend ?? 0) >= 0;

  if (loading) {
    return (
      <div className="glass-cyber rounded-xl p-4 animate-shimmer h-[110px]">
        <div className="h-full w-full" />
      </div>
    );
  }

  return (
    <div
      onClick={onClick}
      className={cn('glass-cyber rounded-xl p-4', onClick && 'cursor-pointer')}
      style={{ borderInlineStartWidth: 3, borderInlineStartColor: accentColor[accent] }}
    >
      <div className="flex items-start justify-between">
        <span className="text-[13px] text-fg-muted">{label}</span>
        <Icon className="w-5 h-5 text-fg-faint" />
      </div>

      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-[28px] font-bold text-fg-primary tracking-tight num-ltr">{value}</span>
        {unit && <span className="text-sm text-fg-muted">{unit}</span>}
      </div>

      {typeof trend === 'number' && (
        <div
          className={cn(
            'mt-1 inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium',
            trendUp ? 'bg-[rgba(34,197,94,0.1)] text-[#22C55E]' : 'bg-[rgba(239,68,68,0.1)] text-[#EF4444]',
          )}
        >
          {trendUp ? <ArrowUp className="w-3.5 h-3.5" /> : <ArrowDown className="w-3.5 h-3.5" />}
          <span className="num-ltr">{Math.abs(trend)}%</span>
        </div>
      )}

      {typeof progress === 'number' && (
        <div className="mt-3 h-1.5 bg-overlay-subtle rounded-full overflow-hidden">
          <div
            className={cn('h-full rounded-full progress-shine bg-gradient-to-r', accentBar[accent])}
            style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
          />
        </div>
      )}
    </div>
  );
}
