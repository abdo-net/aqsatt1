'use client';

import * as React from 'react';
import { cn } from '@/shared/lib/utils';

type Variant = 'cyan' | 'pink' | 'purple' | 'green' | 'amber' | 'red' | 'outline' | 'ghost';
type Size = 'sm' | 'md' | 'lg' | 'icon';

const variantClasses: Record<Variant, string> = {
  cyan: 'bg-[#2563EB] text-white hover:bg-[#1D4ED8]',
  pink: 'bg-[#EC4899] text-white hover:bg-[#DB2777]',
  purple: 'bg-[#8B5CF6] text-white hover:bg-[#7C3AED]',
  green: 'bg-[#22C55E] text-white hover:bg-[#16A34A]',
  amber: 'bg-[#F59E0B] text-white hover:bg-[#D97706]',
  red: 'bg-[#EF4444] text-white hover:bg-[#DC2626]',
  outline: 'border border-[var(--border-subtle)] text-fg-primary hover:bg-overlay-subtle',
  ghost: 'text-fg-secondary hover:bg-overlay-subtle hover:text-fg-primary',
};

const sizeClasses: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-sm rounded-lg min-h-[36px]',
  md: 'px-4 py-2.5 text-sm rounded-lg min-h-[40px] sm:min-h-[36px]',
  lg: 'px-6 py-3 text-base rounded-lg min-h-[44px]',
  icon: 'p-2.5 rounded-lg min-h-[40px] min-w-[40px] sm:min-h-[36px] sm:min-w-[36px]',
};

type NeonButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
};

export const NeonButton = React.forwardRef<HTMLButtonElement, NeonButtonProps>(
  (
    {
      className,
      variant = 'cyan',
      size = 'md',
      loading = false,
      leftIcon,
      rightIcon,
      children,
      disabled,
      ...props
    },
    ref,
  ) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          'btn-cyber relative inline-flex items-center justify-center gap-2 font-medium transition-colors select-none',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--ring-offset-base)]',
          'disabled:opacity-50 disabled:pointer-events-none',
          variantClasses[variant],
          sizeClasses[size],
          className,
        )}
        {...props}
      >
        {loading ? (
          <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        ) : (
          leftIcon
        )}
        {children}
        {!loading && rightIcon}
      </button>
    );
  },
);
NeonButton.displayName = 'NeonButton';
