import { formatCurrency } from "@/shared/lib/formatters";

interface NumProps {
  children: React.ReactNode;
  className?: string;
  currency?: boolean;
}

export const Num = ({ children, className = "", currency = false }: NumProps) => {
  const formatted = currency && typeof children === "number" ? formatCurrency(children) : children;
  return (
    <span className={`font-mono tracking-tight num-ltr ${className}`} dir="ltr">
      {formatted}
    </span>
  );
};
