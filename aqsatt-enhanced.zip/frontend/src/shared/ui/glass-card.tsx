'use client';

import * as React from 'react';
import { cn } from '@/shared/lib/utils';

type GlassCardProps = React.HTMLAttributes<HTMLDivElement> & {
  /** Lifts the card on hover (-translate-y-1) */
  lift?: boolean;
  /** Padding scale */
  padding?: 'none' | 'sm' | 'md' | 'lg';
};

const paddingMap = {
  none: '',
  sm: 'p-4',
  md: 'p-5 sm:p-6',
  lg: 'p-6 sm:p-8',
};

export const GlassCard = React.forwardRef<HTMLDivElement, GlassCardProps>(
  (
    {
      className,
      lift = false,
      padding = 'md',
      children,
      ...props
    },
    ref,
  ) => {
    return (
      <div
        ref={ref}
        className={cn(
          'glass-cyber rounded-2xl',
          paddingMap[padding],
          lift && 'card-lift',
          className,
        )}
        {...props}
      >
        {children}
      </div>
    );
  },
);
GlassCard.displayName = 'GlassCard';
