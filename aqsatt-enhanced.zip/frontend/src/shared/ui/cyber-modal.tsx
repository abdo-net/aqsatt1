'use client';

/**
 * CyberModal — Centered modal with backdrop blur, scale-in animation,
 * close on X / overlay click / Escape key.
 *
 * Usage:
 *   <CyberModal open={isOpen} onOpenChange={setIsOpen} title="..." accent="cyan">
 *     ...content
 *   </CyberModal>
 */
import * as React from 'react';
import { cn } from '@/shared/lib/utils';
import { X } from 'lucide-react';

type Accent = 'cyan' | 'pink' | 'purple' | 'green' | 'amber' | 'red';

const accentBorder: Record<Accent, string> = {
  cyan: 'border-[var(--border-subtle)]',
  pink: 'border-[var(--border-subtle)]',
  purple: 'border-[var(--border-subtle)]',
  green: 'border-[var(--border-subtle)]',
  amber: 'border-[var(--border-subtle)]',
  red: 'border-[var(--border-subtle)]',
};

const accentClose: Record<Accent, string> = {
  cyan: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
  pink: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
  purple: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
  green: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
  amber: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
  red: 'hover:bg-overlay-subtle border-[var(--border-subtle)] text-fg-secondary',
};

type CyberModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  accent?: Accent;
  className?: string;
};

const sizeMap = {
  sm: 'max-w-md',
  md: 'max-w-lg',
  lg: 'max-w-2xl',
  xl: 'max-w-4xl',
};

export function CyberModal({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer,
  size = 'md',
  accent = 'cyan',
  className,
}: CyberModalProps) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onOpenChange(false);
    };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onOpenChange]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'cyber-modal-title' : undefined}
      className={cn('modal-overlay', open && 'active')}
      onClick={(e) => {
        if (e.target === e.currentTarget) onOpenChange(false);
      }}
    >
      <div
        className={cn(
          'modal-content w-full',
          sizeMap[size],
          'glass-cyber rounded-2xl p-5 sm:p-8 border',
          accentBorder[accent],
          className,
        )}
      >
        {(title || description) && (
          <div className="flex items-start justify-between mb-6">
            <div>
              {title && (
                <h2 id="cyber-modal-title" className="text-xl sm:text-2xl font-bold text-fg-primary">
                  {title}
                </h2>
              )}
              {description && (
                <p className="text-sm text-fg-muted mt-1">{description}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              aria-label="إغلاق"
              className={cn(
                'p-2 rounded-lg transition-colors border',
                accentClose[accent],
              )}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        <div>{children}</div>

        {footer && <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-6 mt-6 border-t border-[var(--border-subtle)]">{footer}</div>}
      </div>
    </div>
  );
}

/**
 * Helper hook to manage a single modal's open state from a page/component.
 *
 * Usage:
 *   const { open, setOpen } = useModal();
 *   <CyberModal open={open} onOpenChange={setOpen}>...</CyberModal>
 */
export function useModal(initial = false) {
  const [open, setOpen] = React.useState(initial);
  return { open, setOpen, openModal: () => setOpen(true), closeModal: () => setOpen(false) };
}
