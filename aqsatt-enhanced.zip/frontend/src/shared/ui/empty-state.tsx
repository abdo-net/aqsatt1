'use client';

import * as React from 'react';
import { type LucideIcon, Package } from 'lucide-react';
import { cn } from '@/shared/lib/utils';
import { NeonButton } from './neon-button';

export type EmptyStateProps = {
  icon?: LucideIcon;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  accent?: 'cyan' | 'pink' | 'purple' | 'green' | 'amber' | 'red';
  className?: string;
};

const accentBg: Record<NonNullable<EmptyStateProps['accent']>, string> = {
  cyan: 'bg-[rgba(37,99,235,0.1)] text-[#2563EB] border-[rgba(37,99,235,0.2)]',
  pink: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
  purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  green: 'bg-green-500/10 text-green-400 border-green-500/20',
  amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  red: 'bg-red-500/10 text-red-400 border-red-500/20',
};

export function EmptyState({
  icon: Icon = Package,
  title,
  description,
  actionLabel,
  onAction,
  accent = 'cyan',
  className,
}: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center py-16 text-center', className)}>
      <div
        className={cn(
          'w-20 h-20 rounded-2xl border-2 flex items-center justify-center mb-4',
          accentBg[accent],
        )}
      >
        <Icon className="w-10 h-10" />
      </div>
      <h3 className="font-semibold text-lg text-fg-primary mb-1">{title}</h3>
      {description && <p className="text-sm text-fg-muted max-w-sm">{description}</p>}
      {actionLabel && onAction && (
        <NeonButton variant={accent} className="mt-6" onClick={onAction}>
          {actionLabel}
        </NeonButton>
      )}
    </div>
  );
}

/** Loading skeleton for tables */
export function TableSkeleton({ rows = 5, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="space-y-3 p-6">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4">
          {Array.from({ length: cols }).map((__, j) => (
            <div
              key={j}
              className="h-10 flex-1 rounded-lg animate-shimmer bg-overlay-subtle"
            />
          ))}
        </div>
      ))}
    </div>
  );
}
