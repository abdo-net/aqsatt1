# SYSTEM_UI_SPEC.md

> **Source of truth:** extracted line-by-line from the AQSATT backend
> (`backend/app/**`) and compared against the existing frontend
> (`frontend/src/**`). Nothing here is invented. Anything not derivable from
> code is marked **UNKNOWN**. Endpoints that do **not** exist are marked
> **NO ENDPOINT**.
>
> Conventions used below:
> - `T` = tenant-scoped (Row-Level-Security via `app.tenant_id` GUC).
> - `A` = app-scoped (filtered explicitly by `tenant_id` in code, no RLS).
> - All money fields are **integers** (whole IQD, `BigInteger`). No floats anywhere.

---

## 0. SYSTEM TOPOLOGY (verified)

```
Browser
  └─ Next.js (frontend)
       ├─ /api/auth/login   (route.ts)  → sets httpOnly cookies aqsatt_access / aqsatt_refresh
       ├─ /api/auth/refresh (route.ts)  → rotates refresh token
       ├─ /api/auth/logout  (route.ts)
       └─ /api/v1/[[...path]] (route.ts) → BFF catch-all proxy
              · reads aqsatt_access cookie
              · injects  Authorization: Bearer <access>
              · forwards verbatim to FastAPI  http://127.0.0.1:8000/api/v1/<path>
  FastAPI (backend, prefix /api/v1)
       └─ PostgreSQL  (RLS per tenant; auth tables app-scoped)
  Background (systemd timers, NOT HTTP):
       · jobs/overdue_job.py        → late_days, collection_logs, notifications, overdue events
       · app/events/dispatcher.py   → webhook delivery from domain_events outbox
```

**Auth model (verified `core/security.py`, `routers/auth.py`, BFF routes):**
- Access JWT: `{sub, tid, perms[], typ:"access", exp}` — TTL 120 min. **Permissions are embedded in the token.**
- Refresh JWT: `{sub, tid, jti, typ:"refresh", exp}` — TTL 30 days, registered server-side in `refresh_tokens`, rotated on every `/refresh` (old `jti` revoked).
- Tenant is resolved **at login** from `tenant_memberships` (first active membership). **The client never sends `tenant_id`** — it rides inside the JWT. No tenant header exists anywhere.
- The same `JWT_SECRET` is shared between backend and Next.js middleware.

---

## 1. CAPABILITY MAP (100% coverage)

### 1.1 Entities (models/__init__.py) and relationships

| Entity | Scope | Key relationships / notes |
|---|---|---|
| `Tenant` | platform | self-FK `parent_tenant_id`; type store\|reseller; status active\|suspended |
| `User` | A | `home_tenant_id`→Tenant; `username` globally unique; `password_hash` bcrypt |
| `Permission` | A | global codes (17 seeded) |
| `Role` | A | per-tenant; unique(tenant,name); `is_system` |
| `RolePermission` | A | role↔permission |
| `UserRole` | A | (user,tenant,role) composite PK |
| `TenantMembership` | A | (user,tenant) unique; `is_active` gates login |
| `TenantSetting` | T | (tenant,key) unique; JSONB value |
| `TenantSequence` | T | (tenant,sequence_name) PK; atomic counter |
| `RequestIdempotency` | T | (tenant,key,endpoint) unique; stores response_code+body |
| `Customer` | T | phone unique per tenant (partial idx); risk_class trusted\|qi\|mixed; status active\|blocked |
| `Category` | T | name + name_ar |
| `Product` | T | sku unique per tenant; `base_price`>0; `stock_quantity`≥0; status draft\|active; `is_active` |
| `ProductVariant` | T | →Product; `price_cash`>0; `is_default`; sku unique per tenant; attributes JSONB |
| `ProductImage` | T | →Product (+optional Variant); path/thumb_path; sort_order; max 8/product |
| `Sale` | T | →Customer; sale_type cash\|installment; channel store\|online\|agent; status active\|completed\|cancelled; CK `total_price = subtotal - discount_amount`, `down_payment < total_price` |
| `SaleItem` | T | →Sale,Product,Variant; **name snapshots**; CK `line_total = unit_price*qty - item_discount` |
| `InstallmentPlan` | T | →Sale; `revision`; `supersedes_plan_id`; status active\|completed\|defaulted\|cancelled\|superseded; unique(sale,revision) |
| `Installment` | T | →Plan; **stored status only scheduled\|cancelled**; `late_days`; `last_payment_at`; unique(plan,number) |
| `PlanRevision` | T | reschedule audit (old/new months, reason) — **written by NO endpoint** |
| `Payment` | T | →Sale,Customer; method cash\|qi\|transfer\|zaincash\|visa; status pending\|confirmed\|failed\|reversed; `idempotency_key` unique per tenant; `receipt_number` unique per tenant; `transaction_group_id`; `reversed_payment_id` |
| `PaymentAllocation` | T | →Payment,Installment; FIFO allocation rows |
| `Account` | T | code/name/name_ar; type asset\|liability\|equity\|revenue\|expense; normal_balance debit\|credit |
| `LedgerEntry` | T | append-only double-entry; `transaction_group_id`; one side only (CK); reference_type sale\|payment\|reversal\|reschedule |
| `DomainEvent` | T | transactional outbox; status pending\|processed\|failed |
| `AuditLog` | T | action create\|update\|delete\|reschedule; old/new JSONB |
| `Attachment` | T | polymorphic (entity_type,entity_id) — **no management endpoint** |
| `WebhookEndpoint` | T | url/secret/event_types[] — **no management endpoint** |
| `WebhookDelivery` | T | delivery log (dispatcher) |
| `NotificationTemplate` | T | (tenant,key,channel) unique; body_ar; channel sms\|whatsapp |
| `Notification` | T | →Customer; channel sms\|whatsapp; status pending\|sent\|failed |
| `CollectionLog` | T | →Installment; action marked_late\|notification_sent\|manual_note |
| `RefreshToken` | A | jti registry; revoked_at; rotation |

### 1.2 Chart of accounts (seed.py — fixed, 4 accounts)

| Code | Name | Type | Normal |
|---|---|---|---|
| `1000` | Cash / النقد | asset | debit |
| `1100` | Accounts Receivable / الذمم المدينة | asset | debit |
| `4000` | Sales Revenue / إيرادات المبيعات | revenue | credit |
| `5000` | Provider Fees Expense / رسوم المزوّد | expense | debit |

### 1.3 Permissions (seed.py — 17) and role bundles

`customers.read/write · products.read/write · sales.read/create/cancel · plans.read/reschedule · payments.read/create/reverse · ledger.read · reports.read · users.manage · roles.manage · settings.manage`

- **admin**: all 17
- **staff**: customers.read/write, products.read, sales.read/create, plans.read, payments.read/create, reports.read
- **accountant**: sales.read, plans.read, payments.read/reverse, ledger.read, reports.read

> **Capability declared but UNROUTED** (permission exists, no endpoint enforces/uses it):
> `sales.cancel`, `plans.reschedule`, `payments.reverse`, `roles.manage` (only list). See §3.

### 1.4 Complete endpoint inventory (38 routes — every `@router` verified)

**AUTH** (`/api/v1/auth`)
| M | Path | Perm | Req → Resp |
|---|---|---|---|
| POST | `/auth/login` | public | `{username,password}` → `LoginResponse{access_token,refresh_token,access_expires_in,refresh_expires_in,tenant_id,user_id,permissions[]}` |
| POST | `/auth/refresh` | public (valid refresh) | `{refresh_token}` → `RefreshResponse{…}` (rotates) |
| POST | `/auth/logout` | public | `{refresh_token}` → `{status:"logged_out"}` (idempotent) |

**ACCOUNT / SELF** (`/api/v1`)
| M | Path | Perm | Notes |
|---|---|---|---|
| GET | `/me` | auth | `{id,name,username,tenant_id,permissions[]}` |
| PATCH | `/me` | auth | `{name}` → updated profile |
| POST | `/me/password` | auth | `{old_password,new_password}` (verifies old; must differ) |
| GET | `/tenant` | auth | `{id,name,slug,type,currency_code,timezone,status}` |
| GET | `/settings` | settings.manage | `{key: value(JSONB), …}` |
| PUT | `/settings/{key}` | settings.manage | `{value:{}}` upsert |

**ADMIN / RBAC** (`/api/v1`)
| M | Path | Perm | Notes |
|---|---|---|---|
| GET | `/users` | users.manage | members of caller tenant |
| POST | `/users` | users.manage | `{name,username,password,role_id}`; creates user+membership+user_role |
| PATCH | `/users/{id}` | users.manage | `{name?,is_active?,role_id?}`; cannot self-deactivate; role swap UPDATES mapping |
| POST | `/users/{id}/password` | users.manage | `{new_password}` |
| GET | `/roles` | users.manage | roles + permission codes |
| GET | `/permissions` | users.manage | all permission codes |

**CUSTOMERS** (`/api/v1/customers`) — T
| M | Path | Perm | Notes |
|---|---|---|---|
| POST | `` | customers.write | `CustomerCreate`; phone dup → 409 |
| GET | `` | customers.read | paginated; filter phone\|name; **enriched** `receivable_balance,next_due,is_overdue` |
| GET | `/{id}` | customers.read | profile + `receivable_balance` + `sales[]` each with active-plan `schedule[]` |
| PATCH | `/{id}` | customers.write | `CustomerUpdate` (+status active\|blocked) |

**CATEGORIES** (`/api/v1/categories`) — T
| M | Path | Perm |
|---|---|---|
| GET | `` | products.read (returns `product_count`) |
| POST | `` | products.write |
| DELETE | `/{id}` | products.write (soft) |

**PRODUCTS / VARIANTS / IMAGES** (`/api/v1/products`) — T
| M | Path | Perm | Notes |
|---|---|---|---|
| POST | `` | products.write | `ProductCreate` (+ optional `variants[]`); auto default variant if none |
| GET | `` | products.read | paginated; filter category_id\|q\|status; card shape (default-variant pricing) |
| GET | `/{id}` | products.read | detail: `variants[]`, `images[]`, `category` |
| PATCH | `/{id}` | products.write | `ProductUpdate` (**no `variants`** — by design) |
| DELETE | `/{id}` | products.write | soft delete |
| POST | `/{id}/variants` | products.write | `VariantIn`; re-syncs aggregate stock/base_price |
| PATCH | `/{id}/variants/{vid}` | products.write | `VariantUpdate`; re-syncs aggregate |
| GET | `/{id}/images` | products.read | |
| POST | `/{id}/images` | products.write | multipart `files[]`; max 8; square 800/300 |
| DELETE | `/{id}/images/{iid}` | products.write | soft |

**SALES** (`/api/v1/sales`) — T
| M | Path | Perm | Notes |
|---|---|---|---|
| POST | `` | sales.create | `SaleCreate` (idempotent via RequestIdempotency); creates ledger + plan + schedule |
| GET | `` | sales.read | paginated; filter customer_id\|status\|sale_type |
| GET | `/{id}` | sales.read | full sale incl `items[]` + `plan{schedule[]}` |
| GET | `/{id}/schedule` | sales.read | payments-UI shape: `{id,sale_number,customer_name,total_price,down_payment,installments[]}` |

**PLANS** (`/api/v1/plans`) — T
| M | Path | Perm |
|---|---|---|
| GET | `/{plan_id}/schedule` | plans.read |

**PAYMENTS** (`/api/v1/payments`) — T
| M | Path | Perm | Notes |
|---|---|---|---|
| GET | `` | payments.read | filter sale_id\|customer_id; `limit` (not paginated); each w/ `allocations[]` |
| POST | `` | payments.create | `PaymentCreate`; FIFO allocation; idempotent; overpayment → 409 |

**DASHBOARD** (`/api/v1/dashboard`) — T
| M | Path | Perm | Returns |
|---|---|---|---|
| GET | `/summary` | reports.read | `{total_outstanding,total_cash_collected,today_payments,overdue_count,customers_count,active_sales_count}` |

**LEDGER** (`/api/v1/ledger`) — T
| M | Path | Perm | Returns |
|---|---|---|---|
| GET | `` | ledger.read | **bare array** grouped by `transaction_group_id`, each `{transaction_group_id,reference_type,reference_id,created_at,lines[],total}` |
| GET | `/accounts` | ledger.read | per-account balances (trial balance) |
| GET | `/summary` | ledger.read | `{total_debits,total_credits,net_balance,entry_count}` |

**NOTIFICATIONS** (`/api/v1/notifications`) — T
| M | Path | Perm |
|---|---|---|
| GET | `` | reports.read (read-only feed) |

### 1.5 Classification

- **CORE FINANCIAL LOGIC:** sale creation + ledger posting (`sale_service`), payment + FIFO allocation (`payment_service`), double-entry engine + balances (`ledger_service`), installment schedule generation, dashboard/ledger projections.
- **OPERATIONAL FEATURE:** customers, products/variants/images, categories, sales listing, payments listing, notifications feed, POS.
- **ADMIN FEATURE:** users, roles (read), permissions (read), tenant settings, profile/password, tenant info.
- **SYSTEM INFRASTRUCTURE:** auth/JWT/refresh rotation, RLS tenant binding, idempotency (request + payment), sequences, domain-event outbox + webhook dispatcher, overdue job, audit logs.

---

## 2. CRITICAL CONSTRAINTS & HIDDEN LOGIC (must be honored by UI)

1. **Integer money only.** Every amount is whole IQD. UI must never introduce decimals, never do float math on money. Display formatting only.
2. **Double-entry ledger is server-authoritative.** `ledger_service.post` rejects unbalanced/zero/two-sided lines → `LedgerImbalance` → **HTTP 500** (`{"detail":"ledger invariant violated…"}`). UI shows a hard system error; it must never attempt to "fix" balances.
3. **FIFO payment allocation (`payment_service.record_payment`):**
   - Allocates to **scheduled** installments ordered by `installment_number` ascending.
   - Per installment outstanding = `amount − Σ confirmed allocations`.
   - Applies `min(remaining_payment, outstanding)` until payment consumed.
   - **Overpayment (amount > total outstanding) → 409**, payment rejected entirely.
   - On full coverage → plan + sale become `completed`.
4. **Installment status is DERIVED at read time** (`installment_state`), never stored: `cancelled | paid | late | partially_paid | pending`. The DB column only ever holds `scheduled` or `cancelled`. UI must read `status` from the schedule payload, not infer it.
5. **Schedule math (`sale_service`):** `principal = total − down`; `base = principal // months` (floor); `remainder` added to the **last** installment. `base ≤ 0` → 400. Monthly due dates clamp to month length; weekly = +7·n days.
6. **Idempotency:**
   - **POST /sales** — client supplies `idempotency_key` (8–80 chars). Replays return the **stored original response** (status echoes original).
   - **POST /payments** — `idempotency_key` unique per tenant; replay returns the original payment with `"replayed": true`.
   - The axios client auto-injects `idempotency_key` into POST/PUT/PATCH bodies if absent — but **sales & payments require an explicit, stable key** the client controls for true retry-safety.
7. **Stock is server-managed.** Sale decrements variant stock (and rolls product.stock = Σ variants) or product stock for variant-less products, under `FOR UPDATE`. Insufficient → 409. UI must treat displayed stock as advisory and surface 409s.
8. **Customer block:** `status=blocked` → sale creation 409. UI should pre-warn.
9. **Tenant isolation:** never send `tenant_id`; it is in the JWT. Cross-tenant access is impossible by construction (RLS + app filters).
10. **Soft-delete only.** Users, customers, products, variants, images, categories, sales, plans are never hard-deleted; "delete" = flag. UI "delete" actions are deactivations.
11. **Name snapshots:** `SaleItem` stores `name_snapshot/name_ar_snapshot` at sale time — historical sales must display the snapshot, not the live product name.

---

## 3. FRONTEND GAP ANALYSIS (existing UI vs backend)

> Compared `frontend/src/features/**` and `app/(dashboard)/**` against §1.4.

### 3.1 CRITICAL — wrong/contracts that will break or show empty data

| # | Gap | Where | Why it fails | Severity |
|---|---|---|---|---|
| G1 | **Ledger page contract mismatch.** `use-ledger.ts` types `useLedger` as `Paginated<LedgerEntry>` with fields `entry_type, debit, credit, balance_after, customer_name`. Backend `GET /ledger` returns a **bare array grouped by transaction** with `lines[]`, **no pagination envelope, no `balance_after`, no per-row entry, no `customer_name`**. `LedgerEntry.entry_type` enum (`refund/adjustment/write_off`) doesn't exist in backend (only `sale/payment/reversal/reschedule`). | `features/ledger` | Table will render empty/undefined; `data.data` is undefined on an array. | CRITICAL |
| G2 | **Sales list missing fields.** `SaleListItem` expects `customer_name` + `item_count`. Backend `_serialize` returns neither (it returns full `items[]` + `plan`). | `features/sales`, `sales/page.tsx` | Customer column + item count render blank. | CRITICAL |
| G3 | **Payments list contract mismatch.** `Payment` type expects `sale_number, customer_name, created_by(string), reference_number, source, public_id`. Backend `GET /payments` returns `receipt_number, sale_id, customer_id, amount, fee_amount, payment_method, status, paid_at, allocations` — **no names, no public_id, not paginated** (`limit` only). Hook types it `Paginated<Payment>`. | `features/payments` | Columns blank; `data.data` undefined (array, not envelope). | CRITICAL |
| G4 | **Analytics widgets are hardcoded mock data.** `CashflowChart`, `RiskSegmentation`, `OverdueAccounts` render static arrays; zero backend wiring. | `features/analytics/components/*` | Dashboard shows fabricated numbers. | CRITICAL (financial misinformation) |

### 3.2 HIGH — capabilities with NO UI (and some with NO endpoint)

| # | Capability | Endpoint status | UI status | Severity |
|---|---|---|---|---|
| G5 | **Payment reversal** (`payments.reverse`, `reversed_payment_id`, ledger `reversal`) | **NO ENDPOINT** | none | HIGH — backend cannot do it yet; UI must not pretend |
| G6 | **Plan reschedule** (`plans.reschedule`, `PlanRevision`, `supersedes_plan_id`, ledger `reschedule`, audit `reschedule`) | **NO ENDPOINT** | none | HIGH |
| G7 | **Sale cancel** (`sales.cancel`, status `cancelled`) | **NO ENDPOINT** | none | HIGH |
| G8 | **Role/permission management** beyond listing (assign perms, create role) | only `GET /roles`,`GET /permissions` | settings lists only | MEDIUM |
| G9 | **Tenant settings editor** (`GET/PUT /settings/{key}` JSONB) | exists | none | MEDIUM |
| G10 | **Tenant info** (`GET /tenant`) | exists | none | MEDIUM |
| G11 | **Trial balance** (`GET /ledger/accounts`) | exists | not surfaced | MEDIUM |
| G12 | **Plan schedule by plan_id** (`GET /plans/{id}/schedule`) | exists | unused (sales schedule used instead) | LOW |
| G13 | **Notifications feed** (`GET /notifications`) | exists | OverdueAccounts uses mock instead | MEDIUM |
| G14 | **Product images upload/delete UI** | exists | partial/none | MEDIUM |
| G15 | **Webhooks & Attachments** | **NO ENDPOINT** (models+dispatcher only) | none | LOW — backend incomplete |

---

## 4. UI REQUIREMENTS (functional, per capability)

> States required for every data view: **loading / error / empty / success**. Every mutation: **optimistic-or-pending / success toast / typed error toast** (the axios client already maps 409/422/5xx to toasts).

### 4.1 Auth & session
- **Login**: form `{username,password}` → `POST /api/auth/login` (BFF). On 401 show "invalid credentials" (backend message is generic). On success redirect to dashboard.
- **Silent refresh**: handled by axios interceptor (401 → `POST /api/auth/refresh` → retry once → else redirect `/login`). No dedicated UI.
- **Logout**: `POST /api/auth/logout`, clear client state.
- **Permission gating**: read `permissions[]` from `/me`; hide/disable actions the user lacks (mirror §1.3). Server still enforces (403).

### 4.2 Customers
- **List**: `GET /customers` (page,page_size,phone,name). Columns: name, phone, risk_class badge, status badge, `receivable_balance` (currency), `next_due`, `is_overdue` flag. Empty/loading/error states. Pagination via envelope.
- **Create/Edit**: `CustomerCreate/Update`. Edge: phone uniqueness → 409 "phone already exists". Block/unblock via `status`.
- **Profile**: `GET /customers/{id}` → header (receivable_balance) + `sales[]` with per-sale `schedule[]` (installment_state rows). Each installment row shows derived status badge + paid/remaining.

### 4.3 Products / variants / images
- **Catalog**: `GET /products` cards (default-variant pricing: `price_cash, price_installment, compare_price, discount_pct`, `primary_image`, `variant_count`, stock). Filters category/q/status. Pagination.
- **Create**: `ProductCreate` with optional `variants[]` (zod `productCreateSchema` now includes `variants`). If no variant, `base_price` required (else 400).
- **Detail/Edit**: `GET /products/{id}`; product fields via `PATCH /products/{id}` (**never send `variants` here**). Variant edits via `PATCH /products/{id}/variants/{vid}`; add via `POST /products/{id}/variants`.
- **Images**: `POST /products/{id}/images` (multipart, max 8, surfaces 400 on >8 or invalid image), list, soft-delete. Show thumb grid + primary.
- **Categories**: list (with product_count), create, soft-delete.

### 4.4 POS / Sale creation (see flow §5.1)
- Cart builder: pick customer (block check), add items (product+variant+qty+item_discount), order discount, choose cash|installment.
- Installment params: months, frequency (weekly|monthly), start_date. **Client-side preview only** via `calculateInstallments` (must mirror server: floor base, remainder on last). Server is authoritative.
- **Must generate a stable `idempotency_key`** (≥8 chars) and reuse it on retry. On success show sale_number + (for installment) generated schedule. Handle 409 (stock/blocked/overpay) and 400 (rounds-to-zero) explicitly.

### 4.5 Payments (see flow §5.2)
- From a sale: `GET /sales/{id}/schedule` → show installments with paid/remaining/status.
- Record payment: `POST /payments {idempotency_key,sale_id,amount,payment_method,reference_number?,source?}`.
  - **Show FIFO preview** (client `computeFifoAllocation` mirrors server) but treat server `allocations[]` as truth.
  - Reject UI-side amounts ≤ 0; surface server 409 overpayment with the exact outstanding number.
  - On `replayed:true` show "already recorded" (idempotent).
- History: `GET /payments?sale_id|customer_id` with `allocations[]`.

### 4.6 Ledger / accounting (must be rebuilt to match backend — G1)
- **Journal view**: consume the grouped array from `GET /ledger` (`transaction_group_id`, `reference_type`, `lines[]{account_code,account_name(_ar),debit,credit,description,customer_id,sale_id}`, `total`). Render each group as a balanced journal entry (debits left, credits right). **No pagination envelope** — use `limit` + optional `customer_id`.
- **Summary card**: `GET /ledger/summary` → total_debits/credits/net_balance/entry_count.
- **Trial balance**: `GET /ledger/accounts` → per-account balance table (G11).

### 4.7 Dashboard (must replace mock — G4)
- KPIs: `GET /dashboard/summary` (already wired & typed). 
- **Overdue list**: rebuild `OverdueAccounts` from real data — either `GET /customers?…` filtered on `is_overdue`, or `GET /notifications` (overdue feed). Remove hardcoded array.
- **Cashflow / risk segmentation**: **NO backend endpoint** → either hide these widgets or mark them clearly as "not available" until an endpoint exists. Do **not** ship mock numbers as real. (UNKNOWN: intended data source.)

### 4.8 Admin / settings
- Users: list/create/edit (role, is_active — block self-deactivate), reset password.
- Roles & permissions: list only (assign/create = **no endpoint**, G8). Show as read-only.
- Profile: `/me`, `PATCH /me`, `POST /me/password`.
- Tenant: `GET /tenant` (display), `GET/PUT /settings/{key}` editor (G9/G10).
- Notifications feed: `GET /notifications` (G13).

---

## 5. SYSTEM FLOWS (match backend exactly)

### 5.1 Sale flow — `sale_service.create_sale`
```
validate customer (exists, not deleted, status==active else 409)
if installment: require months≥1, frequency∈{weekly,monthly}, start_date
for each item (FOR UPDATE on product & variant):
    resolve variant: explicit → that variant; else product's default variant; else product row
    check stock (variant.stock or product.stock) ≥ qty  else 409
    unit_price = variant.price_cash or product.base_price
    line_total = unit_price*qty − item_discount   (>0 else 400)
subtotal = Σ line_total ; total_price = subtotal − discount_amount  (>0 else 400)
installment: require 0 ≤ down_payment < total_price (else 400)
sale_number = "S-<year>-<seq>"
INSERT sale (status active) + sale_items (with name snapshots) ; decrement stock ; roll product.stock=Σvariants
LEDGER (sale): Dr 1100 AR total_price / Cr 4000 Revenue total_price
if cash:
    full payment → Dr 1000 Cash / Cr 1100 AR total_price ; sale.status=completed
else installment:
    principal = total − down ; base = principal//months (≤0 → 400) ; remainder→last
    INSERT plan(revision=1,status active) + Installment rows (status scheduled)
    if down>0: down payment → Dr 1000 / Cr 1100 down
emit domain_event sale_created ; AuditLog create ; RequestIdempotency stored
```
**Invariants UI must respect:** balanced ledger, integer math, idempotency replay returns original.

### 5.2 Payment flow — `payment_service.record_payment`
```
if idempotency_key exists → return original (replayed=true)
lock sale (FOR UPDATE); must exist & status==active else 404/409
fee = FEE_BY_METHOD[method] (all 0 today); amount>fee else 400
INSERT payment(status confirmed, receipt "R-<year>-<seq>", transaction_group_id)
lock active plan (FOR UPDATE) else 409
load scheduled installments ordered by number (FOR UPDATE)
outstanding[i] = amount[i] − Σ confirmed allocations[i]
if payment_amount > Σ outstanding → 409 overpayment (reject)
FIFO: for each installment in order: apply min(remaining, outstanding[i]) → PaymentAllocation ; set last_payment_at
LEDGER: fee==0 → Dr 1000 / Cr 1100 amount ;  fee>0 → Dr 1000 (amount−fee), Dr 5000 fee, Cr 1100 amount
if sale outstanding == 0 → plan.status=completed, sale.status=completed
emit payment_received
```

### 5.3 Customer lifecycle
`create → active → (sales/installments accrue receivable_balance via ledger) → block (status=blocked stops new sales) → unblock`. `receivable_balance` = AR debits − credits for that customer (`ledger_service.customer_receivable`). `next_due/is_overdue` derived from earliest scheduled installment of active plans.

### 5.4 Product + variants + stock
`create product (auto default variant if none) → add/edit variants (re-sync product.stock=Σ variant stock, base_price=default.price_cash) → images (≤8) → sale decrements stock`. Variant-less legacy products use the product row directly.

### 5.5 Ledger / accounting visibility
Every financial action posts a **balanced** transaction group. Read surfaces: journal (`GET /ledger`), trial balance (`GET /ledger/accounts`), totals (`GET /ledger/summary`), per-customer receivable (in customer payloads). Append-only — no edits/deletes. Reversal/reschedule reference types are defined but **not yet produced by any endpoint**.

### 5.6 Overdue lifecycle (background, not UI-triggered)
Daily job: for active plans, scheduled installments past due & not fully paid → set `late_days`, insert `CollectionLog(marked_late)` (dedup per day), queue Arabic WhatsApp `Notification`, emit `installment_overdue`. UI consumes results via `/notifications` and customer `is_overdue`.

---

## 6. STRICT RULES (enforce in every screen)

1. **Money = integer IQD.** No floats, no decimal inputs, no client money arithmetic beyond display. Mirror server rounding (floor base, remainder last) for previews only.
2. **No client-side authority over financial data.** Stock, allocations, balances, schedule, totals, statuses are server truth. Client previews must be labeled as estimates and replaced by server response.
3. **Respect idempotency.** Sales and payments must send a stable client-controlled `idempotency_key`; retries reuse it; handle `replayed`/stored-response without double-posting.
4. **Backend truth only.** Do not display data the backend does not provide. Remove all mock arrays (§3.1 G4). Where no endpoint exists (reversal, reschedule, cancel, cashflow, risk, roles-write, webhooks, attachments) the UI must omit or disable the action — never fake it.
5. **Permission-gate UI** to the token's `permissions[]`; expect and surface 403/409/422/500 exactly as returned.
6. **Tenant is implicit** (JWT). Never collect or send `tenant_id`.
7. **Soft-delete semantics**: "delete" = deactivate; reflect that wording.
8. **Use derived installment status** from the schedule payload; never recompute persisted status.

---

## 7. OPEN ITEMS — UNKNOWN / NEEDS BACKEND WORK

- **UNKNOWN** data source for cashflow projection and risk segmentation — no endpoint exists.
- **NO ENDPOINT** for: payment reversal, plan reschedule, sale cancel, role create/permission assignment, webhook management, attachment upload (non-product). These permissions/models exist but are unreachable over HTTP; a UI cannot integrate them until endpoints are added.
- **Contract fixes required** before the Ledger, Sales-list, and Payments-list screens work at all (G1–G3): either adapt the frontend types to the actual responses, or extend the backend serializers to include the expected fields (`customer_name`, `item_count`, paginated envelopes, per-entry ledger rows + `balance_after`). Decision is a product call — flagged, not assumed.
