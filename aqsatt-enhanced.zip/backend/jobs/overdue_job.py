"""Daily overdue job: refresh late_days, mark collection logs, emit
installment_overdue events, queue Arabic notifications. Idempotent per day.

Usage: python -m jobs.overdue_job
"""
import sys
from datetime import date

from sqlalchemy import func, select, text

from app.db.base import SessionLocal, set_tenant
from app.models import (
    CollectionLog, Customer, DomainEvent, Installment, InstallmentPlan, Notification,
    NotificationTemplate, Payment, PaymentAllocation, Sale, Tenant,
)

LOCK = 421001


def _paid(db, inst_id):
    return int(db.execute(
        select(func.coalesce(func.sum(PaymentAllocation.amount), 0))
        .join(Payment, Payment.id == PaymentAllocation.payment_id)
        .where(PaymentAllocation.installment_id == inst_id, Payment.status == "confirmed")
    ).scalar_one())


def _msg(db, tenant_id, customer, inst, outstanding):
    tmpl = db.execute(select(NotificationTemplate).where(
        NotificationTemplate.tenant_id == tenant_id, NotificationTemplate.key == "overdue",
        NotificationTemplate.channel == "whatsapp", NotificationTemplate.is_active == True)).scalars().first()  # noqa: E712
    if tmpl:
        return (tmpl.body_ar.replace("{{name}}", customer.full_name)
                .replace("{{amount}}", str(outstanding)).replace("{{due_date}}", str(inst.due_date)))
    return f"عزيزي {customer.full_name}، القسط المستحق بتاريخ {inst.due_date} متأخر. المبلغ المتبقي {outstanding} دينار."


def run() -> int:
    db = SessionLocal()
    try:
        if not db.execute(text("SELECT pg_try_advisory_lock(:k)"), {"k": LOCK}).scalar():
            print("overdue: locked; skip"); return 0
        try:
            today = date.today()
            total_late = 0
            for tid in db.execute(select(Tenant.id).where(Tenant.status == "active")).scalars().all():
                set_tenant(db, tid)
                rows = db.execute(
                    select(Installment).join(InstallmentPlan, InstallmentPlan.id == Installment.plan_id)
                    .where(Installment.status == "scheduled", Installment.due_date < today,
                           InstallmentPlan.status == "active")
                ).scalars().all()
                for r in rows:
                    if _paid(db, r.id) >= r.amount:
                        continue
                    r.late_days = (today - r.due_date).days
                    logged = db.execute(select(CollectionLog.id).where(
                        CollectionLog.installment_id == r.id, CollectionLog.action == "marked_late",
                        func.date(CollectionLog.created_at) == today)).first()
                    if logged:
                        continue
                    db.add(CollectionLog(tenant_id=tid, installment_id=r.id, action="marked_late",
                                         notes=f"late {r.late_days}d as of {today}"))
                    plan = db.get(InstallmentPlan, r.plan_id)
                    sale = db.get(Sale, plan.sale_id)
                    cust = db.get(Customer, sale.customer_id)
                    outstanding = r.amount - _paid(db, r.id)
                    db.add(Notification(tenant_id=tid, customer_id=cust.id, channel="whatsapp",
                                        message=_msg(db, tid, cust, r, outstanding),
                                        related_type="overdue", related_id=r.id, status="pending"))
                    db.add(DomainEvent(tenant_id=tid, event_type="installment_overdue",
                                       entity_type="installment", entity_id=r.id,
                                       payload={"installment_number": r.installment_number,
                                                "outstanding": outstanding, "customer_id": cust.id},
                                       status="pending", attempts=0))
                    total_late += 1
                db.commit()
            print(f"overdue: newly_late={total_late} date={today}")
            return 0
        finally:
            db.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": LOCK})
            db.commit()
    except Exception as e:  # noqa: BLE001
        db.rollback(); print(f"overdue: ERROR {e}", file=sys.stderr); return 1
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(run())
