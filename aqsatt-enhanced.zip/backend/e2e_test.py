import uuid
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from app.main import app
from app.core.config import settings

c = TestClient(app)
PASS, FAIL = [], []
def chk(n, ok): (PASS if ok else FAIL).append(n); print(("PASS " if ok else "FAIL ")+n)

# login
r = c.post("/api/v1/auth/login", json={"username":"admin","password":"admin123"})
chk("login 200", r.status_code==200)
tok = r.json()["access_token"]; H={"Authorization":f"Bearer {tok}"}
chk("admin has permissions", "payments.create" in r.json()["permissions"])
chk("tenant_id in token", r.json()["tenant_id"]==1)

# customer
cid = c.post("/api/v1/customers", headers=H, json={"full_name":"علي حسن","phone":f"077{uuid.uuid4().hex[:8]}","customer_type":"guarantor"}).json()["id"]
chk("customer created", bool(cid))

# product
pid = c.post("/api/v1/products", headers=H, json={"sku":f"SKU{uuid.uuid4().hex[:8]}","name":"Laptop","name_ar":"حاسبة محمولة","base_price":1200000,"stock_quantity":10}).json()["id"]
chk("product created", bool(pid))

# installment sale via idempotency
sale_key = str(uuid.uuid4())
sresp = c.post("/api/v1/sales", headers=H, json={"idempotency_key":sale_key,"customer_id":cid,"sale_type":"installment","items":[{"product_id":pid,"quantity":1}],"down_payment":200000,"months":5,"frequency":"monthly","start_date":"2026-01-15"})
chk("sale 201", sresp.status_code==201)
sale = sresp.json(); sid = sale["id"]
chk("sale_number present", sale["sale_number"].startswith("S-"))
chk("plan principal 1,000,000", sale["plan"]["principal_amount"]==1000000)
chk("5 schedule rows", len(sale["plan"]["schedule"])==5)
chk("schedule sums to principal", sum(s["amount"] for s in sale["plan"]["schedule"])==1000000)

# sale idempotency replay
sresp2 = c.post("/api/v1/sales", headers=H, json={"idempotency_key":sale_key,"customer_id":cid,"sale_type":"installment","items":[{"product_id":pid,"quantity":1}],"down_payment":200000,"months":5,"frequency":"monthly","start_date":"2026-01-15"})
chk("sale idempotent replay same id", sresp2.json()["id"]==sid)

# customer profile (FULL) — AR = 1,200,000 sale - 200,000 down = 1,000,000
prof = c.get(f"/api/v1/customers/{cid}", headers=H).json()
chk("profile AR balance == 1,000,000 (1.2M - 200k down)", prof["receivable_balance"]==1000000)
chk("profile shows sale with schedule", len(prof["sales"])==1 and len(prof["sales"][0]["schedule"])==5)

# schedule endpoint
plan_id = sale["plan"]["id"]
sched = c.get(f"/api/v1/plans/{plan_id}/schedule", headers=H).json()
chk("schedule endpoint", len(sched["schedule"])==5)

# payment with allocation
pay_key = str(uuid.uuid4())
p = c.post("/api/v1/payments", headers=H, json={"idempotency_key":pay_key,"sale_id":sid,"amount":200000,"payment_method":"cash"}).json()
chk("payment receipt present", p["receipt_number"].startswith("R-"))
chk("payment allocated to #1", p["allocations"][0]["installment_number"]==1)
# payment idempotency replay
p2 = c.post("/api/v1/payments", headers=H, json={"idempotency_key":pay_key,"sale_id":sid,"amount":200000,"payment_method":"cash"}).json()
chk("payment idempotent replay", p2["id"]==p["id"] and p2["replayed"]==True)
chk("AR now 800,000 (no double)", c.get(f"/api/v1/customers/{cid}", headers=H).json()["receivable_balance"]==800000)

# overflow allocation: pay 350,000 -> spans installments
p3 = c.post("/api/v1/payments", headers=H, json={"idempotency_key":str(uuid.uuid4()),"sale_id":sid,"amount":350000,"payment_method":"qi"}).json()
chk("overflow split 2 installments", len(p3["allocations"])==2)

# remaining installment outstanding now 450,000; overpayment must be rejected
ro = c.post("/api/v1/payments", headers=H, json={"idempotency_key":str(uuid.uuid4()),"sale_id":sid,"amount":999000,"payment_method":"cash"})
chk("overpayment 409", ro.status_code==409)

# pay exact remaining installment balance (450,000) to complete
pf = c.post("/api/v1/payments", headers=H, json={"idempotency_key":str(uuid.uuid4()),"sale_id":sid,"amount":450000,"payment_method":"cash"}).json()
chk("sale completed", pf["sale_status"]=="completed")
chk("AR 0 at completion", c.get(f"/api/v1/customers/{cid}", headers=H).json()["receivable_balance"]==0)

# dashboard
d = c.get("/api/v1/dashboard/summary", headers=H).json()
chk("dashboard keys", all(k in d for k in ("total_outstanding","today_payments","overdue_count")))

# domain events emitted (sale_created + payment_received)
eng = create_engine(settings.admin_database_url, future=True)
with eng.connect() as conn:
    types = [row[0] for row in conn.execute(text("SELECT event_type FROM domain_events WHERE tenant_id=1"))]
chk("sale_created event emitted", "sale_created" in types)
chk("payment_received event emitted", "payment_received" in types)

# RBAC: a staff user blocked from creating products
import app.db.seed as seed  # reuse session helper
from app.models import User, Role, UserRole, TenantMembership
from app.core.security import hash_password
S = seed.Session()
if not S.query(User).filter_by(username="staff1").first():
    u=User(home_tenant_id=1,name="Staff",username="staff1",password_hash=hash_password("staffpass"),is_active=True); S.add(u); S.flush()
    rid=S.query(Role).filter_by(tenant_id=1,name="staff").first().id
    S.add(TenantMembership(user_id=u.id,tenant_id=1,is_active=True)); S.add(UserRole(user_id=u.id,tenant_id=1,role_id=rid)); S.commit()
S.close()
sh={"Authorization":"Bearer "+c.post("/api/v1/auth/login",json={"username":"staff1","password":"staffpass"}).json()["access_token"]}
chk("staff blocked from product write 403", c.post("/api/v1/products",headers=sh,json={"sku":"X","name":"Y","name_ar":"ز","base_price":1,"stock_quantity":1}).status_code==403)
chk("staff can read customers", c.get("/api/v1/customers",headers=sh).status_code==200)

# RLS cross-tenant isolation: create tenant 2 + its customer; tenant-1 token must NOT see it
with eng.begin() as conn:
    conn.execute(text("INSERT INTO tenants (name,slug,type) VALUES ('Store B','storeb','store') ON CONFLICT DO NOTHING"))
    t2 = conn.execute(text("SELECT id FROM tenants WHERE slug='storeb'")).scalar()
    conn.execute(text("SET app.tenant_id='%d'" % t2))
    exists = conn.execute(text("SELECT 1 FROM customers WHERE tenant_id=:t AND phone='55501'"), {"t": t2}).first()
    if not exists:
        conn.execute(text("INSERT INTO customers (tenant_id,full_name,phone,created_by) VALUES (:t,'OtherTenantCust','55501',:u)"),
                     {"t": t2, "u": 1})
# tenant-1 admin lists customers -> must not include tenant-2 customer
names = [x["full_name"] for x in c.get("/api/v1/customers", headers=H).json()["data"]]
chk("RLS: tenant 1 cannot see tenant 2 customer", "OtherTenantCust" not in names)

print("\n==== RESULT ====")
print(f"PASSED {len(PASS)}  FAILED {len(FAIL)}")
if FAIL: print("FAILURES:", FAIL); raise SystemExit(1)
