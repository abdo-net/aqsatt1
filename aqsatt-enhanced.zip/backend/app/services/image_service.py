"""Image processing for product images. Accepts any input size, center-crops to a
1:1 square (consistent card ratio), and writes a full (800px) and thumb (300px)
version under static/uploads. Returns web paths served by the /static mount."""
import io
import os
import uuid

from PIL import Image

_STATIC = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "static")
_UPLOADS = os.path.join(_STATIC, "uploads")
FULL = 800
THUMB = 300


def _square(img: Image.Image, size: int) -> Image.Image:
    w, h = img.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    img = img.crop((left, top, left + side, top + side))
    return img.resize((size, size), Image.LANCZOS)


def save_square_image(raw: bytes, tenant_id: int, product_id: int) -> tuple[str, str]:
    """Persist a center-cropped square image + thumbnail. Returns (path, thumb_path)
    as web paths like '/static/uploads/<t>/<p>/<uuid>.jpg'. Raises ValueError on
    unreadable image data."""
    try:
        img = Image.open(io.BytesIO(raw))
        img.load()
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"invalid image: {e}")
    if img.mode in ("RGBA", "P", "LA"):
        img = img.convert("RGB")

    rel_dir = os.path.join(str(tenant_id), str(product_id))
    abs_dir = os.path.join(_UPLOADS, rel_dir)
    os.makedirs(abs_dir, exist_ok=True)
    name = uuid.uuid4().hex
    full_name, thumb_name = f"{name}.jpg", f"{name}_thumb.jpg"

    _square(img, FULL).save(os.path.join(abs_dir, full_name), "JPEG", quality=86)
    _square(img, THUMB).save(os.path.join(abs_dir, thumb_name), "JPEG", quality=82)

    web = "/static/uploads/" + rel_dir.replace(os.sep, "/")
    return f"{web}/{full_name}", f"{web}/{thumb_name}"
