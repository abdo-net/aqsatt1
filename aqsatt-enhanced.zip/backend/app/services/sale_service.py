import calendar
import uuid
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import bad_request, conflict, not_found
from app.models import Customer, Installment, InstallmentPlan, Payment, Product, ProductVariant, Sale, SaleItem
from app.services import event_service, ledger_service, sequence_service
from app.services.ledger_service import Line


def _add_months(d: date, m: int) -> date:
    total = d.month - 1 + m
    y = d.year + total // 12
    mo = total % 12 + 1
    return date(y, mo, min(d.day, calendar.monthrange(y, mo)[1]))


def _due(start: date, idx: int, freq: str) -> date:
    return date.fromordinal(start.toordinal() + 7 * idx) if freq == "weekly" else _add_months(start, idx)


def create_sale(db: Session, *, tenant_id: int, user_id: int, customer_id: int, sale_type: str,
                items: list[dict], discount_amount: int, down_payment: int,
                months: int | None, frequency: str | None, start_date: date | None,
                sale_channel: str, salesperson_id: int | None, notes: str | None) -> Sale:
    customer = db.get(Customer, customer_id)
    if not customer or customer.is_deleted:
        raise not_found("customer not found")
    if customer.status != "active":
        raise conflict("customer is blocked")

    if sale_type == "installment":
        if not months or months < 1:
            raise bad_request("months required for installment sale")
        if frequency not in ("weekly", "monthly"):
            raise bad_request("frequency must be weekly|monthly")
        if not start_date:
            raise bad_request("start_date required")

    line_data, subtotal = [], 0
    for it in items:
        prod = db.execute(select(Product).where(Product.id == it["product_id"]).with_for_update()).scalar_one_or_none()
        if not prod or prod.is_deleted or not prod.is_active:
            raise conflict(f"product {it['product_id']} unavailable")
        qty = it["quantity"]
        variant = None
        if it.get("variant_id"):
            variant = db.execute(select(ProductVariant).where(
                ProductVariant.id == it["variant_id"], ProductVariant.product_id == prod.id,
                ProductVariant.is_deleted == False).with_for_update()).scalar_one_or_none()  # noqa: E712
            if not variant:
                raise conflict(f"variant {it['variant_id']} unavailable")
        else:
            # No variant specified: if the product has variants, fall back to its
            # default variant so stock/price stay variant-accurate. Legacy
            # variant-less products (no rows in product_variants) use the product
            # row directly, unchanged.
            variant = db.execute(select(ProductVariant).where(
                ProductVariant.product_id == prod.id, ProductVariant.is_deleted == False,  # noqa: E712
                ProductVariant.is_default == True).with_for_update()).scalar_one_or_none()  # noqa: E712
        if variant:
            if variant.stock_quantity < qty:
                raise conflict(f"insufficient stock for variant {variant.id}")
            unit_price = variant.price_cash
        else:
            if prod.stock_quantity < qty:
                raise conflict(f"insufficient stock for product {prod.id}")
            unit_price = prod.base_price
        item_disc = int(it.get("item_discount", 0))
        line_total = unit_price * qty - item_disc
        if line_total <= 0:
            raise bad_request("line total must be positive")
        subtotal += line_total
        line_data.append((prod, variant, qty, unit_price, item_disc, line_total))

    total_price = subtotal - discount_amount
    if total_price <= 0:
        raise bad_request("total must be positive")
    if sale_type == "installment":
        if not (0 <= down_payment < total_price):
            raise bad_request("down_payment must be >=0 and < total")
        stored_down = down_payment
    else:
        stored_down = 0

    sale_no = sequence_service.format_number("S", sequence_service.next_number(db, tenant_id, "sale"))
    sale = Sale(
        tenant_id=tenant_id, sale_number=sale_no, customer_id=customer_id, sale_type=sale_type,
        sale_channel=sale_channel, salesperson_id=salesperson_id, subtotal=subtotal,
        discount_amount=discount_amount, total_price=total_price, down_payment=stored_down,
        status="active", notes=notes, created_by=user_id,
    )
    db.add(sale)
    db.flush()

    for prod, variant, qty, unit, item_disc, line_total in line_data:
        if variant:
            variant.stock_quantity -= qty
            prod.stock_quantity = sum(
                v.stock_quantity for v in db.execute(select(ProductVariant).where(
                    ProductVariant.product_id == prod.id, ProductVariant.is_deleted == False  # noqa: E712
                )).scalars().all())
        else:
            prod.stock_quantity -= qty
        db.add(SaleItem(
            tenant_id=tenant_id, sale_id=sale.id, product_id=prod.id, variant_id=variant.id if variant else None,
            name_snapshot=prod.name, name_ar_snapshot=prod.name_ar,
            quantity=qty, unit_price=unit, item_discount=item_disc, line_total=line_total,
        ))

    # ledger: recognize sale (Dr AR / Cr Revenue)
    ledger_service.post(
        db, tenant_id=tenant_id, transaction_group_id=uuid.uuid4(),
        lines=[Line("1100", debit=total_price, customer_id=customer_id, sale_id=sale.id, description="AR on sale"),
               Line("4000", credit=total_price, sale_id=sale.id, description="sales revenue")],
        reference_type="sale", reference_id=sale.id, user_id=user_id,
    )

    if sale_type == "cash":
        _full_cash_payment(db, tenant_id=tenant_id, user_id=user_id, sale=sale, amount=total_price)
        sale.status = "completed"
    else:
        principal = total_price - stored_down
        base = principal // months
        if base <= 0:
            raise bad_request("installment rounds to zero; fewer months or lower down payment")
        remainder = principal - base * months
        end = _due(start_date, months - 1, frequency)
        plan = InstallmentPlan(
            tenant_id=tenant_id, sale_id=sale.id, revision=1, principal_amount=principal,
            months=months, monthly_amount=base, frequency=frequency,
            start_date=start_date, end_date=end, status="active", created_by=user_id,
        )
        db.add(plan)
        db.flush()
        for k in range(months):
            db.add(Installment(
                tenant_id=tenant_id, plan_id=plan.id, installment_number=k + 1,
                due_date=_due(start_date, k, frequency),
                amount=base + (remainder if k == months - 1 else 0), status="scheduled",
            ))
        if stored_down > 0:
            _down_payment(db, tenant_id=tenant_id, user_id=user_id, sale=sale, amount=stored_down)

    event_service.emit(db, tenant_id=tenant_id, event_type="sale_created", entity_type="sale",
                       entity_id=sale.id, payload={"sale_number": sale.sale_number, "total": total_price})
    return sale


def _receipt(db, tenant_id):
    return sequence_service.format_number("R", sequence_service.next_number(db, tenant_id, "receipt"))


def _full_cash_payment(db, *, tenant_id, user_id, sale, amount):
    p = Payment(
        tenant_id=tenant_id, receipt_number=_receipt(db, tenant_id),
        idempotency_key=f"sale-{sale.id}-cash", customer_id=sale.customer_id, sale_id=sale.id,
        amount=amount, fee_amount=0, payment_method="cash", status="confirmed", source="manual",
        received_by=user_id, transaction_group_id=uuid.uuid4(), created_by=user_id,
    )
    db.add(p); db.flush()
    ledger_service.post(db, tenant_id=tenant_id, transaction_group_id=p.transaction_group_id,
                        lines=[Line("1000", debit=amount, sale_id=sale.id, description="cash sale"),
                               Line("1100", credit=amount, customer_id=sale.customer_id, sale_id=sale.id, description="AR cash sale")],
                        reference_type="payment", reference_id=p.id, user_id=user_id)


def _down_payment(db, *, tenant_id, user_id, sale, amount):
    p = Payment(
        tenant_id=tenant_id, receipt_number=_receipt(db, tenant_id),
        idempotency_key=f"sale-{sale.id}-downpayment", customer_id=sale.customer_id, sale_id=sale.id,
        amount=amount, fee_amount=0, payment_method="cash", status="confirmed", source="manual",
        received_by=user_id, transaction_group_id=uuid.uuid4(), created_by=user_id,
    )
    db.add(p); db.flush()
    ledger_service.post(db, tenant_id=tenant_id, transaction_group_id=p.transaction_group_id,
                        lines=[Line("1000", debit=amount, sale_id=sale.id, description="down payment"),
                               Line("1100", credit=amount, customer_id=sale.customer_id, sale_id=sale.id, description="AR down payment")],
                        reference_type="payment", reference_id=p.id, user_id=user_id)
