"""Read-only notifications feed (written by the overdue job). RLS-scoped."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.models import Customer, Notification

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


@router.get("")
def list_notifications(limit: int = Query(100, ge=1, le=300),
                       db: Session = Depends(get_db), user=Depends(require_permission("reports.read"))):
    rows = db.execute(select(Notification).order_by(Notification.id.desc()).limit(limit)).scalars().all()
    names = {c.id: c.full_name for c in db.execute(select(Customer)).scalars().all()}
    return [{"id": n.id, "customer_id": n.customer_id, "customer_name": names.get(n.customer_id, "—"),
             "channel": n.channel, "message": n.message, "related_type": n.related_type,
             "related_id": n.related_id, "status": n.status, "created_at": n.created_at.isoformat()}
            for n in rows]
