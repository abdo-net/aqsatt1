import uuid
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import APIRouter, Request
from sqlalchemy import select

from app.core.config import settings
from app.core.errors import unauthorized
from app.core.security import (
    create_access_token, create_refresh_token, decode_refresh_token, new_jti, verify_password,
)
from app.db.base import SessionLocal
from app.models import (
    Permission, RefreshToken, Role, RolePermission, TenantMembership, User, UserRole,
)
from app.schemas import (
    LoginRequest, LoginResponse, LogoutRequest, RefreshRequest, RefreshResponse,
)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

_ACCESS_TTL = settings.jwt_access_exp_minutes * 60
_REFRESH_TTL = settings.jwt_refresh_exp_days * 86400


def resolve_permissions(db, user_id: int, tenant_id: int) -> list[str]:
    rows = db.execute(
        select(Permission.code)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(Role, Role.id == RolePermission.role_id)
        .join(UserRole, UserRole.role_id == Role.id)
        .where(UserRole.user_id == user_id, UserRole.tenant_id == tenant_id)
    ).scalars().all()
    return sorted(set(rows))


def _issue_pair(db, *, user_id: int, tenant_id: int, perms: list[str], user_agent: str | None):
    """Mint a fresh access+refresh pair and persist the refresh jti server-side."""
    jti = new_jti()
    access = create_access_token(user_id=user_id, tenant_id=tenant_id, permissions=perms)
    refresh = create_refresh_token(user_id=user_id, tenant_id=tenant_id, jti=jti)
    db.add(RefreshToken(
        jti=uuid.UUID(jti), user_id=user_id, tenant_id=tenant_id,
        expires_at=datetime.now(tz=timezone.utc) + timedelta(days=settings.jwt_refresh_exp_days),
        user_agent=(user_agent or "")[:255] or None,
    ))
    return access, refresh


@router.post("/login", response_model=LoginResponse)
def login(body: LoginRequest, request: Request):
    # Auth runs without tenant RLS context (auth/RBAC tables are app-scoped).
    db = SessionLocal()
    try:
        user = db.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
        if not user or user.is_deleted or not user.is_active or not verify_password(body.password, user.password_hash):
            raise unauthorized("invalid credentials")
        membership = db.execute(
            select(TenantMembership).where(
                TenantMembership.user_id == user.id, TenantMembership.is_active == True,  # noqa: E712
                TenantMembership.is_deleted == False)  # noqa: E712
        ).scalars().first()
        if not membership:
            raise unauthorized("no active tenant membership")
        tenant_id = membership.tenant_id
        perms = resolve_permissions(db, user.id, tenant_id)
        access, refresh = _issue_pair(
            db, user_id=user.id, tenant_id=tenant_id, perms=perms,
            user_agent=request.headers.get("user-agent"),
        )
        db.commit()
        return LoginResponse(
            access_token=access, refresh_token=refresh,
            access_expires_in=_ACCESS_TTL, refresh_expires_in=_REFRESH_TTL,
            tenant_id=tenant_id, user_id=user.id, permissions=perms,
        )
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


@router.post("/refresh", response_model=RefreshResponse)
def refresh(body: RefreshRequest, request: Request):
    """Validate a refresh token against the server-side registry, then ROTATE:
    revoke the presented jti and issue a brand-new access+refresh pair. A revoked,
    expired, or unknown jti is rejected, defeating replay of a leaked old token."""
    db = SessionLocal()
    try:
        try:
            claims = decode_refresh_token(body.refresh_token)
        except jwt.ExpiredSignatureError:
            raise unauthorized("refresh token expired")
        except jwt.PyJWTError:
            raise unauthorized("invalid refresh token")

        row = db.execute(
            select(RefreshToken).where(RefreshToken.jti == uuid.UUID(claims["jti"]))
        ).scalar_one_or_none()
        now = datetime.now(tz=timezone.utc)
        if row is None or row.revoked_at is not None or row.expires_at <= now:
            raise unauthorized("refresh token is not active")

        user = db.get(User, claims["user_id"])
        if not user or user.is_deleted or not user.is_active:
            raise unauthorized("user is not active")

        perms = resolve_permissions(db, user.id, claims["tenant_id"])
        row.revoked_at = now  # rotation: invalidate the old refresh token
        access, refresh_token = _issue_pair(
            db, user_id=user.id, tenant_id=claims["tenant_id"], perms=perms,
            user_agent=request.headers.get("user-agent"),
        )
        db.commit()
        return RefreshResponse(
            access_token=access, refresh_token=refresh_token,
            access_expires_in=_ACCESS_TTL, refresh_expires_in=_REFRESH_TTL,
            tenant_id=claims["tenant_id"], user_id=user.id, permissions=perms,
        )
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


@router.post("/logout")
def logout(body: LogoutRequest):
    """Revoke the presented refresh token. Idempotent: an undecodable or unknown
    token still returns success (the client clears cookies regardless)."""
    db = SessionLocal()
    try:
        try:
            claims = decode_refresh_token(body.refresh_token)
        except jwt.PyJWTError:
            return {"status": "logged_out"}
        row = db.execute(
            select(RefreshToken).where(RefreshToken.jti == uuid.UUID(claims["jti"]))
        ).scalar_one_or_none()
        if row is not None and row.revoked_at is None:
            row.revoked_at = datetime.now(tz=timezone.utc)
            db.commit()
        return {"status": "logged_out"}
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
