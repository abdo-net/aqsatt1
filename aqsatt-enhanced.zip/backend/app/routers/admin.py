"""User & role management. Additive endpoints over EXISTING tables
(users, tenant_memberships, user_roles, roles, permissions). No schema change.
These tables are app-scoped (not RLS), so every query is filtered by the
caller's tenant_id explicitly."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import bad_request, conflict, not_found
from app.core.security import hash_password
from app.models import (Permission, Role, RolePermission, TenantMembership,
                        User, UserRole)
from app.schemas import PasswordReset, UserCreate, UserUpdate

router = APIRouter(prefix="/api/v1", tags=["admin"])


def _role_of(db: Session, user_id: int, tenant_id: int):
    return db.execute(
        select(Role).join(UserRole, UserRole.role_id == Role.id)
        .where(UserRole.user_id == user_id, UserRole.tenant_id == tenant_id)
    ).scalars().first()


def _user_out(db, u: User, tenant_id: int):
    r = _role_of(db, u.id, tenant_id)
    return {"id": u.id, "name": u.name, "username": u.username, "is_active": u.is_active,
            "role_id": r.id if r else None, "role_name": r.name if r else None,
            "created_at": u.created_at.isoformat()}


@router.get("/users")
def list_users(db: Session = Depends(get_db), user=Depends(require_permission("users.manage"))):
    tid = user["tenant_id"]
    uids = db.execute(select(TenantMembership.user_id).where(
        TenantMembership.tenant_id == tid, TenantMembership.is_deleted == False)).scalars().all()  # noqa: E712
    users = db.execute(select(User).where(User.id.in_(uids), User.is_deleted == False)  # noqa: E712
                       .order_by(User.id)).scalars().all()
    return [_user_out(db, u, tid) for u in users]


@router.post("/users", status_code=201)
def create_user(body: UserCreate, db: Session = Depends(get_db),
                user=Depends(require_permission("users.manage"))):
    tid = user["tenant_id"]
    role = db.execute(select(Role).where(Role.id == body.role_id, Role.tenant_id == tid)).scalar_one_or_none()
    if not role:
        raise bad_request("role not found for this tenant")
    u = User(home_tenant_id=tid, name=body.name, username=body.username,
             password_hash=hash_password(body.password), is_active=True)
    db.add(u)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise conflict("username already exists")
    db.add(TenantMembership(user_id=u.id, tenant_id=tid, is_active=True))
    db.add(UserRole(user_id=u.id, tenant_id=tid, role_id=role.id))
    db.commit()
    db.refresh(u)
    return _user_out(db, u, tid)


@router.patch("/users/{user_id}")
def update_user(user_id: int, body: UserUpdate, db: Session = Depends(get_db),
                user=Depends(require_permission("users.manage"))):
    tid = user["tenant_id"]
    member = db.execute(select(TenantMembership).where(
        TenantMembership.user_id == user_id, TenantMembership.tenant_id == tid)).scalar_one_or_none()
    if not member:
        raise not_found("user not in tenant")
    u = db.get(User, user_id)
    if body.name is not None:
        u.name = body.name
    if body.is_active is not None:
        if user_id == user["user_id"] and body.is_active is False:
            raise bad_request("cannot deactivate yourself")
        u.is_active = body.is_active
        member.is_active = body.is_active
    if body.role_id is not None:
        role = db.execute(select(Role).where(Role.id == body.role_id, Role.tenant_id == tid)).scalar_one_or_none()
        if not role:
            raise bad_request("role not found")
        # UPDATE the existing mapping (app role has no DELETE; system never hard-deletes)
        existing = db.execute(select(UserRole).where(
            UserRole.user_id == user_id, UserRole.tenant_id == tid)).scalars().first()
        if existing:
            existing.role_id = role.id
        else:
            db.add(UserRole(user_id=user_id, tenant_id=tid, role_id=role.id))
    db.commit()
    db.refresh(u)
    return _user_out(db, u, tid)


@router.post("/users/{user_id}/password")
def reset_password(user_id: int, body: PasswordReset, db: Session = Depends(get_db),
                   user=Depends(require_permission("users.manage"))):
    tid = user["tenant_id"]
    member = db.execute(select(TenantMembership).where(
        TenantMembership.user_id == user_id, TenantMembership.tenant_id == tid)).scalar_one_or_none()
    if not member:
        raise not_found("user not in tenant")
    u = db.get(User, user_id)
    u.password_hash = hash_password(body.new_password)
    u.updated_at = datetime.now(tz=timezone.utc)
    db.commit()
    return {"id": user_id, "status": "password_reset"}


@router.get("/roles")
def list_roles(db: Session = Depends(get_db), user=Depends(require_permission("users.manage"))):
    tid = user["tenant_id"]
    roles = db.execute(select(Role).where(Role.tenant_id == tid, Role.is_deleted == False)  # noqa: E712
                       .order_by(Role.id)).scalars().all()
    perms = {p.id: p.code for p in db.execute(select(Permission)).scalars().all()}
    out = []
    for r in roles:
        pcodes = db.execute(select(RolePermission.permission_id).where(RolePermission.role_id == r.id)).scalars().all()
        out.append({"id": r.id, "name": r.name, "description": r.description,
                    "is_system": r.is_system, "permissions": sorted(perms[p] for p in pcodes if p in perms)})
    return out


@router.get("/permissions")
def list_permissions(db: Session = Depends(get_db), user=Depends(require_permission("users.manage"))):
    return [{"code": p.code, "description": p.description}
            for p in db.execute(select(Permission).order_by(Permission.code)).scalars().all()]
