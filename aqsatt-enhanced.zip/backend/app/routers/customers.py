from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import conflict, not_found
from app.core.pagination import paginate
from app.models import AuditLog, Customer, Sale
from app.schemas import CustomerCreate, CustomerUpdate
from app.services import ledger_service, payment_service
from app.models import Installment, InstallmentPlan

router = APIRouter(prefix="/api/v1/customers", tags=["customers"])


def _out(c: Customer) -> dict:
    return {"id": c.id, "public_id": str(c.public_id), "full_name": c.full_name, "phone": c.phone,
            "alt_phone": c.alt_phone, "national_id": c.national_id, "address": c.address,
            "notes": c.notes, "customer_type": c.customer_type,
            "birth_date": c.birth_date.isoformat() if c.birth_date else None,
            "nearest_landmark": c.nearest_landmark, "status": c.status,
            "created_at": c.created_at.isoformat()}


@router.post("", status_code=201)
def create(body: CustomerCreate, db: Session = Depends(get_db),
           user=Depends(require_permission("customers.write"))):
    c = Customer(tenant_id=user["tenant_id"], created_by=user["user_id"], **body.model_dump())
    db.add(c)
    try:
        db.flush()
        db.add(AuditLog(tenant_id=user["tenant_id"], entity_type="customer", entity_id=c.id,
                        action="create", new_data=_out(c), changed_by=user["user_id"]))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise conflict("phone already exists")
    db.refresh(c)
    return _out(c)


@router.get("")
def list_customers(phone: str | None = None, name: str | None = None,
                   page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200),
                   db: Session = Depends(get_db), user=Depends(require_permission("customers.read"))):
    stmt = select(Customer).where(Customer.is_deleted == False)  # noqa: E712
    if phone:
        stmt = stmt.where(Customer.phone == phone)
    if name:
        stmt = stmt.where(Customer.full_name.ilike(f"%{name}%"))

    from datetime import date as _date

    def _enrich(c: Customer) -> dict:
        row = _out(c)
        row["receivable_balance"] = ledger_service.customer_receivable(db, user["tenant_id"], c.id)
        next_due = db.execute(
            select(Installment.due_date).join(InstallmentPlan, InstallmentPlan.id == Installment.plan_id)
            .join(Sale, Sale.id == InstallmentPlan.sale_id)
            .where(Sale.customer_id == c.id, Installment.status == "scheduled",
                   Sale.is_deleted == False, InstallmentPlan.status == "active")
            .order_by(Installment.due_date).limit(1)
        ).scalar_one_or_none()
        row["next_due"] = next_due.isoformat() if next_due else None
        row["is_overdue"] = bool(next_due and next_due < _date.today())
        return row

    return paginate(db, stmt, page, page_size, serializer=_enrich, order_by=Customer.id.desc())


@router.get("/{customer_id}")
def profile(customer_id: int, db: Session = Depends(get_db),
            user=Depends(require_permission("customers.read"))):
    c = db.get(Customer, customer_id)
    if not c or c.is_deleted:
        raise not_found("customer not found")
    out = _out(c)
    out["receivable_balance"] = ledger_service.customer_receivable(db, user["tenant_id"], customer_id)
    sales = db.execute(select(Sale).where(Sale.customer_id == customer_id, Sale.is_deleted == False)).scalars().all()  # noqa: E712
    out["sales"] = []
    for s in sales:
        srow = {"id": s.id, "sale_number": s.sale_number, "type": s.sale_type,
                "total_price": s.total_price, "status": s.status, "schedule": []}
        plan = db.execute(select(InstallmentPlan).where(InstallmentPlan.sale_id == s.id, InstallmentPlan.status == "active")).scalars().first()
        if plan:
            insts = db.execute(select(Installment).where(Installment.plan_id == plan.id).order_by(Installment.installment_number)).scalars().all()
            srow["schedule"] = [payment_service.installment_state(db, i) for i in insts]
        out["sales"].append(srow)
    return out


@router.patch("/{customer_id}")
def update(customer_id: int, body: CustomerUpdate, db: Session = Depends(get_db),
           user=Depends(require_permission("customers.write"))):
    c = db.get(Customer, customer_id)
    if not c or c.is_deleted:
        raise not_found("customer not found")
    before = _out(c)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(c, k, v)
    try:
        db.flush()
        db.add(AuditLog(tenant_id=user["tenant_id"], entity_type="customer", entity_id=c.id,
                        action="update", old_data=before, new_data=_out(c), changed_by=user["user_id"]))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise conflict("phone already exists")
    db.refresh(c)
    return _out(c)
