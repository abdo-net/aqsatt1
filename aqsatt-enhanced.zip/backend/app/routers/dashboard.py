from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.models import Customer, Installment, InstallmentPlan, Payment, PaymentAllocation, Sale
from app.services import ledger_service

router = APIRouter(prefix="/api/v1/dashboard", tags=["dashboard"])


@router.get("/summary")
def summary(db: Session = Depends(get_db), user=Depends(require_permission("reports.read"))):
    tid = user["tenant_id"]
    total_outstanding = ledger_service.account_balance(db, tid, "1100")  # AR balance = unpaid debt

    # total paid = AR credits attributable to payments == cash collected lifetime
    cash_total = ledger_service.account_balance(db, tid, "1000")

    today = date.today()
    today_paid = db.execute(
        select(func.coalesce(func.sum(Payment.amount - Payment.fee_amount), 0))
        .where(func.date(Payment.created_at) == today, Payment.status == "confirmed",
               Payment.reversed_payment_id.is_(None))
    ).scalar_one()

    # overdue installments = scheduled, past due, not fully paid (derived)
    overdue = 0
    rows = db.execute(
        select(Installment).join(InstallmentPlan, InstallmentPlan.id == Installment.plan_id)
        .where(Installment.status == "scheduled", Installment.due_date < today,
               InstallmentPlan.status == "active")
    ).scalars().all()
    for r in rows:
        paid = db.execute(
            select(func.coalesce(func.sum(PaymentAllocation.amount), 0))
            .join(Payment, Payment.id == PaymentAllocation.payment_id)
            .where(PaymentAllocation.installment_id == r.id, Payment.status == "confirmed")
        ).scalar_one()
        if paid < r.amount:
            overdue += 1

    customers = db.execute(select(func.count(Customer.id)).where(Customer.is_deleted == False)).scalar_one()  # noqa: E712
    active_sales = db.execute(select(func.count(Sale.id)).where(Sale.status == "active", Sale.is_deleted == False)).scalar_one()  # noqa: E712

    return {
        "total_outstanding": int(total_outstanding),
        "total_cash_collected": int(cash_total),
        "today_payments": int(today_paid),
        "overdue_count": int(overdue),
        "customers_count": int(customers),
        "active_sales_count": int(active_sales),
    }
