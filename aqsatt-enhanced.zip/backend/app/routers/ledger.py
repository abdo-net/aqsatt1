"""Read-only ledger projections. No business logic, no writes — exposes existing
append-only ledger data for the UI. RLS-scoped via get_db; permission: ledger.read."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.models import Account, LedgerEntry
from app.services import ledger_service

router = APIRouter(prefix="/api/v1/ledger", tags=["ledger"])


@router.get("")
def list_entries(customer_id: int | None = None, limit: int = Query(120, ge=1, le=500),
                 db: Session = Depends(get_db), user=Depends(require_permission("ledger.read"))):
    accounts = {a.id: a for a in db.execute(select(Account)).scalars().all()}
    stmt = select(LedgerEntry).order_by(LedgerEntry.id.desc()).limit(limit)
    if customer_id:
        stmt = select(LedgerEntry).where(LedgerEntry.customer_id == customer_id).order_by(LedgerEntry.id.desc()).limit(limit)
    rows = db.execute(stmt).scalars().all()
    # group by transaction_group_id, preserving recency order of first appearance
    groups, order = {}, []
    for e in rows:
        g = str(e.transaction_group_id)
        if g not in groups:
            groups[g] = {"transaction_group_id": g, "reference_type": e.reference_type,
                         "reference_id": e.reference_id, "created_at": e.created_at.isoformat(),
                         "lines": [], "total": 0}
            order.append(g)
        acc = accounts.get(e.account_id)
        groups[g]["lines"].append({
            "account_code": acc.code if acc else "?", "account_name": acc.name if acc else "?",
            "account_name_ar": acc.name_ar if acc else "?",
            "debit": e.debit_amount, "credit": e.credit_amount,
            "description": e.description, "customer_id": e.customer_id, "sale_id": e.sale_id,
        })
        groups[g]["total"] += e.debit_amount
    return [groups[g] for g in order]


@router.get("/accounts")
def account_balances(db: Session = Depends(get_db), user=Depends(require_permission("ledger.read"))):
    out = []
    for a in db.execute(select(Account).order_by(Account.code)).scalars().all():
        out.append({"code": a.code, "name": a.name, "name_ar": a.name_ar, "type": a.type,
                    "normal_balance": a.normal_balance,
                    "balance": ledger_service.account_balance(db, user["tenant_id"], a.code)})
    return out


@router.get("/summary")
def ledger_summary(customer_id: int | None = None,
                   date_from: str | None = None, date_to: str | None = None,
                   db: Session = Depends(get_db), user=Depends(require_permission("ledger.read"))):
    """Aggregate totals for the ledger header card (LedgerSummary). RLS-scoped
    via get_db; filters are optional and additive."""
    from sqlalchemy import func as _func

    stmt = select(
        _func.coalesce(_func.sum(LedgerEntry.debit_amount), 0),
        _func.coalesce(_func.sum(LedgerEntry.credit_amount), 0),
        _func.count(LedgerEntry.id),
    )
    if customer_id:
        stmt = stmt.where(LedgerEntry.customer_id == customer_id)
    if date_from:
        stmt = stmt.where(LedgerEntry.created_at >= date_from)
    if date_to:
        stmt = stmt.where(LedgerEntry.created_at <= date_to)
    total_debits, total_credits, entry_count = db.execute(stmt).one()
    return {
        "total_debits": int(total_debits), "total_credits": int(total_credits),
        "net_balance": int(total_debits) - int(total_credits), "entry_count": int(entry_count),
    }
