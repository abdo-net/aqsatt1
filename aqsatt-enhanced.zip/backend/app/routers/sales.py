from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.deps import get_db, require_permission
from app.core.errors import conflict, not_found
from app.core.pagination import paginate
from app.models import (
    AuditLog, Installment, InstallmentPlan, RequestIdempotency, Sale, SaleItem,
)
from app.schemas import SaleCreate
from app.services import payment_service, sale_service

router = APIRouter(prefix="/api/v1/sales", tags=["sales"])


def _serialize(db: Session, sale: Sale) -> dict:
    items = db.execute(select(SaleItem).where(SaleItem.sale_id == sale.id)).scalars().all()
    out = {
        "id": sale.id, "public_id": str(sale.public_id), "sale_number": sale.sale_number,
        "customer_id": sale.customer_id, "sale_type": sale.sale_type, "sale_channel": sale.sale_channel,
        "subtotal": sale.subtotal, "discount_amount": sale.discount_amount,
        "total_price": sale.total_price, "down_payment": sale.down_payment, "status": sale.status,
        "notes": sale.notes, "created_at": sale.created_at.isoformat(),
        "items": [{"product_id": i.product_id, "variant_id": i.variant_id, "name": i.name_snapshot, "name_ar": i.name_ar_snapshot,
                   "quantity": i.quantity, "unit_price": i.unit_price, "item_discount": i.item_discount,
                   "line_total": i.line_total} for i in items],
        "plan": None,
    }
    plan = db.execute(select(InstallmentPlan).where(
        InstallmentPlan.sale_id == sale.id, InstallmentPlan.status.in_(["active", "completed"]))
        .order_by(InstallmentPlan.revision.desc())).scalars().first()
    if plan:
        insts = db.execute(select(Installment).where(Installment.plan_id == plan.id).order_by(Installment.installment_number)).scalars().all()
        out["plan"] = {
            "id": plan.id, "principal_amount": plan.principal_amount, "months": plan.months,
            "monthly_amount": plan.monthly_amount, "frequency": plan.frequency,
            "start_date": str(plan.start_date), "end_date": str(plan.end_date), "status": plan.status,
            "schedule": [payment_service.installment_state(db, i) for i in insts],
        }
    return out


@router.post("", status_code=201)
def create_sale(body: SaleCreate, db: Session = Depends(get_db),
                user=Depends(require_permission("sales.create"))):
    tid = user["tenant_id"]
    # generic request idempotency
    existing = db.execute(select(RequestIdempotency).where(
        RequestIdempotency.tenant_id == tid, RequestIdempotency.idempotency_key == body.idempotency_key,
        RequestIdempotency.endpoint == "POST /sales")).scalar_one_or_none()
    if existing:
        return existing.response_body
    try:
        sale = sale_service.create_sale(
            db, tenant_id=tid, user_id=user["user_id"], customer_id=body.customer_id,
            sale_type=body.sale_type, items=[i.model_dump() for i in body.items],
            discount_amount=body.discount_amount, down_payment=body.down_payment,
            months=body.months, frequency=body.frequency, start_date=body.start_date,
            sale_channel=body.sale_channel, salesperson_id=body.salesperson_id, notes=body.notes,
        )
        db.flush()
        result = _serialize(db, sale)
        db.add(AuditLog(tenant_id=tid, entity_type="sale", entity_id=sale.id, action="create",
                        new_data={"sale_number": sale.sale_number, "total": sale.total_price},
                        changed_by=user["user_id"]))
        db.add(RequestIdempotency(tenant_id=tid, idempotency_key=body.idempotency_key,
                                  endpoint="POST /sales", response_code=201, response_body=result))
        db.commit()
        return result
    except IntegrityError:
        db.rollback()
        ex = db.execute(select(RequestIdempotency).where(
            RequestIdempotency.tenant_id == tid, RequestIdempotency.idempotency_key == body.idempotency_key,
            RequestIdempotency.endpoint == "POST /sales")).scalar_one_or_none()
        if ex:
            return ex.response_body
        raise
    except Exception:
        db.rollback()
        raise


@router.get("")
def list_sales(customer_id: int | None = None, status: str | None = None, sale_type: str | None = None,
               page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200),
               db: Session = Depends(get_db), user=Depends(require_permission("sales.read"))):
    stmt = select(Sale).where(Sale.is_deleted == False)  # noqa: E712
    if customer_id:
        stmt = stmt.where(Sale.customer_id == customer_id)
    if status:
        stmt = stmt.where(Sale.status == status)
    if sale_type:
        stmt = stmt.where(Sale.sale_type == sale_type)
    return paginate(db, stmt, page, page_size, serializer=lambda s: _serialize(db, s), order_by=Sale.id.desc())


@router.get("/{sale_id}")
def get_sale(sale_id: int, db: Session = Depends(get_db),
             user=Depends(require_permission("sales.read"))):
    s = db.get(Sale, sale_id)
    if not s or s.is_deleted:
        raise not_found("sale not found")
    return _serialize(db, s)


@router.get("/{sale_id}/schedule")
def sale_schedule(sale_id: int, db: Session = Depends(get_db),
                  user=Depends(require_permission("sales.read"))):
    """Installment schedule for one sale, shaped for the payments UI
    (SaleSchedule). Resolves the active/completed plan for the sale and projects
    per-installment paid/remaining/status via the same installment_state used by
    the sale serializer — single source of truth, no duplicated math."""
    from app.models import Customer

    s = db.get(Sale, sale_id)
    if not s or s.is_deleted:
        raise not_found("sale not found")
    customer = db.get(Customer, s.customer_id)
    plan = db.execute(select(InstallmentPlan).where(
        InstallmentPlan.sale_id == s.id, InstallmentPlan.status.in_(["active", "completed"]))
        .order_by(InstallmentPlan.revision.desc())).scalars().first()
    installments = []
    if plan:
        insts = db.execute(select(Installment).where(Installment.plan_id == plan.id)
                           .order_by(Installment.installment_number)).scalars().all()
        installments = [payment_service.installment_state(db, i) for i in insts]
    return {
        "id": s.id, "sale_number": s.sale_number,
        "customer_name": customer.full_name if customer else "",
        "total_price": s.total_price, "down_payment": s.down_payment,
        "installments": installments,
    }
