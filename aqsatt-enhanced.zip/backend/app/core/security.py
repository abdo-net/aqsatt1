import uuid
from datetime import datetime, timedelta, timezone

import jwt
from passlib.context import CryptContext

from app.core.config import settings

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(p: str) -> str:
    return _pwd.hash(p)


def verify_password(p: str, h: str) -> bool:
    return _pwd.verify(p, h)


def _exp(delta: timedelta) -> datetime:
    return datetime.now(tz=timezone.utc) + delta


def create_access_token(*, user_id: int, tenant_id: int, permissions: list[str]) -> str:
    payload = {
        "sub": str(user_id),
        "tid": tenant_id,
        "perms": permissions,
        "typ": "access",
        "exp": _exp(timedelta(minutes=settings.jwt_access_exp_minutes)),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def create_refresh_token(*, user_id: int, tenant_id: int, jti: str) -> str:
    payload = {
        "sub": str(user_id),
        "tid": tenant_id,
        "jti": jti,
        "typ": "refresh",
        "exp": _exp(timedelta(days=settings.jwt_refresh_exp_days)),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def new_jti() -> str:
    return str(uuid.uuid4())


def decode_token(token: str) -> dict:
    """Decode and validate an ACCESS token. Rejects refresh tokens presented as
    access (typ guard) so a long-lived refresh token can never be used as a
    bearer credential against the API."""
    d = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    if d.get("typ") == "refresh":
        raise jwt.InvalidTokenError("refresh token cannot be used as access token")
    return {"user_id": int(d["sub"]), "tenant_id": int(d["tid"]), "permissions": d.get("perms", [])}


def decode_refresh_token(token: str) -> dict:
    """Decode and validate a REFRESH token. Requires typ=refresh and a jti."""
    d = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    if d.get("typ") != "refresh" or "jti" not in d:
        raise jwt.InvalidTokenError("not a refresh token")
    return {"user_id": int(d["sub"]), "tenant_id": int(d["tid"]), "jti": d["jti"]}
