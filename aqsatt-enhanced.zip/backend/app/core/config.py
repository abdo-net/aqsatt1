from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg2://ccs_app:ccs_app_pass@localhost:5432/ccs"
    admin_database_url: str = "postgresql+psycopg2://postgres@localhost:5432/ccs"

    # SECURITY: this MUST be identical to the Next.js JWT_SECRET (middleware.ts /
    # env.mjs verify access tokens with the SAME secret). The frontend env schema
    # requires >= 32 chars, so this default is >= 32 chars too. The installer
    # generates ONE shared secret and writes it into both .env files.
    jwt_secret: str = "dev-secret-change-me-32-chars-long"

    # Access token is now short-lived; long-lived sessions are sustained by the
    # refresh token instead of a 12h access token. Kept jwt_exp_hours for
    # backward compatibility (unused once access_exp_minutes is set).
    jwt_exp_hours: int = 12
    jwt_access_exp_minutes: int = 120        # 2h access token
    jwt_refresh_exp_days: int = 30           # 30d refresh token

    default_tenant_name: str = "Default Store"
    default_tenant_slug: str = "default"
    default_admin_username: str = "admin"
    default_admin_password: str = "admin123"

    whatsapp_api_url: str = ""
    whatsapp_api_token: str = ""

    # Comma-separated list of origins allowed to call this API with credentials
    # (cookies). CORS with allow_credentials=True does not permit a wildcard "*".
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
