import os

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.core.errors import LedgerImbalance
from app.routers import (account, admin, auth, categories, customers, dashboard,
                         installments, ledger, notifications, payments, products, sales)

app = FastAPI(title="Credit Commerce System", version="1.0.0")

# CORS for the decoupled Next.js frontend. allow_credentials=True is required
# because auth uses an httpOnly cookie set by the Next.js Route Handler proxy —
# this means allow_origins CANNOT be "*" (the CORS spec forbids wildcard origin
# together with credentials). settings.cors_origin_list is the exact, explicit
# allow-list, configured via the CORS_ORIGINS env var.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for r in (auth.router, customers.router, products.router, categories.router, sales.router,
          installments.router, payments.router, dashboard.router,
          ledger.router, notifications.router, admin.router, account.router):
    app.include_router(r)

_STATIC = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")


@app.exception_handler(LedgerImbalance)
async def _imbalance(request: Request, exc: LedgerImbalance):
    return JSONResponse(status_code=500, content={"detail": f"ledger invariant violated: {exc}"})


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/")
def root():
    return {
        "service": "Credit Commerce System API",
        "docs": "/docs",
        "note": "This is an API-only backend. The web UI is the separate Next.js app (ccs-web).",
    }


if os.path.isdir(_STATIC):
    app.mount("/static", StaticFiles(directory=_STATIC), name="static")
