from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import settings

engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

Base = declarative_base()


def set_tenant(db, tenant_id: int) -> None:
    """Bind the RLS tenant to THIS session. Stored on session.info so the
    after_begin listener can re-apply it on every transaction (surviving
    commit→refresh and pooled-connection recycling). Transaction-local GUC =
    no cross-tenant pool leakage."""
    db.info["tenant_id"] = str(tenant_id)
    db.execute(text("SELECT set_config('app.tenant_id', :t, true)"), {"t": str(tenant_id)})


def clear_tenant(db) -> None:
    db.info.pop("tenant_id", None)


@event.listens_for(SessionLocal, "after_begin")
def _reapply_tenant(session, transaction, connection):
    tid = session.info.get("tenant_id")
    if tid:
        connection.exec_driver_sql("SELECT set_config('app.tenant_id', %s, true)", (tid,))
