"""sale_items.variant_id: link sale lines to the specific variant sold (additive,
nullable FK -> product_variants.id). Existing rows remain NULL (legacy
product-level sales). Backward compatible: variant_id is optional in the API.

Revision ID: b2c3d4e5f6a7
Revises: a1b2c3d4e5f6
Create Date: 2026-06-15
"""
from alembic import op
import sqlalchemy as sa

revision = "b2c3d4e5f6a7"
down_revision = "a1b2c3d4e5f6"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("sale_items", sa.Column("variant_id", sa.BigInteger(), nullable=True))
    op.create_foreign_key(
        "fk_sale_items_variant_id", "sale_items", "product_variants", ["variant_id"], ["id"]
    )
    op.create_index("ix_sale_items_variant_id", "sale_items", ["variant_id"])


def downgrade():
    op.drop_index("ix_sale_items_variant_id", table_name="sale_items")
    op.drop_constraint("fk_sale_items_variant_id", "sale_items", type_="foreignkey")
    op.drop_column("sale_items", "variant_id")
