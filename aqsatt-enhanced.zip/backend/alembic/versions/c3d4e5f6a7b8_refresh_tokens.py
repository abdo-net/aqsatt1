"""refresh_tokens: server-side refresh-token registry for the access+refresh
auth system. Auth-plumbing table (NOT tenant-RLS scoped, same class as users /
request_idempotency). Grants SELECT/INSERT/UPDATE to ccs_app (insert at login,
select to validate, update to revoke/rotate). No DELETE — rows are never hard
deleted. Fully self-contained: imports no application state.

Revision ID: c3d4e5f6a7b8
Revises: b2c3d4e5f6a7
Create Date: 2026-06-20
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "c3d4e5f6a7b8"
down_revision = "b2c3d4e5f6a7"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "refresh_tokens",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("jti", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("user_agent", sa.String(length=255), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("jti", name="uq_refresh_jti"),
    )
    op.create_index("idx_refresh_user_active", "refresh_tokens", ["user_id", "revoked_at"])

    # App role: insert (login), select (validate), update (revoke/rotate). No DELETE.
    op.execute("GRANT SELECT, INSERT, UPDATE ON refresh_tokens TO ccs_app")
    op.execute("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ccs_app")


def downgrade():
    op.execute("REVOKE SELECT, INSERT, UPDATE ON refresh_tokens FROM ccs_app")
    op.drop_index("idx_refresh_user_active", table_name="refresh_tokens")
    op.drop_table("refresh_tokens")
