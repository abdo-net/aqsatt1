"""catalog extension: product columns + variants + images (additive, backward compatible)

Revision ID: a1b2c3d4e5f6
Revises: 287d370eafcb
Create Date: 2026-06-15
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision = "a1b2c3d4e5f6"
down_revision = "287d370eafcb"
branch_labels = None
depends_on = None

NEW_RLS_TABLES = ["product_variants", "product_images"]


def upgrade():
    # 1. additive product columns (all nullable / defaulted -> backward compatible)
    op.add_column("products", sa.Column("description", sa.Text(), nullable=True))
    op.add_column("products", sa.Column("brand", sa.String(100), nullable=True))
    op.add_column("products", sa.Column("tags", sa.String(300), nullable=True))
    op.add_column("products", sa.Column("status", sa.String(20), server_default="active", nullable=False))

    # 2. product_variants
    op.create_table(
        "product_variants",
        sa.Column("id", sa.BigInteger(), sa.Identity(always=False), primary_key=True),
        sa.Column("public_id", UUID(as_uuid=True), server_default=sa.text("gen_random_uuid()"), nullable=False, unique=True),
        sa.Column("tenant_id", sa.BigInteger(), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("product_id", sa.BigInteger(), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("sku", sa.String(60), nullable=False),
        sa.Column("price_cash", sa.BigInteger(), nullable=False),
        sa.Column("price_installment", sa.BigInteger(), nullable=True),
        sa.Column("compare_price", sa.BigInteger(), nullable=True),
        sa.Column("cost_price", sa.BigInteger(), nullable=True),
        sa.Column("stock_quantity", sa.Integer(), server_default="0", nullable=False),
        sa.Column("attributes", JSONB(), nullable=True),
        sa.Column("is_default", sa.Boolean(), server_default="false", nullable=False),
        sa.Column("is_deleted", sa.Boolean(), server_default="false", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("price_cash > 0", name="ck_var_price"),
        sa.CheckConstraint("stock_quantity >= 0", name="ck_var_stock"),
    )
    op.create_index("uq_variant_sku", "product_variants", ["tenant_id", "sku"], unique=True,
                    postgresql_where=sa.text("is_deleted = false"))
    op.create_index("ix_variant_product", "product_variants", ["product_id"])

    # 3. product_images
    op.create_table(
        "product_images",
        sa.Column("id", sa.BigInteger(), sa.Identity(always=False), primary_key=True),
        sa.Column("tenant_id", sa.BigInteger(), sa.ForeignKey("tenants.id"), nullable=False),
        sa.Column("product_id", sa.BigInteger(), sa.ForeignKey("products.id"), nullable=False),
        sa.Column("variant_id", sa.BigInteger(), sa.ForeignKey("product_variants.id"), nullable=True),
        sa.Column("path", sa.String(300), nullable=False),
        sa.Column("thumb_path", sa.String(300), nullable=True),
        sa.Column("sort_order", sa.Integer(), server_default="0", nullable=False),
        sa.Column("is_deleted", sa.Boolean(), server_default="false", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
    )
    op.create_index("ix_image_product", "product_images", ["product_id"])

    # 4. RLS + grants mirroring the initial migration
    op.execute("GRANT SELECT, INSERT, UPDATE ON product_variants, product_images TO ccs_app")
    op.execute("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ccs_app")
    for t in NEW_RLS_TABLES:
        op.execute(f"ALTER TABLE {t} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {t} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY tenant_isolation ON {t} "
            f"USING (tenant_id = current_setting('app.tenant_id', true)::bigint) "
            f"WITH CHECK (tenant_id = current_setting('app.tenant_id', true)::bigint)"
        )

    # 5. backfill: every existing product gets a default variant mirroring it
    op.execute("""
        INSERT INTO product_variants (tenant_id, product_id, sku, price_cash, price_installment,
                                      stock_quantity, is_default, is_deleted)
        SELECT p.tenant_id, p.id, p.sku, p.base_price, p.base_price, p.stock_quantity, true, false
        FROM products p
        WHERE p.is_deleted = false
          AND NOT EXISTS (SELECT 1 FROM product_variants v WHERE v.product_id = p.id)
    """)


def downgrade():
    op.drop_table("product_images")
    op.drop_table("product_variants")
    op.drop_column("products", "status")
    op.drop_column("products", "tags")
    op.drop_column("products", "brand")
    op.drop_column("products", "description")
