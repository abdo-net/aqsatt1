"""customer_type: replace risk_class (trusted/qi/mixed) with customer_type
(guarantor/non_guarantor) — guarantor means the customer has a QI-card-backed
guarantee. Also adds two optional fields collected at signup: birth_date and
nearest_landmark (a delivery/collections aid, common in addresses without
formal street numbering). national_id already existed and stays nullable.

Revision ID: d4e5f6a7b8c9
Revises: c3d4e5f6a7b8
Create Date: 2026-06-21
"""
from alembic import op
import sqlalchemy as sa

revision = "d4e5f6a7b8c9"
down_revision = "c3d4e5f6a7b8"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("customers", sa.Column("customer_type", sa.String(length=15), nullable=True))
    op.execute("UPDATE customers SET customer_type = 'non_guarantor'")
    op.alter_column("customers", "customer_type", nullable=False, server_default="non_guarantor")
    op.create_check_constraint("ck_cust_type", "customers", "customer_type IN ('guarantor','non_guarantor')")

    op.add_column("customers", sa.Column("birth_date", sa.Date(), nullable=True))
    op.add_column("customers", sa.Column("nearest_landmark", sa.Text(), nullable=True))

    op.drop_constraint("ck_cust_risk", "customers", type_="check")
    op.drop_column("customers", "risk_class")


def downgrade():
    op.add_column("customers", sa.Column("risk_class", sa.String(length=10), nullable=True))
    op.execute("UPDATE customers SET risk_class = 'trusted'")
    op.alter_column("customers", "risk_class", nullable=False, server_default="trusted")
    op.create_check_constraint("ck_cust_risk", "customers", "risk_class IN ('trusted','qi','mixed')")

    op.drop_column("customers", "nearest_landmark")
    op.drop_column("customers", "birth_date")

    op.drop_constraint("ck_cust_type", "customers", type_="check")
    op.drop_column("customers", "customer_type")
